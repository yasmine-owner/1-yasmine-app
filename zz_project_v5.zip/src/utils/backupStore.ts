import { Capacitor } from '@capacitor/core';

// Automatic local snapshots of the ERP database.
// Android app: files in the app's private storage. Browser/PC: IndexedDB.
const DATA_KEY = 'factory_erp_medical_clean_v6'; // same key ERPContext saves to
const IDX_KEY = 'erp_backup_index_v1';
const MIN_GAP_MS = 60 * 1000;

export interface SnapMeta {
  name: string;
  ts: number;
  entries: number;
  accounts: number;
  reason: string;
  size: number;
  hash: string;
}

interface Adapter {
  write(name: string, text: string): Promise<void>;
  read(name: string): Promise<string>;
  remove(name: string): Promise<void>;
}

const idb = (): Promise<IDBDatabase> =>
  new Promise((res, rej) => {
    const r = indexedDB.open('erp_backups', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('snaps');
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });

const idbRun = async <T,>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> => {
  const db = await idb();
  return new Promise<T>((res, rej) => {
    const tx = db.transaction('snaps', mode);
    const req = fn(tx.objectStore('snaps'));
    tx.oncomplete = () => res(req.result);
    tx.onerror = () => rej(tx.error);
  });
};

const webAdapter: Adapter = {
  write: async (n, t) => void (await idbRun('readwrite', (s) => s.put(t, n))),
  read: async (n) => (await idbRun('readonly', (s) => s.get(n))) as string,
  remove: async (n) => void (await idbRun('readwrite', (s) => s.delete(n))),
};

const nativeAdapter: Adapter = {
  async write(n, t) {
    const { Filesystem, Directory, Encoding } = await import('@capacitor/filesystem');
    await Filesystem.writeFile({ path: `erp_backups/${n}`, data: t, directory: Directory.Data, encoding: Encoding.UTF8, recursive: true });
  },
  async read(n) {
    const { Filesystem, Directory, Encoding } = await import('@capacitor/filesystem');
    const r = await Filesystem.readFile({ path: `erp_backups/${n}`, directory: Directory.Data, encoding: Encoding.UTF8 });
    return r.data as string;
  },
  async remove(n) {
    const { Filesystem, Directory } = await import('@capacitor/filesystem');
    await Filesystem.deleteFile({ path: `erp_backups/${n}`, directory: Directory.Data });
  },
};

let adapter: Adapter | null = null;
const getAdapter = () => (adapter ??= Capacitor.isNativePlatform() ? nativeAdapter : webAdapter);
export const __setAdapter = (a: Adapter) => { adapter = a; };

const hashOf = (s: string) => {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
  return `${s.length}:${h}`;
};

export const listSnaps = (): SnapMeta[] => {
  try {
    const arr = JSON.parse(localStorage.getItem(IDX_KEY) || '[]') as SnapMeta[];
    return arr.sort((a, b) => b.ts - a.ts);
  } catch {
    return [];
  }
};
const saveIndex = (m: SnapMeta[]) => { try { localStorage.setItem(IDX_KEY, JSON.stringify(m)); } catch { /* ignore */ } };

// Keep the newest 20 snapshots plus the newest one of each of the last 14 days.
export const pickKeep = (metas: SnapMeta[], now: number): Set<string> => {
  const sorted = [...metas].sort((a, b) => b.ts - a.ts);
  const keep = new Set(sorted.slice(0, 20).map((m) => m.name));
  const seen = new Set<string>();
  for (const m of sorted) {
    if (now - m.ts > 14 * 86400000) continue;
    const day = new Date(m.ts).toDateString();
    if (!seen.has(day)) { seen.add(day); keep.add(m.name); }
  }
  return keep;
};

export async function takeSnapshot(reason: string, force = false): Promise<SnapMeta | null> {
  const raw = localStorage.getItem(DATA_KEY);
  if (!raw) return null;
  const d = JSON.parse(raw);
  delete d.ownerSecretPin; // never copy the secret PIN into snapshots
  const text = JSON.stringify(d);
  const hash = hashOf(text);
  const metas = listSnaps();
  const now = Date.now();
  if (!force && metas[0] && (metas[0].hash === hash || now - metas[0].ts < MIN_GAP_MS)) return null;
  const name = `snap_${now}.json`;
  await getAdapter().write(name, text);
  const meta: SnapMeta = {
    name, ts: now, reason, hash, size: text.length,
    entries: Array.isArray(d.journalEntries) ? d.journalEntries.length : 0,
    accounts: Array.isArray(d.accounts) ? d.accounts.length : 0,
  };
  const all = [meta, ...metas];
  const keep = pickKeep(all, now);
  for (const m of all) if (!keep.has(m.name)) { try { await getAdapter().remove(m.name); } catch { /* ignore */ } }
  saveIndex(all.filter((m) => keep.has(m.name)));
  return meta;
}

export const readSnapshot = (name: string) => getAdapter().read(name);
