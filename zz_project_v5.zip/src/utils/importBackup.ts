// Maps the sheets of an "AlYasmeen" Excel backup into this app's database format.
// Pure functions (no I/O) so they can be tested outside the browser.
export type Sheets = Record<string, unknown[][]>;
type Row = Record<string, any>;

const rowsOf = (sheets: Sheets, name: string): Row[] => {
  const r = sheets[name];
  if (!r || r.length < 2) return [];
  const head = r[0].map((h) => String(h ?? '').trim());
  return r
    .slice(1)
    .filter((row) => row.some((c) => c !== null && c !== undefined && c !== ''))
    .map((row) => Object.fromEntries(head.map((k, i) => [k, row[i] ?? ''])));
};

const num = (v: unknown): number => {
  const n = Number(String(v ?? '').replace(/,/g, '').trim());
  return Number.isFinite(n) ? n : 0;
};
const str = (v: unknown) => String(v ?? '').trim();
const day = (v: unknown) => (v instanceof Date ? v.toISOString().slice(0, 10) : str(v).slice(0, 10));

const accType = (t: string) =>
  /أصول|اصول/.test(t) ? 'asset'
  : /التزام/.test(t) ? 'liability'
  : /ملكية/.test(t) ? 'equity'
  : /إيراد|ايراد/.test(t) ? 'revenue'
  : 'expense';

const refType = (t: string) =>
  /شريك/.test(t) ? 'capital' : /مشتريات/.test(t) ? 'purchase' : /مبيعات/.test(t) ? 'sales'
  : /إنتاج/.test(t) ? 'production' : /رواتب/.test(t) ? 'payroll' : /مخزن|مخزون/.test(t) ? 'inventory' : 'manual';

const itemCategory = (t: string) =>
  /أدوات|ادوات/.test(t) ? 'cutting_tools' : /مستلزمات|خام/.test(t) ? 'raw_materials' : 'finished_goods';

const whType = (n: string) =>
  /أدوات|ادوات/.test(n) ? 'tools' : /خام/.test(n) ? 'raw' : /هالك/.test(n) ? 'scrap' : 'finished';

const EXTRAS: Record<string, string> = {
  employees: 'الموظفون', attendance: 'الحضور والانصراف', advances: 'السلف والخصومات', payroll: 'الرواتب',
  partnerMoves: 'حركات الشركاء', partnerDues: 'المستحقات', stockMoves: 'حركات المخزن',
  purchases: 'المشتريات', sales: 'المبيعات', parties: 'العملاء والموردون', documents: 'الصور والمستندات',
};

export interface ImportSummary {
  counts: Record<string, number>;
  totalDebit: number;
  totalCredit: number;
  warnings: string[];
}

export function buildDump(sheets: Sheets): { data: Record<string, any>; summary: ImportSummary } {
  const warnings: string[] = [];
  const need = ['دليل الحسابات', 'قيود اليومية', 'تفاصيل قيود اليومية'];
  const missing = need.filter((n) => !sheets[n]);
  if (missing.length) throw new Error(`الملف ناقص أوراق أساسية: ${missing.join('، ')}`);

  const accounts = rowsOf(sheets, 'دليل الحسابات').map((r) => ({
    id: str(r['كود الحساب']), code: str(r['كود الحساب']), name: str(r['اسم الحساب']),
    type: accType(str(r['نوع الحساب'])) as any, balance: 0,
  }));
  const byCode = new Map(accounts.map((a) => [a.code, a]));

  const heads = new Map(rowsOf(sheets, 'قيود اليومية').map((r) => [str(r['رقم القيد']), r]));
  const grouped = new Map<string, Row[]>();
  rowsOf(sheets, 'تفاصيل قيود اليومية').forEach((r) => {
    const k = str(r['رقم القيد']);
    grouped.set(k, [...(grouped.get(k) || []), r]);
  });

  let totalDebit = 0;
  let totalCredit = 0;
  const journalEntries = [...grouped.entries()].map(([no, ls]) => {
    const h = heads.get(no) || ls[0];
    const status = str(h['الحالة']);
    const isPosted = !/مسود|draft|ملغ|cancel|void/i.test(status);
    const lines = ls.map((l) => {
      const code = str(l['كود الحساب']);
      const acc = byCode.get(code);
      if (!acc) warnings.push(`قيد ${no}: الحساب ${code} غير موجود في دليل الحسابات`);
      return { accountId: code, accountCode: code, accountName: acc?.name || str(l['اسم الحساب']),
        debit: num(l['مدين']), credit: num(l['دائن']) };
    });
    const dr = lines.reduce((s, l) => s + l.debit, 0);
    const cr = lines.reduce((s, l) => s + l.credit, 0);
    if (Math.abs(dr - cr) > 0.01) warnings.push(`قيد ${no} غير متوازن: مدين ${dr} / دائن ${cr}`);
    if (isPosted) {
      totalDebit += dr;
      totalCredit += cr;
      lines.forEach((l) => {
        const a = byCode.get(l.accountCode);
        if (!a) return;
        a.balance += a.type === 'asset' || a.type === 'expense' ? l.debit - l.credit : l.credit - l.debit;
      });
    }
    return {
      id: `je-${no}`, entryNumber: no, date: day(h['التاريخ']), description: str(h['البيان'] || ls[0]['البيان']),
      referenceType: refType(str(h['نوع القيد'])) as any, isPosted, isReversed: /معكوس|reversed/i.test(status),
      createdBy: str(h['سجّله']) || 'استيراد', createdAt: `${day(h['التاريخ'])} 00:00`, lines, totalAmount: dr,
    };
  });

  const itemRows = rowsOf(sheets, 'الأصناف');
  const whNames = [...new Set(itemRows.map((r) => str(r['المخزن'])).filter(Boolean))];
  const warehouses = whNames.map((n, i) => ({
    id: `wh-${i + 1}`, code: `WH-${String(i + 1).padStart(2, '0')}`, name: n, type: whType(n) as any, location: '', managerName: '',
  }));
  const whId = (n: string) => warehouses.find((w) => w.name === n)?.id || warehouses[0]?.id || '';
  const inventory = itemRows.map((r) => {
    const qty = num(r['الرصيد']);
    const cost = num(r['تكلفة الوحدة']) || (qty ? num(r['قيمة الرصيد']) / qty : 0);
    return { id: str(r['كود الصنف']), code: str(r['كود الصنف']), name: str(r['اسم الصنف']),
      category: itemCategory(str(r['التصنيف'])) as any, unit: str(r['الوحدة']) || 'وحدة',
      warehouseId: whId(str(r['المخزن'])), currentStock: qty, minAlertStock: num(r['حد إعادة الطلب']),
      movingAverageCost: cost, lastPurchasePrice: cost };
  });

  // The items sheet may carry zero balances while stock movements exist: rebuild stock from the movements.
  if (!inventory.some((i) => i.currentStock !== 0)) {
    const moves = rowsOf(sheets, 'حركات المخزن').sort(
      (a, b) => day(a['التاريخ']).localeCompare(day(b['التاريخ'])) || str(a['رقم الحركة']).localeCompare(str(b['رقم الحركة']))
    );
    moves.forEach((m) => {
      const no = str(m['رقم الحركة']);
      const it = inventory.find((i) => i.code === str(m['كود الصنف']));
      if (!it) return void warnings.push(`حركة ${no}: الصنف ${str(m['كود الصنف'])} غير موجود`);
      const q = num(m['الكمية']);
      const c = num(m['تكلفة الوحدة']);
      const t = str(m['نوع الحركة']);
      if (/استلام|إضافة|اضافة|وارد|افتتاح|جرد/.test(t)) {
        const nq = it.currentStock + q;
        it.movingAverageCost = nq ? (it.currentStock * it.movingAverageCost + q * c) / nq : c;
        it.currentStock = nq;
        if (c) it.lastPurchasePrice = c;
      } else if (/صرف|إصدار|اصدار|خروج|بيع|هالك/.test(t)) {
        it.currentStock -= q;
      } else {
        warnings.push(`حركة ${no}: نوع غير معروف (${t})`);
      }
    });
  }

  const partners = rowsOf(sheets, 'الشركاء').map((r) => {
    const acc = byCode.get(str(r['حساب الجاري']));
    const share = num(r['نصيبه في الأرباح %']);
    return { id: str(r['المعرّف']), name: str(r['اسم الشريك']),
      initialContribution: num(r['الحصة الأصلية']) || num(r['حصته داخل نصيب الشريك الثالث']),
      currentBalance: acc ? acc.balance : num(r['المدفوع فعلًا']), notes: str(r['ملاحظات']),
      hasSubAccountInOtherPartner: str(r['تابع للشريك']) || undefined,
      ownershipSharePercentage: share || undefined };
  });

  const extras: Record<string, Row[]> = {};
  Object.entries(EXTRAS).forEach(([k, sheet]) => { extras[k] = rowsOf(sheets, sheet); });

  const counts = {
    accounts: accounts.length, journalEntries: journalEntries.length, partners: partners.length,
    inventory: inventory.length, warehouses: warehouses.length,
    ...Object.fromEntries(Object.entries(extras).map(([k, v]) => [k, v.length])),
  };
  if (Math.abs(totalDebit - totalCredit) > 0.01) warnings.push('ميزان المراجعة غير متوازن');

  return {
    data: { accounts, journalEntries, partners, inventory, warehouses, machines: [], cuttingTools: [],
      productionOrders: [], scrapLogs: [], extras },
    summary: { counts, totalDebit, totalCredit, warnings },
  };
}
