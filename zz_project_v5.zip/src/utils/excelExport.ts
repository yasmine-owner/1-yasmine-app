/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as XLSX from 'xlsx';
import {
  Account,
  CuttingTool,
  InventoryItem,
  JournalEntry,
  Machine,
  Partner,
  ProductionOrder,
  ScrapDowntimeLog,
} from '../types/erp';

export function exportCompleteFactoryExcel({
  journalEntries,
  accounts,
  partners,
  machines,
  cuttingTools,
  inventory,
  productionOrders,
  scrapLogs,
}: {
  journalEntries: JournalEntry[];
  accounts: Account[];
  partners: Partner[];
  machines: Machine[];
  cuttingTools: CuttingTool[];
  inventory: InventoryItem[];
  productionOrders: ProductionOrder[];
  scrapLogs: ScrapDowntimeLog[];
}) {
  const wb = XLSX.utils.book_new();

  // 1. شيت قيود اليومية المركزية (The single unified journal screen!)
  const journalRows: any[] = [];
  journalEntries.forEach((entry) => {
    entry.lines.forEach((line, idx) => {
      journalRows.push({
        'رقم القيد': entry.entryNumber,
        'التاريخ': entry.date,
        'البيان والشرح': entry.description,
        'سطر #': idx + 1,
        'كود الحساب': line.accountCode,
        'اسم الحساب': line.accountName,
        'مدين (منه)': line.debit,
        'دائن (له)': line.credit,
        'ملاحظة السطر': line.note || '',
        'نوع المرجع': entry.referenceType || 'يدوي',
        'الحالة': entry.isPosted ? 'مرحل' : 'مسودة',
        'بواسطة': entry.createdBy,
        'تاريخ الإنشاء': entry.createdAt,
      });
    });
  });
  const wsJournal = XLSX.utils.json_to_sheet(journalRows);
  XLSX.utils.book_append_sheet(wb, wsJournal, 'القيود اليومية المركزية');

  // 2. دليل الحسابات وميزان المراجعة
  const accountRows = accounts.map((acc) => ({
    'كود الحساب': acc.code,
    'اسم الحساب': acc.name,
    'نوع الحساب': acc.type === 'asset' ? 'أصول' : acc.type === 'liability' ? 'التزامات' : acc.type === 'equity' ? 'حقوق ملكية' : acc.type === 'revenue' ? 'إيرادات' : 'مصروفات وتكاليف',
    'الحساب الرئيسي': acc.parentCode || 'رئيسي',
    'الرصيد الحالي (جنيه مصري)': acc.balance,
    'الوصف': acc.description || '',
  }));
  const wsAccounts = XLSX.utils.json_to_sheet(accountRows);
  XLSX.utils.book_append_sheet(wb, wsAccounts, 'دليل الحسابات وميزان المراجعة');

  // 3. مساهمات الشركاء والماكينات والمخزون الطبي (2,400,000 جنيه مصري)
  const partnerRows = partners.map((p) => ({
    'اسم الشريك': p.name,
    'المساهمة المعتمدة (جنيه مصري)': p.initialContribution,
    'الرصيد الجاري الحالي (جنيه مصري)': p.currentBalance,
    'مكان إيداع المبلغ': p.hasSubAccountInOtherPartner ? `بحساب ${p.hasSubAccountInOtherPartner}` : 'حساب مباشر',
    'ملاحظات تدقيقية': p.notes,
  }));
  const wsPartners = XLSX.utils.json_to_sheet(partnerRows);
  XLSX.utils.book_append_sheet(wb, wsPartners, 'مساهمات الشركاء والماكينات');

  // 4. سجل الماكينات والمعدات
  const machineRows = machines.map((m) => ({
    'كود الماكينة': m.code,
    'اسم الماكينة': m.name,
    'النوع والموديل': `${m.brand} - ${m.model}`,
    'تاريخ الشراء': m.purchaseDate,
    'تكلفة الشراء الأصلية (جنيه مصري)': m.purchaseCost,
    'صافي القيمة الدفترية (جنيه مصري)': m.currentBookValue,
    'العمر الإنتاجي (سنوات)': m.usefulLifeYears,
    'ساعات التشغيل الكلية': m.totalRunHours,
    'ساعات التوقف والأعطال': m.totalBreakdownHours,
    'تكلفة التشغيل للساعة (جنيه مصري لكل ساعة)': m.hourlyOperatingCost,
    'الموقع': m.location,
    'الحالة التشغيلية': m.status === 'running' ? 'تعمل' : m.status === 'maintenance' ? 'صيانة' : 'متوقفة',
  }));
  const wsMachines = XLSX.utils.json_to_sheet(machineRows);
  XLSX.utils.book_append_sheet(wb, wsMachines, 'الماكينات والمعدات');

  // 5. أدوات القطع (End Mills)
  const toolRows = cuttingTools.map((t) => ({
    'كود الأداة': t.code,
    'اسم ومقاس الأداة': t.name,
    'المقاس والقطر': t.size,
    'النوع والطلاء': t.type,
    'المورد': t.supplier,
    'سعر الوحدة (جنيه مصري)': t.unitPrice,
    'العمر الافتراضي (ساعة)': t.expectedLifespanHours,
    'ساعات التشغيل الفعلية': t.actualRunHours,
    'عدد مرات الاستخدام': t.usageCount,
    'حالة الأداة': t.status === 'active' ? 'نشطة في التشغيل' : t.status === 'worn_out' ? 'مستهلكة طبيعياً' : 'مكسورة استثنائياً',
    'سبب الخروج': t.breakageReason === 'exceptional_breakage' ? 'كسر استثنائي' : 'استهلاك طبيعي',
  }));
  const wsTools = XLSX.utils.json_to_sheet(toolRows);
  XLSX.utils.book_append_sheet(wb, wsTools, 'أدوات القطع والـ EndMills');

  // 6. المخازن والأصناف
  const invRows = inventory.map((item) => ({
    'كود الصنف': item.code,
    'اسم الصنف': item.name,
    'التصنيف': item.category,
    'الوحدة': item.unit,
    'الرصيد المخزني الحالي': item.currentStock,
    'حد إعادة الطلب': item.minAlertStock,
    'متوسط التكلفة المرجح (جنيه مصري)': item.movingAverageCost,
    'إجمالي قيمة المخزون (جنيه مصري)': item.currentStock * item.movingAverageCost,
    'سعر البيع المقترح': item.sellingPrice || '-',
  }));
  const wsInv = XLSX.utils.json_to_sheet(invRows);
  XLSX.utils.book_append_sheet(wb, wsInv, 'المخازن والأصناف');

  // 7. أوامر الإنتاج والتكاليف
  const orderRows = productionOrders.map((o) => ({
    'رقم أمر الإنتاج': o.orderNumber,
    'المنتج المطلوب': o.productName,
    'الكمية المطلوبة': o.requiredQuantity,
    'الكمية المنتجة': o.producedQuantity,
    'المقبول جودة': o.acceptedQuantity,
    'المرفوض': o.rejectedQuantity,
    'المعاد تشغيله': o.reworkedQuantity,
    'الهالك': o.scrapQuantity,
    'إجمالي التكلفة الفعلية (جنيه مصري)': o.totalActualCost,
    'تكلفة القطعة المقبولة (جنيه مصري لكل قطعة)': o.costPerAcceptedUnit,
    'الحالة': o.status === 'completed' ? 'منجز تام' : 'قيد التشغيل',
  }));
  const wsOrders = XLSX.utils.json_to_sheet(orderRows);
  XLSX.utils.book_append_sheet(wb, wsOrders, 'أوامر الإنتاج والتكاليف');

  // 8. سجل الهالك والتوقفات
  const scrapDataRows = scrapLogs.map((s) => ({
    'التاريخ': s.date,
    'الوقت': s.time,
    'النوع': s.type === 'scrap' ? 'هالك خامات' : s.type === 'tool_breakage' ? 'كسر أداة قطع' : 'توقف ماكينة',
    'طبيعة الحدث': s.isNormal ? 'طبيعي ومخطط' : 'استثنائي وخسارة',
    'الكمية / المدة': `${s.quantityOrHours} ${s.unit}`,
    'السبب': s.reason,
    'المسؤول': s.responsiblePerson,
    'الأثر المالي (جنيه مصري)': s.financialImpact,
    'الإجراء التصحيحي': s.correctiveAction,
  }));
  const wsScrap = XLSX.utils.json_to_sheet(scrapDataRows);
  XLSX.utils.book_append_sheet(wb, wsScrap, 'الهالك والتوقفات');

  // Save workbook
  const dateStr = new Date().toISOString().slice(0, 10);
  XLSX.writeFile(wb, `ERP_Factory_Full_Workbook_${dateStr}.xlsx`);
}

export function importJournalEntriesFromExcel(file: File): Promise<any[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const json = XLSX.utils.sheet_to_json(worksheet);
        resolve(json);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = (error) => reject(error);
    reader.readAsArrayBuffer(file);
  });
}
