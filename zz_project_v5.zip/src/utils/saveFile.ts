import { Capacitor } from '@capacitor/core';

// Saves/shares a text file. In the Android app blob downloads do not work,
// so the file is written to cache and handed to the system share sheet.
export async function saveTextFile(filename: string, content: string, mime = 'application/json') {
  if (Capacitor.isNativePlatform()) {
    const { Filesystem, Directory, Encoding } = await import('@capacitor/filesystem');
    const { Share } = await import('@capacitor/share');
    const r = await Filesystem.writeFile({
      path: filename,
      data: content,
      directory: Directory.Cache,
      encoding: Encoding.UTF8,
    });
    await Share.share({ title: filename, url: r.uri, dialogTitle: 'حفظ أو مشاركة الملف' });
    try { localStorage.setItem('erp_last_export', String(Date.now())); } catch { /* ignore */ }
    return;
  }
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
  try { localStorage.setItem('erp_last_export', String(Date.now())); } catch { /* ignore */ }
}
