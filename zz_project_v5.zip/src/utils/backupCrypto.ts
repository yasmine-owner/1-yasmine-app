// AES-256-GCM encrypted backups, key derived from a password with PBKDF2-SHA256.
const enc = new TextEncoder();
const dec = new TextDecoder();

const toB64 = (buf: ArrayBuffer | Uint8Array): string => {
  const bytes = new Uint8Array(buf as ArrayBuffer);
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) {
    bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  }
  return btoa(bin);
};
const fromB64 = (s: string) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

async function deriveKey(password: string, salt: Uint8Array, iterations: number) {
  const base = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt: salt as BufferSource, iterations, hash: 'SHA-256' },
    base,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

export async function encryptBackup(plainText: string, password: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const iterations = 200000;
  const key = await deriveKey(password, salt, iterations);
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, enc.encode(plainText));
  return JSON.stringify({ app: 'factory-erp', v: 1, i: iterations, s: toB64(salt), n: toB64(iv), d: toB64(ct) });
}

export async function decryptBackup(fileText: string, password: string): Promise<string> {
  const p = JSON.parse(fileText);
  if (p.app !== 'factory-erp' || !p.d) throw new Error('not-a-backup');
  const key = await deriveKey(password, fromB64(p.s), p.i);
  const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: fromB64(p.n) }, key, fromB64(p.d));
  return dec.decode(pt);
}
