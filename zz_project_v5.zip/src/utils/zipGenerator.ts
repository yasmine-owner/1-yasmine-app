/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import JSZip from 'jszip';
import * as XLSX from 'xlsx';

export async function generateFullProjectZip(erpState: {
  journalEntries: any[];
  accounts: any[];
  partners: any[];
  machines: any[];
  cuttingTools: any[];
  inventory: any[];
  productionOrders: any[];
  scrapLogs: any[];
  auditLogs: any[];
  users: any[];
  theme: any;
}): Promise<Blob> {
  const zip = new JSZip();

  // 1. Documentation Folder
  const docFolder = zip.folder('Documentation');
  docFolder?.file(
    'دليل_التشغيل_والتثبيت_الشامل_للمصنع.md',
    `# دليل تشغيل وتثبيت النظام المتكامل لإدارة المصانع والحسابات (Enterprise Factory ERP)
الإصدار: 2.5.0 Enterprise
المصنع: مصنع الأشغال الهندسية والميكانيكية الدقيقة

## 1. نبذة عن النظام
برنامج ERP متكامل واحترافي يربط:
- الحسابات العامة وشاشة القيود اليومية المركزية
- المخازن المتعددة وتقييم المخزون بالمتوسط المرجح
- التصنيع وأوامر التشغيل ومتابعة القطع المقبولة والمرفوضة
- سجل الماكينات ومساهمات الشركاء والمخزون الطبي (2,400,000 جنيه مصري)
- أدوات القطع (End Mills) وفصل الاستهلاك الطبيعي عن الكسر الاستثنائي
- لوحة تحكم المالك السرية والمحمية بالكامل برمز PIN (الافتراضي: 7890)

## 2. كيفية التشغيل والتثبيت
### أولاً: كبرنامج مستقل على الويندوز (Desktop App)
1. افتح رابط البرنامج في متصفح Google Chrome أو Microsoft Edge.
2. انقر على أيقونة التثبيت (Install App) الموجودة بأقصى يمين شريط العنوان أو من قائمة الخيارات.
3. سيتم تثبيت البرنامج فورياً كأيقونة رسمية على سطح المكتب وقائمة Start، ويعمل كنافذة مستقلة بدون أشرطة المتصفح.

### ثانياً: كتطبيق محمول على الأندرويد (Android APK / PWA)
1. افتح الرابط من متصفح الهاتف Chrome.
2. انقر على خيارات المتصفح (الثلاث نقاط) واختر "تثبيت التطبيق" أو "إضافة إلى الشاشة الرئيسية".
3. سيظهر التطبيق على هاتفك بأيقونته وشاشة Splash كاملة دون الحاجة لفتح المتصفح.

### ثالثاً: التشغيل المحلي من السورس كود (Local Developer Server)
1. فك ضغط هذا الملف.
2. افتح مجلد Source_Code في الطرفية (Terminal / CMD).
3. اكتب:
   \`npm install\`
4. ثم شغّل السيرفر:
   \`npm run dev\`
5. افتح المتصفح على: \`http://localhost:3000\`
`
  );

  // 2. Database Folder
  const dbFolder = zip.folder('Database');
  dbFolder?.file('database_seed.json', JSON.stringify(erpState, null, 2));
  dbFolder?.file(
    'schema.sql',
    `-- Enterprise Factory ERP Database Schema (PostgreSQL / MySQL)
CREATE TABLE users (
  id VARCHAR(64) PRIMARY KEY,
  username VARCHAR(64) UNIQUE NOT NULL,
  name VARCHAR(128) NOT NULL,
  role VARCHAR(32) NOT NULL,
  email VARCHAR(128),
  is_active BOOLEAN DEFAULT TRUE,
  permissions JSONB NOT NULL
);

CREATE TABLE accounts (
  id VARCHAR(64) PRIMARY KEY,
  code VARCHAR(32) UNIQUE NOT NULL,
  name VARCHAR(128) NOT NULL,
  type VARCHAR(32) NOT NULL,
  parent_code VARCHAR(32),
  balance NUMERIC(15, 2) DEFAULT 0.00
);

CREATE TABLE journal_entries (
  id VARCHAR(64) PRIMARY KEY,
  entry_number VARCHAR(64) UNIQUE NOT NULL,
  date DATE NOT NULL,
  description TEXT NOT NULL,
  reference_type VARCHAR(32),
  total_amount NUMERIC(15, 2) NOT NULL,
  is_posted BOOLEAN DEFAULT TRUE,
  is_reversed BOOLEAN DEFAULT FALSE,
  created_by VARCHAR(64),
  lines JSONB NOT NULL
);

CREATE TABLE machines (
  id VARCHAR(64) PRIMARY KEY,
  code VARCHAR(32) UNIQUE NOT NULL,
  name VARCHAR(128) NOT NULL,
  purchase_cost NUMERIC(15, 2) NOT NULL,
  current_book_value NUMERIC(15, 2) NOT NULL,
  useful_life_years INT NOT NULL,
  total_run_hours NUMERIC(10, 2) DEFAULT 0,
  total_breakdown_hours NUMERIC(10, 2) DEFAULT 0,
  hourly_operating_cost NUMERIC(10, 2) DEFAULT 0,
  power_consumption_kw NUMERIC(10, 2) DEFAULT 0
);
`
  );

  // 3. Excel Workbook with all sheets
  const wb = XLSX.utils.book_new();

  // Journal
  const jRows: any[] = [];
  erpState.journalEntries.forEach((entry) => {
    entry.lines.forEach((l: any, idx: number) => {
      jRows.push({
        'رقم القيد': entry.entryNumber,
        'التاريخ': entry.date,
        'البيان': entry.description,
        'سطر': idx + 1,
        'كود الحساب': l.accountCode,
        'اسم الحساب': l.accountName,
        'مدين': l.debit,
        'دائن': l.credit,
        'ملاحظة': l.note || '',
      });
    });
  });
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(jRows), 'القيود اليومية المركزية');

  // Accounts
  XLSX.utils.book_append_sheet(
    wb,
    XLSX.utils.json_to_sheet(
      erpState.accounts.map((a) => ({
        'الكود': a.code,
        'اسم الحساب': a.name,
        'النوع': a.type,
        'الرصيد المرحل (جنيه مصري)': a.balance,
      }))
    ),
    'دليل الحسابات'
  );

  // Partners & 2.4M Capital
  XLSX.utils.book_append_sheet(
    wb,
    XLSX.utils.json_to_sheet(
      erpState.partners.map((p) => ({
        'اسم الشريك': p.name,
        'المساهمة المعتمدة (جنيه مصري)': p.initialContribution,
        'الرصيد الجاري الحالي (جنيه مصري)': p.currentBalance,
        'ملاحظات': p.notes,
      }))
    ),
    'مساهمات الشركاء 2.4 مليون جنيه'
  );

  // Machines
  XLSX.utils.book_append_sheet(
    wb,
    XLSX.utils.json_to_sheet(
      erpState.machines.map((m) => ({
        'كود الماكينة': m.code,
        'الاسم': m.name,
        'تكلفة الشراء': m.purchaseCost,
        'صافي القيمة الدفترية': m.currentBookValue,
        'ساعات التشغيل': m.totalRunHours,
        'ساعات الأعطال': m.totalBreakdownHours,
        'تكلفة الساعة': m.hourlyOperatingCost,
      }))
    ),
    'الماكينات والمعدات'
  );

  // Tools
  XLSX.utils.book_append_sheet(
    wb,
    XLSX.utils.json_to_sheet(
      erpState.cuttingTools.map((t) => ({
        'كود الأداة': t.code,
        'الاسم': t.name,
        'المقاس': t.size,
        'السعر': t.unitPrice,
        'العمر الافتراضي': t.expectedLifespanHours,
        'ساعات التشغيل': t.actualRunHours,
        'الحالة': t.status,
      }))
    ),
    'أدوات القطع End Mills'
  );

  // Inventory
  XLSX.utils.book_append_sheet(
    wb,
    XLSX.utils.json_to_sheet(
      erpState.inventory.map((i) => ({
        'الكود': i.code,
        'الاسم': i.name,
        'الوحدة': i.unit,
        'الرصيد': i.currentStock,
        'متوسط التكلفة': i.movingAverageCost,
        'إجمالي القيمة': i.currentStock * i.movingAverageCost,
      }))
    ),
    'المخازن والأصناف'
  );

  // Orders
  XLSX.utils.book_append_sheet(
    wb,
    XLSX.utils.json_to_sheet(
      erpState.productionOrders.map((o) => ({
        'رقم الأمر': o.orderNumber,
        'المنتج': o.productName,
        'الكمية المطلوبة': o.requiredQuantity,
        'المقبول جودة': o.acceptedQuantity,
        'المرفوض': o.rejectedQuantity,
        'التكلفة الإجمالية': o.totalActualCost,
        'تكلفة القطعة المقبولة': o.costPerAcceptedUnit,
      }))
    ),
    'أوامر الإنتاج والتكاليف'
  );

  const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const excelFolder = zip.folder('Excel_Templates');
  excelFolder?.file('Factory_ERP_Full_Workbook_2010.xlsx', excelBuffer);

  // 4. Installers & Build Scripts
  const instFolder = zip.folder('Installers_and_Scripts');
  instFolder?.file(
    'build_windows_installer.bat',
    `@echo off
echo ========================================================
echo جاري بناء ملف تثبيت الويندوز المستقل (Windows EXE / MSI)...
echo ========================================================
npm install
npm run build
npx @capacitor/cli add @capacitor-community/electron
echo تم تجهيز حزمة الويندوز بنجاح!
pause
`
  );
  instFolder?.file(
    'build_android_apk.sh',
    `#!/bin/bash
echo "========================================================"
echo "جاري تجهيز حزمة تطبيق أندرويد (Android APK)..."
echo "========================================================"
npm install
npm run build
npx @capacitor/cli add android
npx @capacitor/cli copy android
echo "افتح مجلد android في Android Studio لبناء ملف APK النهائي الموقع!"
`
  );

  // 5. Source Code Package Info
  const srcFolder = zip.folder('Source_Code_Structure');
  srcFolder?.file(
    'README_SOURCE.txt',
    `مشروع النظام المتكامل لإدارة المصانع والتكاليف (Enterprise Factory ERP)
- مبني بلغة TypeScript و React 19 الحديثة و Vite 8 و Tailwind CSS 4.
- شاشات وتطبيقات متجاوبة بالكامل RTL و LTR.
- قاعدة بيانات تفاعلية مع حفظ تلقائي محلي وسحابي.
- دعم كامل لتصدير واستيراد ملفات الإكسل بصيغة XLSX.
- كود المصدر كامل ومفتوح بالكامل للمالك بدون قيود أو شفرات سرية مخفية.
`
  );

  // Generate Zip Blob
  return await zip.generateAsync({ type: 'blob' });
}
