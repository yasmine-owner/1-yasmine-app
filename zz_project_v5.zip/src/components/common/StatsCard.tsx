/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatsCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  trend?: string;
  trendUp?: boolean;
  color?: 'blue' | 'emerald' | 'amber' | 'rose' | 'purple' | 'slate';
  badge?: string;
}

const colorMap = {
  blue: {
    bg: 'bg-blue-950/40 border-blue-800/50 hover:border-blue-500/70',
    iconBg: 'bg-blue-600/20 text-blue-400',
    text: 'text-blue-400',
  },
  emerald: {
    bg: 'bg-emerald-950/40 border-emerald-800/50 hover:border-emerald-500/70',
    iconBg: 'bg-emerald-600/20 text-emerald-400',
    text: 'text-emerald-400',
  },
  amber: {
    bg: 'bg-amber-950/40 border-amber-800/50 hover:border-amber-500/70',
    iconBg: 'bg-amber-600/20 text-amber-400',
    text: 'text-amber-400',
  },
  rose: {
    bg: 'bg-rose-950/40 border-rose-800/50 hover:border-rose-500/70',
    iconBg: 'bg-rose-600/20 text-rose-400',
    text: 'text-rose-400',
  },
  purple: {
    bg: 'bg-purple-950/40 border-purple-800/50 hover:border-purple-500/70',
    iconBg: 'bg-purple-600/20 text-purple-400',
    text: 'text-purple-400',
  },
  slate: {
    bg: 'bg-slate-900/60 border-slate-800 hover:border-slate-700',
    iconBg: 'bg-slate-800 text-slate-300',
    text: 'text-slate-400',
  },
};

export const StatsCard: React.FC<StatsCardProps> = ({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  trendUp,
  color = 'blue',
  badge,
}) => {
  const c = colorMap[color];

  return (
    <div
      className={`relative p-5 rounded-2xl border backdrop-blur-md transition-all duration-200 shadow-lg ${c.bg}`}
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-semibold text-slate-400 mb-1">{title}</p>
          <h3 className="text-2xl font-bold tracking-tight text-white">{value}</h3>
          {subtitle && <p className="text-xs text-slate-400 mt-1">{subtitle}</p>}
        </div>
        <div className={`p-3 rounded-xl ${c.iconBg}`}>
          <Icon className="w-6 h-6" />
        </div>
      </div>

      <div className="mt-4 flex items-center justify-between text-xs">
        {trend && (
          <div className="flex items-center gap-1 font-medium">
            <span className={trendUp ? 'text-emerald-400' : 'text-rose-400'}>
              {trendUp ? '↑' : '↓'} {trend}
            </span>
            <span className="text-slate-500">مقارنة بالشهر السابق</span>
          </div>
        )}
        {badge && (
          <span className="ml-auto px-2 py-0.5 rounded-full text-[11px] font-medium bg-slate-800/80 text-slate-300 border border-slate-700">
            {badge}
          </span>
        )}
      </div>
    </div>
  );
};
