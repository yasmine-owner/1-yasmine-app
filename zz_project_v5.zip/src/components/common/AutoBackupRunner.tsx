import { useEffect } from 'react';
import { takeSnapshot } from '../../utils/backupStore';

// Silent background component: snapshots the database when it changes.
export const AutoBackupRunner: React.FC = () => {
  useEffect(() => {
    try { void navigator.storage?.persist?.(); } catch { /* ignore */ }
    const run = (reason: string, force = false) => { takeSnapshot(reason, force).catch(() => undefined); };
    run('بداية الجلسة');
    const timer = window.setInterval(() => run('تلقائي بعد تغيير'), 30000);
    const onHide = () => { if (document.hidden) run('عند الخروج من التطبيق'); };
    document.addEventListener('visibilitychange', onHide);
    return () => { window.clearInterval(timer); document.removeEventListener('visibilitychange', onHide); };
  }, []);
  return null;
};
