import React, { useState } from 'react';
import { History } from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { listSnaps, readSnapshot, takeSnapshot, SnapMeta } from '../../utils/backupStore';
import { saveTextFile } from '../../utils/saveFile';

const fmtTime = (ts: number) => new Date(ts).toLocaleString('ar-EG', { dateStyle: 'medium', timeStyle: 'short' });

export const BackupCenter: React.FC = () => {
  const { currentUser, restoreDatabaseFromJSON } = useERP();
  const [snaps, setSnaps] = useState<SnapMeta[]>(listSnaps());
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  if (currentUser.role !== 'owner') return null;

  const lastExport = Number(localStorage.getItem('erp_last_export') || 0);
  const exportAge = lastExport ? Math.floor((Date.now() - lastExport) / 86400000) : -1;
  const refresh = () => setSnaps(listSnaps());

  const snapNow = async () => {
    setBusy(true);
    const m = await takeSnapshot('يدوي', true).catch(() => null);
    refresh();
    setMsg(m ? { ok: true, text: 'تم حفظ نسخة الآن.' } : { ok: false, text: 'لا توجد بيانات لحفظها.' });
    setBusy(false);
  };

  const restore = async (m: SnapMeta) => {
    if (!window.confirm(`الرجوع لنسخة ${fmtTime(m.ts)}؟ سيتم حفظ نسخة من وضعك الحالي أولاً.`)) return;
    setBusy(true);
    try {
      await takeSnapshot('قبل الاستعادة', true);
      const data = JSON.parse(await readSnapshot(m.name));
      const res = restoreDatabaseFromJSON(JSON.stringify({ data }));
      setMsg({ ok: res.success, text: res.message });
    } catch {
      setMsg({ ok: false, text: 'تعذر قراءة هذه النسخة.' });
    }
    refresh();
    setBusy(false);
  };

  const exportOut = async (m: SnapMeta) => {
    try {
      const data = JSON.parse(await readSnapshot(m.name));
      const file = { timestamp: new Date(m.ts).toISOString(), version: '2.5.0-enterprise', system: 'Factory ERP Suite', data };
      await saveTextFile(`Factory_ERP_Snapshot_${new Date(m.ts).toISOString().slice(0, 16).replace(/[:T]/g, '-')}.json`, JSON.stringify(file, null, 2));
    } catch {
      setMsg({ ok: false, text: 'تعذر تصدير هذه النسخة.' });
    }
  };

  return (
    <div className="p-4 rounded-2xl bg-slate-900 border border-emerald-500/40 space-y-3 text-xs">
      <div className="flex items-center gap-2 text-emerald-300 font-bold text-sm">
        <History className="w-4 h-4" /> النسخ التلقائية ({snaps.length})
      </div>
      <p className="text-slate-400">
        يحفظ التطبيق نسخة تلقائياً بعد كل تغيير. لو حصل إدخال غلط اختر نسخة قبله واضغط استعادة.
        النسخ دي داخل التليفون، فلو اتمسح التطبيق بتضيع. صدّر نسخة خارج الجهاز بانتظام.
      </p>
      {exportAge === -1 || exportAge >= 7 ? (
        <p className="text-amber-300">
          {exportAge === -1 ? 'لم تصدّر نسخة خارج الجهاز بعد.' : `آخر نسخة خارج الجهاز من ${exportAge} يوم.`} صدّر نسخة الآن.
        </p>
      ) : null}
      <button onClick={snapNow} disabled={busy}
        className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-bold disabled:opacity-60">
        حفظ نسخة الآن
      </button>
      {msg && <p className={msg.ok ? 'text-emerald-400' : 'text-rose-400'}>{msg.text}</p>}
      <div className="max-h-72 overflow-y-auto space-y-2">
        {snaps.map((m) => (
          <div key={m.name} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
            <div>
              <div className="text-white font-semibold">{fmtTime(m.ts)}</div>
              <div className="text-[10px] text-slate-500">{m.reason} · {m.entries} قيد</div>
            </div>
            <div className="flex gap-1.5 shrink-0">
              <button onClick={() => restore(m)} disabled={busy} className="px-2.5 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-bold">استعادة</button>
              <button onClick={() => exportOut(m)} className="px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-slate-200">تصدير</button>
            </div>
          </div>
        ))}
        {snaps.length === 0 && <p className="text-slate-500">لا توجد نسخ بعد. ستظهر بعد أول تغيير.</p>}
      </div>
    </div>
  );
};
