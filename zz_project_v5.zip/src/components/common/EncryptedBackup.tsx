import React, { useState } from 'react';
import { Lock } from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { decryptBackup, encryptBackup } from '../../utils/backupCrypto';
import { saveTextFile } from '../../utils/saveFile';

export const EncryptedBackup: React.FC = () => {
  const { currentUser, exportDatabaseAsJSON, restoreDatabaseFromJSON } = useERP();
  const [pw, setPw] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  if (currentUser.role !== 'owner') return null;

  const doBackup = async () => {
    setMsg(null);
    if (pw.length < 8) return setMsg({ ok: false, text: 'كلمة مرور النسخة لازم تكون 8 أحرف على الأقل. احتفظ بها، بدونها لا يمكن فتح النسخة.' });
    setBusy(true);
    try {
      const data = await encryptBackup(exportDatabaseAsJSON(), pw);
      await saveTextFile(`Factory_ERP_Backup_${new Date().toISOString().slice(0, 10)}.erpbak`, data, 'application/octet-stream');
      setMsg({ ok: true, text: 'تم تجهيز النسخة المشفرة. احفظها في Drive أو أرسلها لنفسك.' });
    } catch {
      setMsg({ ok: false, text: 'تعذر إنشاء النسخة المشفرة.' });
    }
    setBusy(false);
  };

  const doRestore = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setMsg(null);
    if (!pw) return setMsg({ ok: false, text: 'اكتب كلمة مرور النسخة أولاً ثم اختر الملف.' });
    if (!window.confirm('استعادة النسخة هتستبدل كل البيانات الحالية. متأكد؟')) return;
    setBusy(true);
    try {
      const plain = await decryptBackup(await file.text(), pw);
      const res = restoreDatabaseFromJSON(plain);
      setMsg({ ok: res.success, text: res.message });
    } catch {
      setMsg({ ok: false, text: 'كلمة المرور غير صحيحة أو الملف تالف.' });
    }
    setBusy(false);
  };

  return (
    <div className="p-4 rounded-2xl bg-slate-900 border border-amber-500/40 space-y-3 text-xs">
      <div className="flex items-center gap-2 text-amber-300 font-bold text-sm">
        <Lock className="w-4 h-4" /> نسخة احتياطية مشفرة (للمالك)
      </div>
      <input type="password" value={pw} onChange={(e) => setPw(e.target.value)}
        placeholder="كلمة مرور النسخة (8 أحرف على الأقل)"
        className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white" />
      <div className="flex flex-wrap gap-2">
        <button onClick={doBackup} disabled={busy}
          className="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold disabled:opacity-60">
          إنشاء نسخة مشفرة
        </button>
        <label className="px-4 py-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-200 font-semibold cursor-pointer">
          استعادة من نسخة
          <input type="file" className="hidden" onChange={doRestore} />
        </label>
      </div>
      {msg && <p className={msg.ok ? 'text-emerald-400' : 'text-rose-400'}>{msg.text}</p>}
    </div>
  );
};
