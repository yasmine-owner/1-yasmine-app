import React, { useMemo, useState } from 'react';
import { Zap } from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { Account } from '../../types/erp';

type Kind = 'receipt' | 'payment' | 'transfer' | 'partner_in' | 'partner_out';
type Group = 'cash' | 'recv_rev' | 'pay_exp' | 'equity';

const KINDS: { id: Kind; label: string; debit: Group; credit: Group; dLabel: string; cLabel: string }[] = [
  { id: 'receipt', label: 'قبض (من عميل أو إيراد)', debit: 'cash', credit: 'recv_rev', dLabel: 'تدخل إلى (خزينة/بنك)', cLabel: 'من (عميل/إيراد)' },
  { id: 'payment', label: 'دفع (لمورد أو مصروف)', debit: 'pay_exp', credit: 'cash', dLabel: 'عن (مورد/مصروف)', cLabel: 'تخرج من (خزينة/بنك)' },
  { id: 'transfer', label: 'تحويل بين خزينة وبنك', debit: 'cash', credit: 'cash', dLabel: 'إلى', cLabel: 'من' },
  { id: 'partner_in', label: 'مساهمة / إيداع من شريك', debit: 'cash', credit: 'equity', dLabel: 'تدخل إلى (خزينة/بنك)', cLabel: 'من الشريك' },
  { id: 'partner_out', label: 'سحب / رد لشريك', debit: 'equity', credit: 'cash', dLabel: 'إلى الشريك', cLabel: 'تخرج من (خزينة/بنك)' },
];

const fmt = (n: number) => (Number(n) || 0).toLocaleString('en-US');

export const QuickEntry: React.FC = () => {
  const { accounts, addJournalEntry, currentUser } = useERP();
  const [kind, setKind] = useState<Kind>('receipt');
  const [debitId, setDebitId] = useState('');
  const [creditId, setCreditId] = useState('');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [doc, setDoc] = useState('');
  const [desc, setDesc] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const k = KINDS.find((x) => x.id === kind)!;

  const pick = useMemo(() => {
    const leaf = (a: Account) => !accounts.some((x) => x.parentCode === a.code);
    const groups: Record<Group, (a: Account) => boolean> = {
      cash: (a) => a.type === 'asset' && /خزين|بنك|البنك|نقد/.test(a.name),
      recv_rev: (a) => (a.type === 'asset' && /عملاء|قبض/.test(a.name)) || a.type === 'revenue',
      pay_exp: (a) => a.type === 'liability' || a.type === 'expense',
      equity: (a) => a.type === 'equity',
    };
    const list = (g: Group) => accounts.filter((a) => leaf(a) && groups[g](a));
    return { debit: list(k.debit), credit: list(k.credit) };
  }, [accounts, k]);

  if (!currentUser.permissions.canPost) {
    return (
      <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-slate-400">
        ليس لديك صلاحية تسجيل الحركات. اطلب من المالك منحك صلاحية الترحيل.
      </div>
    );
  }

  const changeKind = (v: Kind) => {
    setKind(v);
    setDebitId('');
    setCreditId('');
    setMsg(null);
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const d = accounts.find((a) => a.id === debitId);
    const c = accounts.find((a) => a.id === creditId);
    const amt = Number(amount);
    if (!d || !c) return setMsg({ ok: false, text: 'اختر الحسابين.' });
    if (d.id === c.id) return setMsg({ ok: false, text: 'لا يمكن اختيار نفس الحساب في الطرفين.' });
    if (!(amt > 0)) return setMsg({ ok: false, text: 'اكتب مبلغاً أكبر من صفر.' });
    if (k.credit === 'cash' && amt > (c.balance || 0)) {
      return setMsg({ ok: false, text: `الرصيد غير كافٍ في ${c.name}. المتاح ${fmt(c.balance)} ج.` });
    }
    const description = `${k.label.split(' (')[0]}${doc ? ` — مستند ${doc}` : ''}${desc ? ` — ${desc}` : ''}`;
    const res = addJournalEntry({
      date,
      description,
      referenceType: 'manual',
      lines: [
        { accountId: d.id, accountCode: d.code, accountName: d.name, debit: amt, credit: 0, note: desc },
        { accountId: c.id, accountCode: c.code, accountName: c.name, debit: 0, credit: amt, note: desc },
      ],
    });
    setMsg({ ok: res.success, text: res.message });
    if (res.success) {
      setAmount('');
      setDesc('');
      setDoc('');
    }
  };

  const dAcc = accounts.find((a) => a.id === debitId);
  const cAcc = accounts.find((a) => a.id === creditId);
  const cls = 'w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs';

  return (
    <form onSubmit={submit} className="p-4 rounded-2xl bg-slate-900 border border-blue-500/40 space-y-3 text-xs">
      <div className="flex items-center gap-2 text-blue-300 font-bold text-sm">
        <Zap className="w-4 h-4" /> تسجيل حركة سريعة (قبض / دفع / تحويل)
      </div>
      <select value={kind} onChange={(e) => changeKind(e.target.value as Kind)} className={cls}>
        {KINDS.map((x) => (
          <option key={x.id} value={x.id}>{x.label}</option>
        ))}
      </select>
      <div>
        <label className="block text-slate-400 mb-1">{k.dLabel}</label>
        <select value={debitId} onChange={(e) => setDebitId(e.target.value)} className={cls}>
          <option value="">— اختر —</option>
          {pick.debit.map((a) => (
            <option key={a.id} value={a.id}>{a.code} — {a.name}</option>
          ))}
        </select>
        {dAcc && <p className="text-[10px] text-slate-500 mt-1">الرصيد الحالي: {fmt(dAcc.balance)} ج.م</p>}
      </div>
      <div>
        <label className="block text-slate-400 mb-1">{k.cLabel}</label>
        <select value={creditId} onChange={(e) => setCreditId(e.target.value)} className={cls}>
          <option value="">— اختر —</option>
          {pick.credit.map((a) => (
            <option key={a.id} value={a.id}>{a.code} — {a.name}</option>
          ))}
        </select>
        {cAcc && <p className="text-[10px] text-slate-500 mt-1">الرصيد الحالي: {fmt(cAcc.balance)} ج.م</p>}
      </div>
      <div className="grid grid-cols-2 gap-2">
        <input type="number" inputMode="decimal" min="0" step="0.01" value={amount}
          onChange={(e) => setAmount(e.target.value)} placeholder="المبلغ" className={cls} />
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={cls} />
        <input type="text" value={doc} onChange={(e) => setDoc(e.target.value)} placeholder="رقم المستند (اختياري)" className={cls} />
        <input type="text" value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="البيان" className={cls} />
      </div>
      {msg && <p className={msg.ok ? 'text-emerald-400' : 'text-rose-400'}>{msg.text}</p>}
      <button type="submit" className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold">
        تسجيل وترحيل
      </button>
    </form>
  );
};
