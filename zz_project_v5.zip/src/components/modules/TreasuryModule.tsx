/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  ArrowDownLeft,
  ArrowRightLeft,
  ArrowUpRight,
  Banknote,
  Building,
  CheckCircle2,
  DollarSign,
  FileSpreadsheet,
  Plus,
  Wallet,
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';

export const TreasuryModule: React.FC = () => {
  const { accounts, addJournalEntry } = useERP();
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [showVoucherModal, setShowVoucherModal] = useState(false);

  // Transfer State
  const [fromAccount, setFromAccount] = useState('acc-111'); // Cash
  const [toAccount, setToAccount] = useState('acc-112'); // Bank
  const [transferAmount, setTransferAmount] = useState(15000);
  const [transferDesc, setTransferDesc] = useState('إيداع نقدي من الخزينة لحساب البنك');

  // Receipt / Payment State
  const [voucherType, setVoucherType] = useState<'receipt' | 'payment'>('receipt');
  const [treasuryAccount, setTreasuryAccount] = useState('acc-111');
  const [counterpartyAccount, setCounterpartyAccount] = useState('acc-113'); // Customers
  const [voucherAmount, setVoucherAmount] = useState(20000);
  const [voucherDesc, setVoucherDesc] = useState('تحصيل دفعة نقدية من عميل');

  const cashAccount = accounts.find((a) => a.code === '1110');
  const bankAccount = accounts.find((a) => a.code === '1120');

  const handleTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    if (transferAmount <= 0) return;
    const fromAcc = accounts.find((a) => a.id === fromAccount);
    const toAcc = accounts.find((a) => a.id === toAccount);
    if (!fromAcc || !toAcc) return;

    // In double-entry: ToAccount is debited, FromAccount is credited
    addJournalEntry({
      date: new Date().toISOString().slice(0, 10),
      description: transferDesc,
      referenceType: 'manual',
      lines: [
        { accountId: toAcc.id, accountCode: toAcc.code, accountName: toAcc.name, debit: transferAmount, credit: 0, note: 'تحويل وارد' },
        { accountId: fromAcc.id, accountCode: fromAcc.code, accountName: fromAcc.name, debit: 0, credit: transferAmount, note: 'تحويل منصرف' },
      ],
    });

    setShowTransferModal(false);
  };

  const handleVoucher = (e: React.FormEvent) => {
    e.preventDefault();
    if (voucherAmount <= 0) return;
    const trAcc = accounts.find((a) => a.id === treasuryAccount);
    const cpAcc = accounts.find((a) => a.id === counterpartyAccount);
    if (!trAcc || !cpAcc) return;

    if (voucherType === 'receipt') {
      // Cash/Bank is debited, Counterparty (Customer/Revenue) is credited
      addJournalEntry({
        date: new Date().toISOString().slice(0, 10),
        description: `سند قبض نقدي: ${voucherDesc}`,
        referenceType: 'sales',
        lines: [
          { accountId: trAcc.id, accountCode: trAcc.code, accountName: trAcc.name, debit: voucherAmount, credit: 0, note: 'قبض وإيداع بالخزينة/البنك' },
          { accountId: cpAcc.id, accountCode: cpAcc.code, accountName: cpAcc.name, debit: 0, credit: voucherAmount, note: 'تسوية حساب العميل / الإيراد' },
        ],
      });
    } else {
      // Counterparty (Supplier/Expense) is debited, Cash/Bank is credited
      addJournalEntry({
        date: new Date().toISOString().slice(0, 10),
        description: `سند صرف نقدي: ${voucherDesc}`,
        referenceType: 'purchase',
        lines: [
          { accountId: cpAcc.id, accountCode: cpAcc.code, accountName: cpAcc.name, debit: voucherAmount, credit: 0, note: 'سداد للمورد / مصروف' },
          { accountId: trAcc.id, accountCode: trAcc.code, accountName: trAcc.name, debit: 0, credit: voucherAmount, note: 'صرف من الخزينة/البنك' },
        ],
      });
    }

    setShowVoucherModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-l from-slate-900 via-slate-900 to-emerald-950/40 border border-slate-800 shadow-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="p-2 rounded-xl bg-emerald-600/20 text-emerald-400 border border-emerald-500/30">
              <Wallet className="w-6 h-6" />
            </span>
            <h2 className="text-xl font-bold text-white">إدارة الخزائن والبنوك والسيولة النقدية</h2>
          </div>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            متابعة حركة النقدية والمقبوضات والمدفوعات والتحويلات البنكية، مع الترحيل التلقائي الفوري
            لقيود اليومية المركزية وحسابات الأستاذ العام.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowVoucherModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs shadow-lg transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>سند قبض / صرف جديد</span>
          </button>
          <button
            onClick={() => setShowTransferModal(true)}
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition cursor-pointer"
          >
            <ArrowRightLeft className="w-4 h-4 text-blue-400" />
            <span>تحويل بين الخزينة والبنك</span>
          </button>
        </div>
      </div>

      {/* Cash & Bank Balance Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-6 rounded-3xl border border-slate-800 bg-slate-900 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-emerald-600/20 rounded-2xl text-emerald-400">
                <Banknote className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-base text-white">الخزينة الرئيسية (النقدية)</h3>
                <span className="text-xs text-slate-400 font-mono">كود الحساب: 1110</span>
              </div>
            </div>
            <span className="font-mono text-2xl font-bold text-emerald-400">
              {(cashAccount?.balance || 0).toLocaleString()} جنيه مصري
            </span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            السيولة الكاش الجاهزة للصرف الفوري لمستلزمات الورشة ونثريات المصنع وتوريدات الطوارئ.
          </p>
        </div>

        <div className="p-6 rounded-3xl border border-slate-800 bg-slate-900 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-blue-600/20 rounded-2xl text-blue-400">
                <Building className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-base text-white">البنك الأهلي المصري - جاري</h3>
                <span className="text-xs text-slate-400 font-mono">كود الحساب: 1120</span>
              </div>
            </div>
            <span className="font-mono text-2xl font-bold text-blue-400">
              {(bankAccount?.balance || 0).toLocaleString()} جنيه مصري
            </span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            حساب التحويلات البنكية والمشتريات الكبرى للخامات وسداد مستحقات موردي الصلب والألومنيوم.
          </p>
        </div>
      </div>

      {/* Transfer Modal */}
      {showTransferModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-6 text-white shadow-2xl">
            <h3 className="text-base font-bold text-white mb-4">تحويل أموال بين الخزائن والبنوك</h3>
            <form onSubmit={handleTransfer} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">من حساب (الطرف الدائن)</label>
                <select
                  value={fromAccount}
                  onChange={(e) => setFromAccount(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="acc-111">الخزينة الرئيسية (1110)</option>
                  <option value="acc-112">البنك الأهلي المصري (1120)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">إلى حساب (الطرف المدين)</label>
                <select
                  value={toAccount}
                  onChange={(e) => setToAccount(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="acc-112">البنك الأهلي المصري (1120)</option>
                  <option value="acc-111">الخزينة الرئيسية (1110)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">المبلغ المحول (جنيه مصري)</label>
                <input
                  type="number"
                  value={transferAmount}
                  onChange={(e) => setTransferAmount(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:border-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">البيان والشرح</label>
                <input
                  type="text"
                  value={transferDesc}
                  onChange={(e) => setTransferDesc(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowTransferModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold transition shadow-lg"
                >
                  تنفيذ التحويل وترحيل القيد
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Voucher Modal */}
      {showVoucherModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-6 text-white shadow-2xl">
            <h3 className="text-base font-bold text-white mb-4">إنشاء سند قبض أو صرف نقدي</h3>
            <form onSubmit={handleVoucher} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">نوع السند</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setVoucherType('receipt')}
                    className={`py-2 rounded-xl border font-bold text-xs transition cursor-pointer ${
                      voucherType === 'receipt'
                        ? 'bg-emerald-950 border-emerald-500 text-emerald-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    سند قبض (وارد نقدي)
                  </button>
                  <button
                    type="button"
                    onClick={() => setVoucherType('payment')}
                    className={`py-2 rounded-xl border font-bold text-xs transition cursor-pointer ${
                      voucherType === 'payment'
                        ? 'bg-rose-950 border-rose-500 text-rose-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    سند صرف (منصرف نقدي)
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">حساب النقدية / البنك</label>
                  <select
                    value={treasuryAccount}
                    onChange={(e) => setTreasuryAccount(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="acc-111">الخزينة الرئيسية</option>
                    <option value="acc-112">البنك الأهلي</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">الطرف المقابل</label>
                  <select
                    value={counterpartyAccount}
                    onChange={(e) => setCounterpartyAccount(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="acc-113">العملاء وحسابات القبض</option>
                    <option value="acc-21">الموردون وأوراق الدفع</option>
                    <option value="acc-41">مبيعات المنتجات</option>
                    <option value="acc-51">تكلفة الخامات</option>
                    <option value="acc-54">فاتورة الكهرباء</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">المبلغ (جنيه مصري)</label>
                <input
                  type="number"
                  value={voucherAmount}
                  onChange={(e) => setVoucherAmount(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">البيان والشرح</label>
                <input
                  type="text"
                  value={voucherDesc}
                  onChange={(e) => setVoucherDesc(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowVoucherModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold transition shadow-lg"
                >
                  حفظ وترحيل السند
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
