/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Cpu,
  FileSpreadsheet,
  Plus,
  Scissors,
  Wrench,
  XCircle,
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import * as XLSX from 'xlsx';

export const CuttingToolsModule: React.FC = () => {
  const { cuttingTools, machines, addCuttingTool, updateToolStatus } = useERP();
  const [showAddModal, setShowAddModal] = useState(false);
  const [showBreakageModal, setShowBreakageModal] = useState(false);
  const [selectedToolId, setSelectedToolId] = useState('');
  const [breakageReason, setBreakageReason] = useState<'normal_wear' | 'exceptional_breakage'>('normal_wear');
  const [breakageNotes, setBreakageNotes] = useState('');

  // Form State
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [size, setSize] = useState('');
  const [supplier, setSupplier] = useState('');
  const [unitPrice, setUnitPrice] = useState(450);
  const [lifespan, setLifespan] = useState(60);

  const handleAddTool = (e: React.FormEvent) => {
    e.preventDefault();
    addCuttingTool({
      code: code || `EM-${cuttingTools.length + 1}`,
      name: name || 'بنطة تفريز End Mill',
      size: size || '6mm',
      type: 'Solid Carbide End Mill TiAlN',
      supplier: supplier || 'شركة التوريدات الصناعية',
      unitPrice: Number(unitPrice),
      expectedLifespanHours: Number(lifespan),
      actualRunHours: 0,
      usageCount: 0,
      status: 'active',
    });
    setShowAddModal(false);
  };

  const handleConfirmBreakage = () => {
    if (!selectedToolId) return;
    updateToolStatus(
      selectedToolId,
      breakageReason === 'normal_wear' ? 'worn_out' : 'broken',
      breakageReason,
      breakageNotes
    );
    setShowBreakageModal(false);
    setBreakageNotes('');
    setSelectedToolId('');
  };

  const exportToolsToExcel = () => {
    const data = cuttingTools.map((t) => ({
      'كود الأداة': t.code,
      'الاسم': t.name,
      'المقاس والقطر': t.size,
      'المورد': t.supplier,
      'سعر الوحدة (جنيه مصري)': t.unitPrice,
      'العمر الافتراضي (ساعة)': t.expectedLifespanHours,
      'ساعات التشغيل الفعلية': t.actualRunHours,
      'عدد الاستخدامات': t.usageCount,
      'الحالة': t.status,
      'سبب الخروج': t.breakageReason || '-',
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'أدوات القطع End Mills');
    XLSX.writeFile(wb, 'Cutting_Tools_EndMills.xlsx');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-l from-slate-900 via-slate-900 to-indigo-950/50 border border-slate-800 shadow-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="p-2 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
              <Scissors className="w-6 h-6" />
            </span>
            <h2 className="text-xl font-bold text-white">
              وحدة أدوات القطع والـ End Mills ومستلزمات CNC
            </h2>
          </div>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            متابعة دقيقة لبنط التفريز وفصوص الخراطة، عمر الحد القاطع الافتراضي بالساعات، وتوثيق
            حالات الاستهلاك الطبيعي وفصلها عن حالات الكسر الاستثنائي وتحميل تكلفتها على أوامر
            التشغيل المناسبة.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>تعريف أداة قطع جديدة</span>
          </button>
          <button
            onClick={exportToolsToExcel}
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>تصدير إكسل</span>
          </button>
        </div>
      </div>

      {/* Tools Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 overflow-hidden shadow-xl">
        <table className="w-full text-right text-xs">
          <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
            <tr>
              <th className="p-3.5">كود الأداة</th>
              <th className="p-3.5">اسم ومقاس بنطة التفريز (End Mill)</th>
              <th className="p-3.5">المورد</th>
              <th className="p-3.5">السعر (جنيه مصري)</th>
              <th className="p-3.5">العمر الافتراضي</th>
              <th className="p-3.5">ساعات العمل الفعلية</th>
              <th className="p-3.5">الحالة الحالية</th>
              <th className="p-3.5">تصنيف الاستهلاك/الكسر</th>
              <th className="p-3.5 text-center">الإجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {cuttingTools.map((tool) => {
              const remainingHours = Math.max(0, tool.expectedLifespanHours - tool.actualRunHours);
              const isWarning = remainingHours < 15 && tool.status === 'active';

              return (
                <tr key={tool.id} className="hover:bg-slate-800/40 transition">
                  <td className="p-3.5 font-mono font-bold text-indigo-400">{tool.code}</td>
                  <td className="p-3.5">
                    <p className="font-bold text-white">{tool.name}</p>
                    <span className="text-[10px] text-slate-400 font-mono">{tool.size}</span>
                  </td>
                  <td className="p-3.5 text-slate-300">{tool.supplier}</td>
                  <td className="p-3.5 font-mono font-bold text-slate-200">{tool.unitPrice} جنيه مصري</td>
                  <td className="p-3.5 font-mono text-slate-400">{tool.expectedLifespanHours} ساعة</td>
                  <td className="p-3.5">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-white">{tool.actualRunHours} ساعة</span>
                      {isWarning && (
                        <span className="text-[10px] text-amber-400 bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-800">
                          قرب انتهاء العمر!
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="p-3.5">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                        tool.status === 'active'
                          ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                          : tool.status === 'worn_out'
                          ? 'bg-slate-800 text-slate-400 border-slate-700'
                          : 'bg-rose-950 text-rose-400 border-rose-800'
                      }`}
                    >
                      {tool.status === 'active'
                        ? '🟢 نشطة بالتشغيل'
                        : tool.status === 'worn_out'
                        ? '⚪ مستهلكة طبيعياً'
                        : '🔴 مكسورة'}
                    </span>
                  </td>
                  <td className="p-3.5">
                    {tool.breakageReason === 'exceptional_breakage' ? (
                      <span className="px-2 py-0.5 rounded-md text-[10px] bg-rose-950 text-rose-400 border border-rose-800 font-bold">
                        كسر استثنائي (خسارة)
                      </span>
                    ) : tool.breakageReason === 'normal_wear' ? (
                      <span className="px-2 py-0.5 rounded-md text-[10px] bg-slate-800 text-slate-300 border border-slate-700 font-medium">
                        استهلاك تشغيلي طبيعي
                      </span>
                    ) : (
                      <span className="text-slate-500">-</span>
                    )}
                  </td>
                  <td className="p-3.5 text-center">
                    {tool.status === 'active' && (
                      <button
                        onClick={() => {
                          setSelectedToolId(tool.id);
                          setShowBreakageModal(true);
                        }}
                        className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 text-[11px] font-semibold border border-slate-700 cursor-pointer"
                      >
                        تسجيل استهلاك / كسر
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Breakage / Wear Modal */}
      {showBreakageModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-6 text-white shadow-2xl">
            <h3 className="text-base font-bold text-white mb-2">
              تسجيل استهلاك أو كسر أداة قطع (End Mill)
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              حدد طبيعة خروج الأداة لحساب التكلفة بشكل عادل وفصل الخسائر الاستثنائية عن التكاليف
              الصناعية المعتادة:
            </p>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-2">نوع الخروج</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setBreakageReason('normal_wear')}
                    className={`p-3 rounded-xl border text-center font-bold transition cursor-pointer ${
                      breakageReason === 'normal_wear'
                        ? 'bg-blue-950 border-blue-500 text-blue-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    استهلاك طبيعي
                    <span className="block text-[10px] font-normal text-slate-400 mt-1">
                      انتهاء العمر الافتراضي
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setBreakageReason('exceptional_breakage')}
                    className={`p-3 rounded-xl border text-center font-bold transition cursor-pointer ${
                      breakageReason === 'exceptional_breakage'
                        ? 'bg-rose-950 border-rose-500 text-rose-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    كسر استثنائي
                    <span className="block text-[10px] font-normal text-slate-400 mt-1">
                      خطأ برمجة أو تغذية
                    </span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">
                  شرح السبب والإجراء المتخذ
                </label>
                <textarea
                  value={breakageNotes}
                  onChange={(e) => setBreakageNotes(e.target.value)}
                  placeholder="مثال: انتهاء الحد القاطع طبيعياً، أو كسر بسبب زيادة Feed Rate أثناء تفريز جيب عميق..."
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-indigo-500 h-20"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowBreakageModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  إلغاء
                </button>
                <button
                  type="button"
                  onClick={handleConfirmBreakage}
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold transition shadow-lg cursor-pointer"
                >
                  تأكيد وإخراج الأداة
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Tool Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-6 text-white shadow-2xl">
            <h3 className="text-base font-bold text-white mb-4">تعريف أداة قطع جديدة</h3>
            <form onSubmit={handleAddTool} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">اسم الأداة</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="مثال: End Mill 12mm 4-Flute"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">الكود والمقاس</label>
                  <input
                    type="text"
                    value={size}
                    onChange={(e) => setSize(e.target.value)}
                    placeholder="Ø 12mm x 75mm"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">المورد</label>
                  <input
                    type="text"
                    value={supplier}
                    onChange={(e) => setSupplier(e.target.value)}
                    placeholder="اسم المورد"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">سعر الشراء (جنيه مصري)</label>
                  <input
                    type="number"
                    value={unitPrice}
                    onChange={(e) => setUnitPrice(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">
                    العمر الافتراضي (ساعات)
                  </label>
                  <input
                    type="number"
                    value={lifespan}
                    onChange={(e) => setLifespan(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold transition shadow-lg"
                >
                  حفظ الأداة
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
