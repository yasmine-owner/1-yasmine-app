/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Activity,
  AlertTriangle,
  ArrowDownLeft,
  ArrowUpRight,
  Boxes,
  CheckCircle2,
  Clock,
  Cpu,
  DollarSign,
  Factory,
  FileSpreadsheet,
  Package,
  Plus,
  Scissors,
  TrendingDown,
  TrendingUp,
  Users2,
  Wallet,
} from 'lucide-react';
import { StatsCard } from '../common/StatsCard';
import { useERP } from '../../context/ERPContext';

interface DashboardModuleProps {
  setActiveModule: (mod: string) => void;
}

export const DashboardModule: React.FC<DashboardModuleProps> = ({ setActiveModule }) => {
  const {
    journalEntries,
    accounts,
    machines,
    cuttingTools,
    inventory,
    productionOrders,
    scrapLogs,
    theme,
  } = useERP();

  // Financial aggregates
  const revenues = accounts
    .filter((a) => a.type === 'revenue')
    .reduce((s, a) => s + (a.balance || 0), 0);
  const expenses = accounts
    .filter((a) => a.type === 'expense')
    .reduce((s, a) => s + (a.balance || 0), 0);
  const netProfit = revenues - expenses;

  const cashAccount = accounts.find((a) => a.code === '1110');
  const bankAccount = accounts.find((a) => a.code === '1120');
  const totalLiquidity = (cashAccount?.balance || 0) + (bankAccount?.balance || 0);

  const activeMachines = machines.filter((m) => m.status === 'running').length;
  const lowStockCount = inventory.filter((i) => i.currentStock <= i.minAlertStock).length;
  const completedOrders = productionOrders.filter((o) => o.status === 'completed').length;
  const inProgressOrders = productionOrders.filter((o) => o.status === 'in_progress').length;

  return (
    <div className="space-y-6">
      {/* Welcome / Header Banner matching the high-tech 3D design */}
      <div className="relative overflow-hidden p-6 rounded-3xl bg-gradient-to-l from-blue-950/80 via-slate-900 to-slate-900 border border-blue-800/40 shadow-2xl">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
              <span className="text-xs font-semibold text-blue-400">
                لوحة التشغيل والمراقبة الحية (SoftStream Live Control)
              </span>
            </div>
            <h2 className="text-2xl font-bold text-white tracking-tight">
              {theme.companyName || 'مصنع الشرق للأشغال الهندسية والميكانيكية'}
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              نظام ERP متكامل يربط الماكينات والحسابات والمخازن والتكاليف والقيود اليومية المركزية
              لحظياً.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setActiveModule('journal')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/30 transition cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>تسجيل قيد يومية فوري</span>
            </button>
            <button
              onClick={() => setActiveModule('manufacturing')}
              className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition cursor-pointer"
            >
              <Factory className="w-4 h-4 text-cyan-400" />
              <span>أوامر الإنتاج</span>
            </button>
          </div>
        </div>

        {/* Live System Alerts Ribbon */}
        {lowStockCount > 0 && (
          <div className="mt-5 p-3 rounded-xl bg-amber-950/40 border border-amber-800/50 flex items-center justify-between text-xs text-amber-300">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                تنبيه مخزني: يوجد <strong>{lowStockCount} أصناف/أدوات قطع</strong> اقتربت من حد إعادة
                الطلب الأدنى!
              </span>
            </div>
            <button
              onClick={() => setActiveModule('inventory')}
              className="px-2.5 py-1 rounded-lg bg-amber-500 text-slate-950 font-bold hover:bg-amber-400 transition cursor-pointer"
            >
              فحص النواقص
            </button>
          </div>
        )}
      </div>

      {/* Top 4 KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="إجمالي المبيعات والإيرادات"
          value={`${revenues.toLocaleString()} جنيه مصري`}
          subtitle="المبيعات وخدمات التشغيل المحققة"
          icon={TrendingUp}
          trend={revenues > 0 ? "+14.2%" : undefined}
          trendUp={true}
          color="blue"
          badge="إيراد"
        />

        <StatsCard
          title="إجمالي التكاليف والمصروفات"
          value={`${expenses.toLocaleString()} جنيه مصري`}
          subtitle="خامات، كهرباء، عمالة، وإهلاك"
          icon={TrendingDown}
          trend={expenses > 0 ? "+5.1%" : undefined}
          trendUp={false}
          color="rose"
          badge="تكلفة"
        />

        <StatsCard
          title="صافي الأرباح المحققة"
          value={`${netProfit.toLocaleString()} جنيه مصري`}
          subtitle={revenues > 0 ? `هامش ربح تشغيلي ${((netProfit / (revenues || 1)) * 100).toFixed(1)}%` : 'مصنع جديد - بانتظار أول دورة بيعية'}
          icon={DollarSign}
          trend={netProfit > 0 ? "+18.4%" : undefined}
          trendUp={true}
          color="emerald"
          badge="أرباح"
        />

        <StatsCard
          title="السيولة النقدية (الخزينة والبنوك)"
          value={`${totalLiquidity.toLocaleString()} جنيه مصري`}
          subtitle="رصيد جاهز للتشغيل والمشتريات"
          icon={Wallet}
          color="purple"
          badge="سيولة"
        />
      </div>

      {/* Second Row: Operations & Shop Floor KPIs */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Machinery Status */}
        <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Cpu className="w-5 h-5 text-blue-400" />
              <h3 className="font-bold text-sm text-white">حالة خطوط الإنتاج وماكينات CNC</h3>
            </div>
            <button
              onClick={() => setActiveModule('machines')}
              className="text-xs text-blue-400 hover:underline"
            >
              عرض الكل
            </button>
          </div>

          <div className="space-y-3">
            {machines.map((m) => (
              <div
                key={m.id}
                className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-center justify-between"
              >
                <div>
                  <h4 className="font-bold text-xs text-white">{m.name.split('(')[0]}</h4>
                  <p className="text-[10px] text-slate-400">
                    تشغيل: {m.totalRunHours} ساعة • توقف: {m.totalBreakdownHours} ساعة
                  </p>
                </div>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                    m.status === 'running'
                      ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                      : m.status === 'maintenance'
                      ? 'bg-amber-950 text-amber-400 border-amber-800'
                      : 'bg-rose-950 text-rose-400 border-rose-800'
                  }`}
                >
                  {m.status === 'running' ? 'تعمل الآن' : m.status === 'maintenance' ? 'صيانة' : 'جاهزة'}
                </span>
              </div>
            ))}
          </div>

          <div className="pt-2 border-t border-slate-800 flex justify-between text-xs text-slate-400">
            <span>الماكينات النشطة:</span>
            <span className="font-bold text-emerald-400">
              {activeMachines} من {machines.length} ماكينات
            </span>
          </div>
        </div>

        {/* Work Orders Progress */}
        <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Factory className="w-5 h-5 text-cyan-400" />
              <h3 className="font-bold text-sm text-white">أوامر الإنتاج والجودة (OEE)</h3>
            </div>
            <button
              onClick={() => setActiveModule('manufacturing')}
              className="text-xs text-cyan-400 hover:underline"
            >
              التفاصيل
            </button>
          </div>

          <div className="space-y-3">
            {productionOrders.slice(0, 3).map((o) => (
              <div
                key={o.id}
                className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2"
              >
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-white truncate max-w-[180px]">{o.productName}</span>
                  <span className="font-mono text-cyan-400 font-bold">{o.orderNumber}</span>
                </div>
                <div className="flex justify-between text-[11px] text-slate-400">
                  <span>مطلوب: {o.requiredQuantity} قطعة</span>
                  <span className="text-emerald-400 font-bold">مقبول: {o.acceptedQuantity} قطعة</span>
                  <span className="text-rose-400">مرفوض: {o.rejectedQuantity} قطعة</span>
                </div>
                {/* Progress bar */}
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-cyan-500 h-full rounded-full transition-all"
                    style={{
                      width: `${Math.min(
                        100,
                        (o.producedQuantity / (o.requiredQuantity || 1)) * 100
                      )}%`,
                    }}
                  ></div>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-2 border-t border-slate-800 flex justify-between text-xs text-slate-400">
            <span>منجز / قيد التشغيل:</span>
            <span className="font-bold text-white">
              {completedOrders} منجز • {inProgressOrders} جاري
            </span>
          </div>
        </div>

        {/* Cutting Tools & End Mills Alerts */}
        <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Scissors className="w-5 h-5 text-indigo-400" />
              <h3 className="font-bold text-sm text-white">أدوات القطع والـ End Mills</h3>
            </div>
            <button
              onClick={() => setActiveModule('cutting_tools')}
              className="text-xs text-indigo-400 hover:underline"
            >
              كشف العدد
            </button>
          </div>

          <div className="space-y-3">
            {cuttingTools.slice(0, 3).map((tool) => {
              const rem = Math.max(0, tool.expectedLifespanHours - tool.actualRunHours);
              return (
                <div
                  key={tool.id}
                  className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 flex justify-between items-center"
                >
                  <div>
                    <h5 className="font-bold text-xs text-white truncate max-w-[170px]">
                      {tool.name}
                    </h5>
                    <p className="text-[10px] text-slate-400 font-mono">
                      {tool.code} • {tool.size}
                    </p>
                  </div>
                  <div className="text-left font-mono">
                    <span className="text-xs font-bold text-indigo-300">{tool.actualRunHours} ساعة</span>
                    <span className="block text-[10px] text-slate-500">
                      متبقي {rem} ساعة
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="pt-2 border-t border-slate-800 flex justify-between text-xs text-slate-400">
            <span>إجمالي الأدوات النشطة:</span>
            <span className="font-bold text-indigo-400">
              {cuttingTools.filter((t) => t.status === 'active').length} أدوات قطع
            </span>
          </div>
        </div>
      </div>

      {/* Recent Central Journal Transactions Preview */}
      <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-blue-400" />
            <h3 className="font-bold text-sm text-white">
              آخر القيود المسجلة في الصفحة اليومية الموحدة (Live Journal Stream)
            </h3>
          </div>
          <button
            onClick={() => setActiveModule('journal')}
            className="text-xs text-blue-400 hover:underline font-semibold"
          >
            الانتقال لدفتر القيود الموحد الكامل ←
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-2.5">رقم القيد</th>
                <th className="py-2.5">التاريخ</th>
                <th className="py-2.5">البيان</th>
                <th className="py-2.5">المبلغ الإجمالي (جنيه مصري)</th>
                <th className="py-2.5">المرجع</th>
                <th className="py-2.5">الحالة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {journalEntries.slice(0, 4).map((entry) => (
                <tr key={entry.id} className="hover:bg-slate-800/30">
                  <td className="py-2.5 font-mono font-bold text-blue-400">{entry.entryNumber}</td>
                  <td className="py-2.5 text-slate-300">{entry.date}</td>
                  <td className="py-2.5 font-medium text-white max-w-sm truncate">{entry.description}</td>
                  <td className="py-2.5 font-mono font-bold text-emerald-400">
                    {entry.totalAmount.toLocaleString()} جنيه مصري
                  </td>
                  <td className="py-2.5 text-slate-400">{entry.referenceType || 'يدوي'}</td>
                  <td className="py-2.5">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                      مرحل آلياً
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
