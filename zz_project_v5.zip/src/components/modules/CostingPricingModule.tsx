/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  ArrowRight,
  Calculator,
  CheckCircle2,
  DollarSign,
  FileSpreadsheet,
  Info,
  Layers,
  Percent,
  Sparkles,
  TrendingUp,
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import * as XLSX from 'xlsx';

export const CostingPricingModule: React.FC = () => {
  const { boms, productionOrders } = useERP();

  // Interactive Pricing Engine State
  const [directMaterialCost, setDirectMaterialCost] = useState(650);
  const [directLaborCost, setDirectLaborCost] = useState(150);
  const [machineCost, setMachineCost] = useState(120);
  const [toolingWearCost, setToolingWearCost] = useState(50);
  const [scrapAllowanceCost, setScrapAllowanceCost] = useState(30);

  // Overheads & Markup
  const [adminSalesOverheadPercent, setAdminSalesOverheadPercent] = useState(10); // 10%
  const [targetMarginOnSellingPrice, setTargetMarginOnSellingPrice] = useState(20); // 20% Margin from Selling Price!
  const [salesTaxPercent, setSalesTaxPercent] = useState(14); // 14% VAT

  // Base Manufacturing Cost
  const totalDirectMfgCost =
    directMaterialCost +
    directLaborCost +
    machineCost +
    toolingWearCost +
    scrapAllowanceCost;

  // Total Cost including SG&A (Overheads)
  const totalCostWithOverheads =
    totalDirectMfgCost * (1 + adminSalesOverheadPercent / 100);

  // Calculation matching specification #18:
  // Selling Price = Total Cost / (1 - Margin%)
  // Example in spec: Cost 1,000 EGP, 20% Margin from selling price => 1,000 / (1 - 0.20) = 1,250 EGP!
  const marginDecimal = targetMarginOnSellingPrice / 100;
  const suggestedSellingPriceBeforeTax =
    marginDecimal < 1
      ? totalCostWithOverheads / (1 - marginDecimal)
      : totalCostWithOverheads * 2;

  const profitAmount = suggestedSellingPriceBeforeTax - totalCostWithOverheads;
  const markupOnCostPercent =
    totalCostWithOverheads > 0
      ? (profitAmount / totalCostWithOverheads) * 100
      : 0;

  const finalCustomerPriceWithTax =
    suggestedSellingPriceBeforeTax * (1 + salesTaxPercent / 100);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-l from-emerald-950/70 via-slate-900 to-slate-900 border border-emerald-800/40 shadow-xl">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="p-2 rounded-xl bg-emerald-600/20 text-emerald-400 border border-emerald-500/30">
                <Calculator className="w-6 h-6" />
              </span>
              <h2 className="text-xl font-bold text-white">
                محرك التكاليف الصناعية والتسعير وهامش الربح الحقيقي
              </h2>
            </div>
            <p className="text-xs text-slate-300 max-w-3xl leading-relaxed">
              وفقاً للبند 18: التمييز الهندسي الدقيق بين (هامش الربح من سعر البيع Profit Margin)
              و(الزيادة على التكلفة Markup on Cost). مثال البند 18 المعتمد: تكلفة 1,000 جنيه مصري مع هامش ربح
              20% من سعر البيع يعطي سعراً 1,250 جنيه مصري قبل الإضافات.
            </p>
          </div>
        </div>
      </div>

      {/* Interactive Pricing Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Input Parameters (Cost Components) */}
        <div className="lg:col-span-7 rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-5 shadow-xl">
          <h3 className="font-bold text-sm text-white flex items-center gap-2 border-b border-slate-800 pb-3">
            <Layers className="w-4 h-4 text-emerald-400" />
            <span>عناصر تكلفة القطعة الواحدة (Direct Manufacturing Costs)</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block text-slate-400 font-semibold mb-1">
                تكلفة الخامات المباشرة (جنيه مصري)
              </label>
              <input
                type="number"
                value={directMaterialCost}
                onChange={(e) => setDirectMaterialCost(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-emerald-400 font-mono font-bold focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-slate-400 font-semibold mb-1">
                تكلفة العمالة والأجور المباشرة (جنيه مصري)
              </label>
              <input
                type="number"
                value={directLaborCost}
                onChange={(e) => setDirectLaborCost(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono font-bold focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-slate-400 font-semibold mb-1">
                نصيب تشغيل الماكينة والكهرباء (جنيه مصري)
              </label>
              <input
                type="number"
                value={machineCost}
                onChange={(e) => setMachineCost(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono font-bold focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-slate-400 font-semibold mb-1">
                استهلاك أدوات القطع (End Mills) (جنيه مصري)
              </label>
              <input
                type="number"
                value={toolingWearCost}
                onChange={(e) => setToolingWearCost(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono font-bold focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-slate-400 font-semibold mb-1">
                مخصص الهالك الصناعي المخطط (جنيه مصري)
              </label>
              <input
                type="number"
                value={scrapAllowanceCost}
                onChange={(e) => setScrapAllowanceCost(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono font-bold focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-slate-400 font-semibold mb-1">
                مصاريف إدارية وبيعية عامة SG&A (%)
              </label>
              <input
                type="number"
                value={adminSalesOverheadPercent}
                onChange={(e) => setAdminSalesOverheadPercent(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono font-bold focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 grid grid-cols-2 gap-4">
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-[11px] text-slate-400">تكلفة التصنيع المباشرة:</span>
              <p className="font-mono text-lg font-bold text-white mt-0.5">
                {totalDirectMfgCost.toFixed(2)} جنيه مصري
              </p>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-[11px] text-slate-400">إجمالي التكلفة الكلية مع العمومية:</span>
              <p className="font-mono text-lg font-bold text-blue-400 mt-0.5">
                {totalCostWithOverheads.toFixed(2)} جنيه مصري
              </p>
            </div>
          </div>
        </div>

        {/* Pricing Results & Profit Margins (Formulas) */}
        <div className="lg:col-span-5 rounded-3xl border border-emerald-800/60 bg-gradient-to-b from-emerald-950/40 via-slate-900 to-slate-900 p-6 space-y-5 shadow-xl">
          <h3 className="font-bold text-sm text-emerald-300 flex items-center gap-2 border-b border-slate-800 pb-3">
            <Percent className="w-4 h-4 text-emerald-400" />
            <span>معادلة التسعير والأرباح المستهدفة</span>
          </h3>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span className="font-semibold">هامش الربح المطلوب من سعر البيع (%):</span>
                <span className="font-mono font-bold text-emerald-400">
                  {targetMarginOnSellingPrice}%
                </span>
              </div>
              <input
                type="range"
                min="5"
                max="60"
                step="1"
                value={targetMarginOnSellingPrice}
                onChange={(e) => setTargetMarginOnSellingPrice(parseInt(e.target.value) || 20)}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">سعر البيع المقترح قبل الضريبة:</span>
                <span className="font-mono text-xl font-bold text-emerald-400">
                  {suggestedSellingPriceBeforeTax.toFixed(2)} جنيه مصري
                </span>
              </div>

              <div className="flex justify-between items-center text-xs border-t border-slate-850 pt-2">
                <span className="text-slate-400">صافي ربح القطعة الواحدة:</span>
                <span className="font-mono font-bold text-white">
                  {profitAmount.toFixed(2)} جنيه مصري
                </span>
              </div>

              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">نسبة الزيادة على التكلفة (Markup):</span>
                <span className="font-mono font-bold text-cyan-400">
                  +{markupOnCostPercent.toFixed(1)}%
                </span>
              </div>

              <div className="flex justify-between items-center text-xs border-t border-slate-850 pt-2">
                <span className="text-slate-400">سعر البيع النهائي للعميل شامل ض.ق.م (14%):</span>
                <span className="font-mono text-base font-bold text-amber-300">
                  {finalCustomerPriceWithTax.toFixed(2)} جنيه مصري
                </span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-blue-950/40 border border-blue-800/40 text-[11px] text-blue-300 flex items-start gap-2">
              <Info className="w-4 h-4 shrink-0 mt-0.5 text-blue-400" />
              <span>
                <strong>التطابق مع معيار البند 18:</strong> عند إدخال تكلفة 1,000 جنيه مصري مع هامش 20%،
                تكون النتيجة المحتسبة بدقة هي 1,250 جنيهاً مصرياً (1000 ÷ 0.8 = 1250 جنيه مصري).
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
