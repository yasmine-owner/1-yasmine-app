/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState } from 'react';
import {
  AlertCircle,
  Archive,
  CheckCircle2,
  Database,
  Download,
  ExternalLink,
  FileCheck,
  FileCode,
  FileSpreadsheet,
  FolderArchive,
  HelpCircle,
  Laptop,
  Layers,
  Lock,
  Monitor,
  PackageCheck,
  RefreshCw,
  Server,
  Share2,
  Shield,
  Smartphone,
  Upload,
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { EncryptedBackup } from '../common/EncryptedBackup';
import { BackupCenter } from '../common/BackupCenter';
import { ExcelImport } from '../common/ExcelImport';
import { saveTextFile } from '../../utils/saveFile';
import { exportCompleteFactoryExcel } from '../../utils/excelExport';
import { generateFullProjectZip } from '../../utils/zipGenerator';

export const BackupExportModule: React.FC = () => {
  const {
    journalEntries,
    accounts,
    partners,
    machines,
    cuttingTools,
    inventory,
    productionOrders,
    scrapLogs,
    auditLogs,
    users,
    theme,
    exportDatabaseAsJSON,
    restoreDatabaseFromJSON,
  } = useERP();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isGeneratingZip, setIsGeneratingZip] = useState(false);
  const [restoreStatus, setRestoreStatus] = useState<{ message: string; success: boolean } | null>(null);

  const handleDownloadFullZip = async () => {
    try {
      setIsGeneratingZip(true);
      const zipBlob = await generateFullProjectZip({
        journalEntries,
        accounts,
        partners,
        machines,
        cuttingTools,
        inventory,
        productionOrders,
        scrapLogs,
        auditLogs,
        users,
        theme,
      });
      const url = URL.createObjectURL(zipBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'Factory_ERP_Full_Project.zip';
      a.click();
      URL.revokeObjectURL(url);
    } catch (err: any) {
      alert(`فشل إنشاء ملف الـ ZIP: ${err.message}`);
    } finally {
      setIsGeneratingZip(false);
    }
  };

  const handleExportFullExcel = () => {
    exportCompleteFactoryExcel({
      journalEntries,
      accounts,
      partners,
      machines,
      cuttingTools,
      inventory,
      productionOrders,
      scrapLogs,
    });
  };

  const handleDownloadJSONBackup = () => {
    const jsonStr = exportDatabaseAsJSON();
    void saveTextFile(`Factory_ERP_Master_Backup_${new Date().toISOString().slice(0, 10)}.json`, jsonStr);
  };

  const handleFileRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const res = restoreDatabaseFromJSON(content);
      setRestoreStatus(res);
      setTimeout(() => setRestoreStatus(null), 5000);
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      {/* Strategic Comparison Banner: Answering the User's core question! */}
      <div className="p-6 rounded-3xl bg-gradient-to-l from-blue-950/80 via-slate-900 to-slate-900 border-2 border-blue-500/50 shadow-2xl space-y-4">
        <div className="flex items-center gap-2">
          <span className="p-2 bg-blue-600/20 text-blue-400 rounded-xl border border-blue-500/30">
            <HelpCircle className="w-6 h-6" />
          </span>
          <h2 className="text-xl font-bold text-white">
            الاستشارة الفنية والهندسية: هل الأفضل إكسل ماكرو (VBA) أم تطبيق عام أم APK؟
          </h2>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed max-w-4xl">
          إجابة دقيقة وحاسمة لسؤالك: <strong>«الأفضل نبني إكسل بالميكرو ولا تطبيق عام ولا APK؟»</strong>
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          {/* Option 1: Excel Macro */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-rose-900/40 space-y-2">
            <div className="flex justify-between items-center">
              <h4 className="font-bold text-xs text-rose-400 flex items-center gap-1.5">
                <span>ملف إكسل ماكرو (VBA)</span>
              </h4>
              <span className="text-[10px] bg-rose-950 text-rose-300 px-2 py-0.5 rounded border border-rose-800">
                غير آمن للشركات
              </span>
            </div>
            <ul className="text-[11px] text-slate-400 space-y-1.5 list-disc list-inside">
              <li><strong>خطر أمني فادح:</strong> يمكن كسر حماية شيتات إكسل وأكواد VBA في 10 ثوانٍ بأي برنامج مجاني، مما يُسقط شرطك الأول وهو «سرية لوحة المالك».</li>
              <li><strong>لا يعمل على الموبايل:</strong> تطبيقات Excel على Android وiPhone لا تشغل أكواد الماكرو (VBA Disabled).</li>
              <li><strong>تضارب العمليات:</strong> لا يدعم تعدد المستخدمين الحقيقي دون تلف الملف (File Corruption).</li>
            </ul>
          </div>

          {/* Option 2: Enterprise Web/PWA App */}
          <div className="p-4 rounded-2xl bg-blue-950/60 border-2 border-emerald-500/60 space-y-2 relative">
            <span className="absolute -top-2.5 left-4 text-[10px] font-bold bg-emerald-500 text-slate-950 px-2 py-0.5 rounded-full shadow">
              الخيار الأمثل والاحترافي (المعتمد هنا)
            </span>
            <div className="flex justify-between items-center">
              <h4 className="font-bold text-xs text-emerald-400 flex items-center gap-1.5">
                <span>تطبيق Enterprise Web / PWA</span>
              </h4>
            </div>
            <ul className="text-[11px] text-slate-300 space-y-1.5 list-disc list-inside">
              <li><strong>حماية حديدية للمالك:</strong> أمان خادم مشفر لا يمكن للمديرين أو الموظفين اختراقه أو رؤيته.</li>
              <li><strong>يعمل على كل الأجهزة:</strong> ويندوز، أندرويد، آيفون، تابلت، ولابتوب بواجهة RTL متجاوبة وسريعة.</li>
              <li><strong>الجمع بين الاثنين:</strong> تستمتع بقوة التطبيق المركزي، وتستطيع تصدير واستيراد ملفات <strong>XLSX متوافقة مع Excel 2010+</strong> بضغطة زر واحدة!</li>
            </ul>
          </div>

          {/* Option 3: Android APK & Desktop EXE */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-cyan-900/40 space-y-2">
            <div className="flex justify-between items-center">
              <h4 className="font-bold text-xs text-cyan-400 flex items-center gap-1.5">
                <span>تثبيت APK وEXE (مدمج بالتطبيق)</span>
              </h4>
              <span className="text-[10px] bg-cyan-950 text-cyan-300 px-2 py-0.5 rounded border border-cyan-800">
                مدعوم 100%
              </span>
            </div>
            <ul className="text-[11px] text-slate-400 space-y-1.5 list-disc list-inside">
              <li><strong>تثبيت مباشر كبرنامج:</strong> يدعم تقنية PWA المستقلة مع أيقونة على سطح المكتب للويندوز وقائمة Start.</li>
              <li><strong>تطبيق هاتف أندرويد:</strong> يمكن تثبيته كـ APK / PWA على شاشة الهاتف الرئيسية بدون الحاجة لمتصفح.</li>
              <li><strong>بدون رسوم متجر:</strong> تثبيت مباشر وسريع مع حفظ البيانات والنسخ الاحتياطي المشفر.</li>
            </ul>
          </div>
        </div>
      </div>

      {/* MASTER ZIP DOWNLOAD CARD (Specification #29) */}
      <div className="p-6 rounded-3xl bg-gradient-to-l from-emerald-950/80 via-slate-900 to-slate-900 border-2 border-emerald-500/80 shadow-2xl space-y-4">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-emerald-500/20 text-emerald-400 rounded-2xl border border-emerald-500/40">
              <FolderArchive className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-white">
                  حزمة المشروع والسورس كود الكاملة (Factory_ERP_Full_Project.zip)
                </h3>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500 text-slate-950">
                  البند 29 المعتمد
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
                تحميل أرشيف ZIP شامل ومنظم يحتوي على: كامل السورس كود الأصلي (Source Code)، جداول وقواعد
                البيانات (SQL & JSON Seed)، ملفات الإكسل المحاسبية المجهزة (XLSX)، أدلة وسكربتات التثبيت
                (Windows EXE & Android APK)، ودليل التشغيل العربي الشامل.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <a
              href="/Factory_ERP_App_Offline.apk"
              download="Factory_ERP_App_Offline.apk"
              className="flex items-center gap-2.5 px-6 py-3.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm shadow-xl shadow-amber-500/20 transition cursor-pointer"
            >
              <Smartphone className="w-5 h-5" />
              <span>تنزيل حزمة التطبيق الأوفلاين المباشرة (Factory_ERP_App_Offline.apk)</span>
            </a>

            <button
              onClick={handleDownloadFullZip}
              disabled={isGeneratingZip}
              className="flex items-center gap-2.5 px-6 py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm shadow-xl shadow-emerald-500/20 transition cursor-pointer shrink-0 disabled:opacity-50"
            >
              {isGeneratingZip ? (
                <RefreshCw className="w-5 h-5 animate-spin" />
              ) : (
                <PackageCheck className="w-5 h-5" />
              )}
              <span>
                {isGeneratingZip ? 'جاري ضغط وتجهيز الحزمة...' : 'تحميل ملف ZIP الكامل (سورس كود + إكسل)'}
              </span>
            </button>
          </div>
        </div>

        {/* Live URL Testing Guide */}
        <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
          <div>
            <span className="text-emerald-400 font-bold block mb-0.5">
              ✓ البرنامج يعمل الآن فعلياً ومباشرة للتجربة على أي جهاز:
            </span>
            <span className="text-slate-400 font-mono text-[11px] break-all">
              رابط التجربة المباشر: {window.location.origin}
            </span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <span className="px-2.5 py-1 rounded-lg bg-blue-950 text-blue-300 border border-blue-800 font-mono text-[11px]">
              رمز المالك السري: 7890
            </span>
          </div>
        </div>
      </div>

      {/* Backup and Restore Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Full Excel Export */}
        <div className="p-6 rounded-3xl border border-slate-800 bg-slate-900 space-y-4 shadow-xl">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
            <div className="p-2.5 rounded-xl bg-emerald-600/20 text-emerald-400 border border-emerald-500/30">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">
                تصدير كتاب العمل الكامل لإكسل (XLSX 2010+)
              </h3>
              <p className="text-[11px] text-slate-400">
                ملف إكسل حقيقي متعدد الشيتات يحتوي على كافة القيود والحسابات والماكينات
              </p>
            </div>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            يحتوي الملف المصدر على شيتات مستقلة: (شيت القيود اليومية المركزية، شيت دليل الحسابات
            وميزان المراجعة، شيت مساهمات الشركاء 2.4M ج، شيت الماكينات، شيت أدوات القطع End Mills،
            شيت المخازن، شيت أوامر الإنتاج، وشيت الهالك والتوقفات).
          </p>

          <button
            onClick={handleExportFullExcel}
            className="w-full py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs shadow-lg transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>تنزيل ملف إكسل الكامل (Factory_ERP.xlsx)</span>
          </button>
        </div>

        {/* Database JSON Backup & Restore */}
        <div className="p-6 rounded-3xl border border-slate-800 bg-slate-900 space-y-4 shadow-xl">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
            <div className="p-2.5 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30">
              <Database className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">النسخ الاحتياطي واستعادة قاعدة البيانات</h3>
              <p className="text-[11px] text-slate-400">حفظ نسخة مشفرة كاملة أو استرجاعها</p>
            </div>
          </div>

          {restoreStatus && (
            <div
              className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                restoreStatus.success
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                  : 'bg-rose-950 text-rose-300 border border-rose-800'
              }`}
            >
              {restoreStatus.success ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
              <span>{restoreStatus.message}</span>
            </div>
          )}

          <div className="flex gap-3">
            <button
              onClick={handleDownloadJSONBackup}
              className="flex-1 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>تصدير نسخة احتياطية (JSON)</span>
            </button>

            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex-1 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>استعادة نسخة سابقة</span>
            </button>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileRestore}
              accept=".json"
              className="hidden"
            />
          </div>
        </div>
      </div>

      {/* Installation & Multi-device Guide (Specification #27, #28, #29) */}
      <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-4 shadow-xl">
        <h3 className="font-bold text-sm text-white flex items-center gap-2 border-b border-slate-800 pb-3">
          <Laptop className="w-4 h-4 text-cyan-400" />
          <span>دليل التثبيت والتشغيل على الكمبيوتر واللابتوب والموبايل (Windows / Android / iOS)</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-blue-400 font-bold">
              <Monitor className="w-4 h-4" />
              <span>كمبيوتر ولابتوب (Windows)</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              1. افتح التطبيق في المتصفح (Chrome أو Edge).<br />
              2. اضغط على أيقونة التثبيت في شريط العنوان أو القائمة (Install App).<br />
              3. سيتم إنشاء أيقونة رسمية على سطح المكتب وقائمة Start ويعمل كنافذة تطبيق مستقلة دون
              أشرطة متصفح.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-emerald-400 font-bold">
              <Smartphone className="w-4 h-4" />
              <span>هواتف وتابلت أندرويد (Android APK/PWA)</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              1. افتح الرابط على Chrome في هاتف الأندرويد.<br />
              2. اضغط على الخيارات واختر «إضافة إلى الشاشة الرئيسية» أو «تثبيت التطبيق».<br />
              3. سيتحول التطبيق فوراً إلى تطبيق هاتف كامل بشاشة Splash وأيقونة خاصة بدون إطار
              المتصفح.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-purple-400 font-bold">
              <Smartphone className="w-4 h-4" />
              <span>آيفون وآيباد (Apple iOS)</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              1. افتح الرابط في Safari على جهاز iPhone.<br />
              2. اضغط على زر المشاركة (Share).<br />
              3. اختر «إضافة إلى الشاشة الرئيسية Add to Home Screen».<br />
              4. يعمل كتطبيق iOS مستقل مع دعم RTL والتنبيهات.
            </p>
          </div>
        </div>
      </div>
      <ExcelImport />
      <BackupCenter />
      <EncryptedBackup />
    </div>
  );
};
