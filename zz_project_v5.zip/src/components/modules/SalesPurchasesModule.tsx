/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  ArrowDownLeft,
  ArrowUpRight,
  CheckCircle2,
  FileSpreadsheet,
  Plus,
  Search,
  ShoppingCart,
  Truck,
  Users,
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';

export const SalesPurchasesModule: React.FC = () => {
  const { addJournalEntry, accounts } = useERP();
  const [activeTab, setActiveTab] = useState<'sales' | 'purchases' | 'clients'>('sales');
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);

  // Form State
  const [invoiceType, setInvoiceType] = useState<'sale' | 'purchase'>('sale');
  const [clientOrSupplierName, setClientOrSupplierName] = useState('');
  const [totalAmount, setTotalAmount] = useState(0);
  const [cashPaid, setCashPaid] = useState(0);
  const [invNotes, setInvNotes] = useState('');

  const handleCreateInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    if (totalAmount <= 0) return;

    const remainingOnCredit = Math.max(0, totalAmount - cashPaid);

    if (invoiceType === 'sale') {
      // Sale: Cash (Debit) + Accounts Receivable (Debit) = Sales Revenue (Credit)
      const lines: any[] = [];
      if (cashPaid > 0) {
        lines.push({ accountId: 'acc-111', accountCode: '1110', accountName: 'الخزينة الرئيسية (النقدية)', debit: cashPaid, credit: 0, note: 'دفعة نقدية مسددة' });
      }
      if (remainingOnCredit > 0) {
        lines.push({ accountId: 'acc-113', accountCode: '1130', accountName: 'العملاء وحسابات القبض', debit: remainingOnCredit, credit: 0, note: `مستحق على العميل ${clientOrSupplierName}` });
      }
      lines.push({ accountId: 'acc-41', accountCode: '4100', accountName: 'مبيعات المنتجات المصنعة', debit: 0, credit: totalAmount, note: `فاتورة مبيعات: ${invNotes}` });

      addJournalEntry({
        date: new Date().toISOString().slice(0, 10),
        description: `فاتورة مبيعات للعميل (${clientOrSupplierName}) بمبلغ ${totalAmount.toLocaleString()} جنيه مصري`,
        referenceType: 'sales',
        lines,
      });
    } else {
      // Purchase: Inventory/Raw Materials (Debit) = Cash/Bank (Credit) + Accounts Payable (Credit)
      const lines: any[] = [];
      lines.push({ accountId: 'acc-114', accountCode: '1140', accountName: 'مخزون الخامات ومستلزمات الإنتاج', debit: totalAmount, credit: 0, note: `فاتورة مشتريات: ${invNotes}` });
      if (cashPaid > 0) {
        lines.push({ accountId: 'acc-112', accountCode: '1120', accountName: 'البنك الأهلي المصري - جاري', debit: 0, credit: cashPaid, note: 'دفعة بنكية مسددة للمورد' });
      }
      if (remainingOnCredit > 0) {
        lines.push({ accountId: 'acc-21', accountCode: '2100', accountName: 'الموردون وأوراق الدفع', debit: 0, credit: remainingOnCredit, note: `مستحق للمورد ${clientOrSupplierName}` });
      }

      addJournalEntry({
        date: new Date().toISOString().slice(0, 10),
        description: `فاتورة مشتريات خامات من المورد (${clientOrSupplierName}) بمبلغ ${totalAmount.toLocaleString()} جنيه مصري`,
        referenceType: 'purchase',
        lines,
      });
    }

    setShowInvoiceModal(false);
  };

  const demoClients = [
    { name: 'مستشفى السلام التخصصي لجراحة العظام', type: 'عميل', balance: 0, creditLimit: 300000, phone: '0100223344' },
    { name: 'مركز الأمل للشرائح والمسامير الطبية', type: 'عميل', balance: 0, creditLimit: 200000, phone: '0122334455' },
    { name: 'المصرية الدولية لتوريد التيتانيوم الطبي (Ti-6Al-4V)', type: 'مورد', balance: 0, creditLimit: 500000, phone: '0111222333' },
    { name: 'تكنوميديكال لعدد قطع وتفريز المستلزمات الطبية', type: 'مورد', balance: 0, creditLimit: 250000, phone: '0100998877' },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-l from-slate-900 via-slate-900 to-blue-950/40 border border-slate-800 shadow-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="p-2 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30">
              <ShoppingCart className="w-6 h-6" />
            </span>
            <h2 className="text-xl font-bold text-white">
              إدارة المبيعات والمشتريات والعملاء والموردين
            </h2>
          </div>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            فواتير بيع المشغولات وخدمات التشغيل، فواتير شراء الخامات والصلب وأدوات القطع، مع
            التوليد التلقائي لقيود اليومية المركزية المتوازنة فور إصدار الفاتورة.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setInvoiceType('sale');
              setShowInvoiceModal(true);
            }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>فاتورة مبيعات جديدة</span>
          </button>
          <button
            onClick={() => {
              setInvoiceType('purchase');
              setShowInvoiceModal(true);
            }}
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition cursor-pointer"
          >
            <Truck className="w-4 h-4 text-amber-400" />
            <span>فاتورة مشتريات خامات</span>
          </button>
        </div>
      </div>

      {/* Clients & Suppliers Directory */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 overflow-hidden shadow-xl">
        <div className="p-4 border-b border-slate-800 flex justify-between items-center">
          <h3 className="font-bold text-sm text-white flex items-center gap-2">
            <Users className="w-4 h-4 text-blue-400" />
            <span>دليل حسابات العملاء والموردين وحدود الائتمان</span>
          </h3>
        </div>

        <table className="w-full text-right text-xs">
          <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
            <tr>
              <th className="p-3.5">اسم الجهة / الشركة</th>
              <th className="p-3.5">النوع</th>
              <th className="p-3.5">الرصيد المالي الحالي (جنيه مصري)</th>
              <th className="p-3.5">حد الائتمان المصرح به</th>
              <th className="p-3.5">رقم الهاتف والتواصل</th>
              <th className="p-3.5 text-center">المركز الائتماني</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {demoClients.map((c, i) => (
              <tr key={i} className="hover:bg-slate-800/40 transition">
                <td className="p-3.5 font-bold text-white">{c.name}</td>
                <td className="p-3.5">
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                      c.type === 'عميل'
                        ? 'bg-blue-950 text-blue-400 border-blue-800'
                        : 'bg-amber-950 text-amber-400 border-amber-800'
                    }`}
                  >
                    {c.type}
                  </span>
                </td>
                <td className="p-3.5 font-mono font-bold text-slate-100 text-sm">
                  {c.balance.toLocaleString()} جنيه مصري
                </td>
                <td className="p-3.5 font-mono text-slate-400">
                  {c.creditLimit.toLocaleString()} جنيه مصري
                </td>
                <td className="p-3.5 font-mono text-slate-400">{c.phone}</td>
                <td className="p-3.5 text-center">
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                    ضمن الحدود الآمنة
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Invoice Modal */}
      {showInvoiceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-6 text-white shadow-2xl">
            <h3 className="text-base font-bold text-white mb-2">
              {invoiceType === 'sale' ? 'إصدار فاتورة مبيعات جديدة' : 'تسجيل فاتورة مشتريات خامات'}
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              سيتم ترحيل القيد المزدوج المتوازن تلقائياً إلى صفحة القيود اليومية المركزية والحسابات.
            </p>

            <form onSubmit={handleCreateInvoice} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">
                  {invoiceType === 'sale' ? 'اسم العميل' : 'اسم المورد'}
                </label>
                <input
                  type="text"
                  value={clientOrSupplierName}
                  onChange={(e) => setClientOrSupplierName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">
                    إجمالي الفاتورة (جنيه مصري)
                  </label>
                  <input
                    type="number"
                    value={totalAmount}
                    onChange={(e) => setTotalAmount(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono font-bold focus:outline-none focus:border-blue-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">
                    الدفعة المسددة فوراً (جنيه مصري)
                  </label>
                  <input
                    type="number"
                    value={cashPaid}
                    onChange={(e) => setCashPaid(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">بيان الأصناف والخدمات</label>
                <input
                  type="text"
                  value={invNotes}
                  onChange={(e) => setInvNotes(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowInvoiceModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold transition shadow-lg cursor-pointer"
                >
                  حفظ الفاتورة والترحيل
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
