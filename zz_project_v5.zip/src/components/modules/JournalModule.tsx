/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  AlertCircle,
  ArrowDownLeft,
  ArrowUpRight,
  BookOpen,
  Calendar,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Download,
  FileSpreadsheet,
  Filter,
  Plus,
  Printer,
  RefreshCcw,
  Search,
  Trash2,
  Undo2,
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { QuickEntry } from '../common/QuickEntry';
import * as XLSX from 'xlsx';

export const JournalModule: React.FC = () => {
  const {
    journalEntries,
    accounts,
    addJournalEntry,
    reverseJournalEntry,
    currentUser,
  } = useERP();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [expandedEntryId, setExpandedEntryId] = useState<string | null>(null);

  // New Entry Modal State
  const [showAddModal, setShowAddModal] = useState(false);
  const [entryDate, setEntryDate] = useState(new Date().toISOString().slice(0, 10));
  const [entryDescription, setEntryDescription] = useState('');
  const [referenceType, setReferenceType] = useState<any>('manual');
  const [lines, setLines] = useState<
    { accountId: string; accountCode: string; accountName: string; debit: number; credit: number; note: string }[]
  >([
    { accountId: '', accountCode: '', accountName: '', debit: 0, credit: 0, note: '' },
    { accountId: '', accountCode: '', accountName: '', debit: 0, credit: 0, note: '' },
  ]);

  // Reverse Entry Modal State
  const [showReverseModal, setShowReverseModal] = useState(false);
  const [reversingTargetId, setReversingTargetId] = useState('');
  const [reverseReason, setReverseReason] = useState('');

  // Toast / notification
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  // Calculations for the new entry
  const totalDebit = lines.reduce((acc, l) => acc + (Number(l.debit) || 0), 0);
  const totalCredit = lines.reduce((acc, l) => acc + (Number(l.credit) || 0), 0);
  const diff = Math.abs(totalDebit - totalCredit);
  const isBalanced = diff < 0.01 && totalDebit > 0;

  const handleAccountSelect = (lineIdx: number, accountId: string) => {
    const acc = accounts.find((a) => a.id === accountId);
    if (acc) {
      const updated = [...lines];
      updated[lineIdx] = {
        ...updated[lineIdx],
        accountId: acc.id,
        accountCode: acc.code,
        accountName: acc.name,
      };
      setLines(updated);
    }
  };

  const handleLineChange = (lineIdx: number, field: string, val: any) => {
    const updated = [...lines];
    updated[lineIdx] = { ...updated[lineIdx], [field]: val };
    setLines(updated);
  };

  const addLine = () => {
    setLines([...lines, { accountId: '', accountCode: '', accountName: '', debit: 0, credit: 0, note: '' }]);
  };

  const removeLine = (idx: number) => {
    if (lines.length <= 2) {
      showToast('يجب أن يحتوي القيد المحاسبي على سطرين على الأقل (طرف مدين وطرف دائن)!', 'error');
      return;
    }
    setLines(lines.filter((_, i) => i !== idx));
  };

  const handleSubmitNewEntry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isBalanced) {
      showToast('لا يمكن حفظ القيد! القيد غير متوازن بين المدين والدائن.', 'error');
      return;
    }
    if (!entryDescription.trim()) {
      showToast('يرجى كتابة شرح وبيان القيد المحاسبي.', 'error');
      return;
    }

    // Check that every line has an account
    for (let i = 0; i < lines.length; i++) {
      if (!lines[i].accountId) {
        showToast(`يرجى تحديد الحساب للسطر رقم ${i + 1}`, 'error');
        return;
      }
    }

    const res = addJournalEntry({
      date: entryDate,
      description: entryDescription,
      referenceType,
      lines,
    });

    if (res.success) {
      showToast(res.message, 'success');
      setShowAddModal(false);
      setEntryDescription('');
      setLines([
        { accountId: '', accountCode: '', accountName: '', debit: 0, credit: 0, note: '' },
        { accountId: '', accountCode: '', accountName: '', debit: 0, credit: 0, note: '' },
      ]);
    } else {
      showToast(res.message, 'error');
    }
  };

  const handleConfirmReverse = () => {
    if (!reverseReason.trim()) {
      showToast('يرجى كتابة سبب إنشاء القيد العكسي للتوثيق المحاسبي.', 'error');
      return;
    }
    const res = reverseJournalEntry(reversingTargetId, reverseReason);
    if (res.success) {
      showToast(res.message, 'success');
      setShowReverseModal(false);
      setReverseReason('');
      setReversingTargetId('');
    } else {
      showToast(res.message, 'error');
    }
  };

  const exportJournalToExcel = () => {
    const rows: any[] = [];
    filteredEntries.forEach((entry) => {
      entry.lines.forEach((l, idx) => {
        rows.push({
          'رقم القيد': entry.entryNumber,
          'التاريخ': entry.date,
          'البيان': entry.description,
          'سطر': idx + 1,
          'كود الحساب': l.accountCode,
          'اسم الحساب': l.accountName,
          'مدين': l.debit,
          'دائن': l.credit,
          'ملاحظة': l.note,
          'المرجع': entry.referenceType,
          'الحالة': entry.isReversed ? 'معكوس' : 'مرحل',
          'المنشئ': entry.createdBy,
        });
      });
    });
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'القيود اليومية المركزية');
    XLSX.writeFile(wb, `Central_Journal_Entries_${new Date().toISOString().slice(0, 10)}.xlsx`);
    showToast('تم تصدير ملف القيود اليومية بنجاح بصيغة XLSX متوافقة مع Excel 2010+!', 'success');
  };

  // Filtered Entries
  const filteredEntries = journalEntries.filter((entry) => {
    const matchesSearch =
      entry.entryNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.lines.some((l) => l.accountName.toLowerCase().includes(searchTerm.toLowerCase()) || l.accountCode.includes(searchTerm));
    const matchesType = filterType === 'all' || entry.referenceType === filterType;
    return matchesSearch && matchesType;
  });

  const grandTotalJournalAmount = journalEntries.reduce((sum, e) => sum + e.totalAmount, 0);

  return (
    <div className="space-y-6">
      <QuickEntry />
      {/* Toast Alert */}
      {toast && (
        <div
          className={`fixed bottom-6 left-6 z-50 p-4 rounded-xl shadow-2xl flex items-center gap-3 border text-sm max-w-md animate-in slide-in-from-bottom ${
            toast.type === 'success'
              ? 'bg-emerald-950/90 text-emerald-200 border-emerald-500'
              : 'bg-rose-950/90 text-rose-200 border-rose-500'
          }`}
        >
          {toast.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
          )}
          <span>{toast.message}</span>
        </div>
      )}

      {/* Hero Banner explaining the single unified journal */}
      <div className="relative overflow-hidden p-6 rounded-3xl bg-gradient-to-l from-blue-900/60 via-slate-900 to-slate-900 border border-blue-800/40 shadow-xl">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="p-2 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30">
                <BookOpen className="w-6 h-6" />
              </span>
              <h2 className="text-xl font-bold text-white">
                شاشة القيود اليومية المركزية الموحدة (Central Journal Hub)
              </h2>
            </div>
            <p className="text-xs text-slate-300 max-w-3xl leading-relaxed">
              هنا يتم تسجيل كافة المعاملات المالية (مبيعات، مشتريات، تصنيع، تكاليف، خزينة، أصول،
              مساهمات الشركاء) في صفحة واحدة مركزية كما طلبت. ومن هذا السجل المركزي يتم الترحيل
              التلقائي واللحظي لكافة الحسابات والأستاذ العام وميزان المراجعة والأرباح والخسائر والمركز
              المالي دون أي تدخل يدوي!
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/30 transition cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>تسجيل قيد يومية جديد</span>
            </button>
            <button
              onClick={exportJournalToExcel}
              className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              <span>تصدير إكسل XLSX</span>
            </button>
            <button
              onClick={() => window.print()}
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition cursor-pointer no-print"
              title="طباعة الدفتر"
            >
              <Printer className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-slate-800/80">
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-[11px] text-slate-400">إجمالي القيود المسجلة</span>
            <p className="text-lg font-bold text-white mt-0.5">{journalEntries.length} قيد</p>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-[11px] text-slate-400">حجم العمليات المحاسبية</span>
            <p className="text-lg font-bold text-emerald-400 mt-0.5">
              {grandTotalJournalAmount.toLocaleString()} جنيه مصري
            </p>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-[11px] text-slate-400">حالة الترحيل للحسابات</span>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              <p className="text-xs font-bold text-slate-200">مرحلة تلقائياً 100%</p>
            </div>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-[11px] text-slate-400">توازن الدفتر المحاسبي</span>
            <div className="flex items-center gap-1.5 mt-0.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />
              <p className="text-xs font-bold text-blue-300">متوازن (Double-Entry)</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 rounded-2xl bg-slate-900 border border-slate-800">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute right-3 top-3 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="ابحث برقم القيد، البيان، اسم الحساب، أو الكود..."
            className="w-full pl-3 pr-9 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-4 h-4 text-slate-400" />
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-blue-500"
          >
            <option value="all">كل المراجع والعمليات</option>
            <option value="capital">مساهمات ورؤوس أموال الشركاء</option>
            <option value="sales">المبيعات والعملاء</option>
            <option value="purchase">المشتريات والموردين</option>
            <option value="production">تكاليف التصنيع والتشغيل</option>
            <option value="manual">قيود يدوية وتسويات</option>
          </select>
        </div>
      </div>

      {/* Central Journal Entries Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-950/80 text-slate-400 font-semibold border-b border-slate-800">
              <tr>
                <th className="p-3.5">رقم القيد</th>
                <th className="p-3.5">التاريخ</th>
                <th className="p-3.5">البيان والشرح المحاسبي</th>
                <th className="p-3.5">نوع المرجع</th>
                <th className="p-3.5">إجمالي المبلغ (جنيه مصري)</th>
                <th className="p-3.5">بواسطة</th>
                <th className="p-3.5">الحالة</th>
                <th className="p-3.5 text-center">التفاصيل والخيارات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredEntries.map((entry) => {
                const isExpanded = expandedEntryId === entry.id;

                return (
                  <React.Fragment key={entry.id}>
                    <tr
                      className={`hover:bg-slate-800/40 transition cursor-pointer ${
                        entry.isReversed ? 'opacity-60 bg-rose-950/10' : ''
                      }`}
                      onClick={() => setExpandedEntryId(isExpanded ? null : entry.id)}
                    >
                      <td className="p-3.5 font-mono font-bold text-blue-400">
                        {entry.entryNumber}
                      </td>
                      <td className="p-3.5 text-slate-300">{entry.date}</td>
                      <td className="p-3.5 font-medium text-white max-w-md truncate">
                        {entry.description}
                      </td>
                      <td className="p-3.5">
                        <span className="px-2 py-0.5 rounded-full text-[10px] bg-slate-800 text-slate-300 border border-slate-700 font-medium">
                          {entry.referenceType === 'capital'
                            ? 'مساهمات الشركاء'
                            : entry.referenceType === 'sales'
                            ? 'مبيعات'
                            : entry.referenceType === 'purchase'
                            ? 'مشتريات'
                            : entry.referenceType === 'production'
                            ? 'تصنيع'
                            : 'تسوية يدوية'}
                        </span>
                      </td>
                      <td className="p-3.5 font-mono font-bold text-emerald-400">
                        {entry.totalAmount.toLocaleString()} جنيه مصري
                      </td>
                      <td className="p-3.5 text-slate-400">{entry.createdBy}</td>
                      <td className="p-3.5">
                        {entry.isReversed ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-950/60 text-rose-400 border border-rose-800/50">
                            معكوس (Reversed)
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950/60 text-emerald-400 border border-emerald-800/50">
                            مرحل آلياً للأستاذ
                          </span>
                        )}
                      </td>
                      <td className="p-3.5 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setExpandedEntryId(isExpanded ? null : entry.id);
                            }}
                            className="p-1 rounded text-slate-400 hover:text-white"
                          >
                            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          </button>
                          {!entry.isReversed && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setReversingTargetId(entry.id);
                                setShowReverseModal(true);
                              }}
                              title="إنشاء قيد عكسي معتمد لإلغاء هذا القيد تدقيقياً"
                              className="px-2 py-1 rounded-md text-[11px] font-medium bg-rose-950/50 text-rose-300 border border-rose-900/50 hover:bg-rose-900/50 transition cursor-pointer"
                            >
                              قيد عكسي
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>

                    {/* Expanded Detail Lines */}
                    {isExpanded && (
                      <tr className="bg-slate-950/90">
                        <td colSpan={8} className="p-4 border-t border-b border-blue-900/40">
                          <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 space-y-3">
                            <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800">
                              <span className="font-bold text-blue-400">
                                أطراف القيد المحاسبي المتوازن (مدين ودائن وملاحظات الحسابات)
                              </span>
                              <span className="text-slate-400">
                                توقيت التسجيل: {entry.createdAt}
                              </span>
                            </div>

                            <table className="w-full text-right text-xs">
                              <thead className="text-slate-400 border-b border-slate-800">
                                <tr>
                                  <th className="py-2">كود الحساب</th>
                                  <th className="py-2">اسم الحساب في دليل الحسابات</th>
                                  <th className="py-2">مدين (منه) - جنيه مصري</th>
                                  <th className="py-2">دائن (له) - جنيه مصري</th>
                                  <th className="py-2">شرح وبيان السطر</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-800/40">
                                {entry.lines.map((l, lIdx) => (
                                  <tr key={lIdx} className="hover:bg-slate-800/30">
                                    <td className="py-2 font-mono text-slate-300">{l.accountCode}</td>
                                    <td className="py-2 font-semibold text-white">{l.accountName}</td>
                                    <td className="py-2 font-mono text-emerald-400 font-bold">
                                      {l.debit > 0 ? `${l.debit.toLocaleString()} جنيه مصري` : '-'}
                                    </td>
                                    <td className="py-2 font-mono text-cyan-400 font-bold">
                                      {l.credit > 0 ? `${l.credit.toLocaleString()} جنيه مصري` : '-'}
                                    </td>
                                    <td className="py-2 text-slate-400">{l.note || '-'}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Journal Entry Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-4xl w-full p-6 text-white shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <BookOpen className="w-6 h-6 text-blue-400" />
                <h3 className="text-base font-bold">
                  تسجيل قيد يومية جديد (ترحيل تلقائي لكافة الحسابات)
                </h3>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white p-1 text-lg"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitNewEntry} className="mt-5 space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                    تاريخ القيد
                  </label>
                  <input
                    type="date"
                    value={entryDate}
                    onChange={(e) => setEntryDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-blue-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                    نوع العملية والمرجع
                  </label>
                  <select
                    value={referenceType}
                    onChange={(e) => setReferenceType(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-blue-500"
                  >
                    <option value="manual">تسوية يدوية / قيد عام</option>
                    <option value="capital">مساهمة شريك / رأسمال</option>
                    <option value="sales">فاتورة مبيعات</option>
                    <option value="purchase">فاتورة مشتريات خامات</option>
                    <option value="production">تكلفة تشغيل وإنتاج</option>
                    <option value="depreciation">إهلاك ماكينات وأصول</option>
                    <option value="payroll">رواتب وأجور عمال</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                    البيان العام والشرح المحاسبي
                  </label>
                  <input
                    type="text"
                    value={entryDescription}
                    onChange={(e) => setEntryDescription(e.target.value)}
                    placeholder="مثال: إثبات سداد دفعة نقدية أو مصروفات تشغيل..."
                    className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-blue-500"
                    required
                  />
                </div>
              </div>

              {/* Dynamic Line Items */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-300">أطراف القيد (المدين والدائن)</h4>
                  <button
                    type="button"
                    onClick={addLine}
                    className="flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30 hover:bg-blue-600/30 transition cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>إضافة طرف / سطر آخر</span>
                  </button>
                </div>

                <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/70 p-2">
                  <table className="w-full text-right text-xs">
                    <thead>
                      <tr className="text-slate-400 border-b border-slate-800 pb-2">
                        <th className="p-2 w-10">#</th>
                        <th className="p-2 w-72">الحساب المحاسبي</th>
                        <th className="p-2 w-36">مدين (منه) - جنيه</th>
                        <th className="p-2 w-36">دائن (له) - جنيه</th>
                        <th className="p-2">شرح وبيان الطرف</th>
                        <th className="p-2 w-12 text-center">حذف</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-850">
                      {lines.map((line, idx) => (
                        <tr key={idx}>
                          <td className="p-2 text-slate-500 font-mono">{idx + 1}</td>
                          <td className="p-2">
                            <select
                              value={line.accountId}
                              onChange={(e) => handleAccountSelect(idx, e.target.value)}
                              className="w-full px-2.5 py-1.5 text-xs bg-slate-900 border border-slate-700 rounded-lg text-slate-200 focus:outline-none focus:border-blue-500"
                              required
                            >
                              <option value="">-- اختر الحساب من الدليل --</option>
                              {accounts.map((a) => (
                                <option key={a.id} value={a.id}>
                                  [{a.code}] {a.name}
                                </option>
                              ))}
                            </select>
                          </td>
                          <td className="p-2">
                            <input
                              type="number"
                              min="0"
                              step="any"
                              value={line.debit || ''}
                              onChange={(e) =>
                                handleLineChange(idx, 'debit', parseFloat(e.target.value) || 0)
                              }
                              placeholder="0.00"
                              className="w-full px-2.5 py-1.5 text-xs bg-slate-900 border border-slate-700 rounded-lg text-emerald-400 font-mono font-bold focus:outline-none focus:border-emerald-500"
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="number"
                              min="0"
                              step="any"
                              value={line.credit || ''}
                              onChange={(e) =>
                                handleLineChange(idx, 'credit', parseFloat(e.target.value) || 0)
                              }
                              placeholder="0.00"
                              className="w-full px-2.5 py-1.5 text-xs bg-slate-900 border border-slate-700 rounded-lg text-cyan-400 font-mono font-bold focus:outline-none focus:border-cyan-500"
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="text"
                              value={line.note}
                              onChange={(e) => handleLineChange(idx, 'note', e.target.value)}
                              placeholder="ملاحظة السطر..."
                              className="w-full px-2.5 py-1.5 text-xs bg-slate-900 border border-slate-700 rounded-lg text-slate-300 focus:outline-none focus:border-blue-500"
                            />
                          </td>
                          <td className="p-2 text-center">
                            <button
                              type="button"
                              onClick={() => removeLine(idx)}
                              className="p-1 rounded text-rose-400 hover:bg-rose-950/40"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Real-time Balance Box */}
              <div
                className={`p-4 rounded-2xl border flex flex-col sm:flex-row items-center justify-between gap-4 ${
                  isBalanced
                    ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-200'
                    : 'bg-rose-950/40 border-rose-500/50 text-rose-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  {isBalanced ? (
                    <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
                  ) : (
                    <AlertCircle className="w-6 h-6 text-rose-400 shrink-0" />
                  )}
                  <div>
                    <h5 className="font-bold text-sm">
                      {isBalanced
                        ? 'القيد متوازن محاسبياً وجاهز للترحيل الفوري!'
                        : 'القيد غير متوازن، لا يمكن حفظه وفقاً لقواعد القيد المزدوج.'}
                    </h5>
                    <p className="text-xs opacity-80">
                      إجمالي المدين: {totalDebit.toLocaleString()} جنيه مصري | إجمالي الدائن:{' '}
                      {totalCredit.toLocaleString()} جنيه مصري | الفرق: {diff.toLocaleString()} جنيه مصري
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700 transition"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    disabled={!isBalanced}
                    className={`px-5 py-2.5 rounded-xl font-bold text-xs transition shadow-lg cursor-pointer ${
                      isBalanced
                        ? 'bg-emerald-500 hover:bg-emerald-600 text-slate-950'
                        : 'bg-slate-800 text-slate-500 cursor-not-allowed opacity-50'
                    }`}
                  >
                    حفظ وترحيل آلي لكافة الحسابات
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reverse Entry Modal */}
      {showReverseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="bg-slate-900 border border-rose-700 rounded-3xl max-w-md w-full p-6 text-white shadow-2xl">
            <div className="flex items-center gap-2 mb-3 text-rose-400">
              <Undo2 className="w-6 h-6" />
              <h3 className="text-base font-bold">إنشاء قيد عكسي معتمد</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              وفقاً للمعايير المحاسبية المعتمدة في النظام، لا يتم حذف القيود المرحلة بدون أثر تدقيقي.
              سيتم إنشاء قيد عكسي مطابق وموازٍ لضبط الحسابات وتصحيح الرصيد.
            </p>
            <div className="mb-4">
              <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                سبب التسوية / العكس
              </label>
              <textarea
                value={reverseReason}
                onChange={(e) => setReverseReason(e.target.value)}
                placeholder="اكتب سبب عكس هذا القيد للرجوع إليه في سجل التدقيق..."
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-rose-500 h-24"
              />
            </div>
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowReverseModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700 transition"
              >
                إلغاء
              </button>
              <button
                onClick={handleConfirmReverse}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition shadow-lg"
              >
                تأكيد القيد العكسي والترحيل
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
