/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  AlertCircle,
  ArrowDownRight,
  ArrowUpLeft,
  Boxes,
  CheckCircle2,
  FileSpreadsheet,
  Package,
  Plus,
  RefreshCcw,
  Search,
  Warehouse as WarehouseIcon,
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import * as XLSX from 'xlsx';

export const InventoryModule: React.FC = () => {
  const { inventory, warehouses, updateStock, addInventoryItem } = useERP();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedWarehouse, setSelectedWarehouse] = useState('all');
  const [showStockModal, setShowStockModal] = useState(false);
  const [selectedItemId, setSelectedItemId] = useState('');
  const [movementType, setMovementType] = useState<'in' | 'out'>('in');
  const [quantity, setQuantity] = useState(10);
  const [unitCost, setUnitCost] = useState(150);

  const handleStockMovement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItemId || quantity <= 0) return;
    updateStock(selectedItemId, Number(quantity), movementType, Number(unitCost));
    setShowStockModal(false);
  };

  const exportInventoryToExcel = () => {
    const data = inventory.map((item) => ({
      'كود الصنف': item.code,
      'الاسم': item.name,
      'التصنيف': item.category,
      'الوحدة': item.unit,
      'الرصيد الحالي': item.currentStock,
      'حد إعادة الطلب': item.minAlertStock,
      'متوسط التكلفة المرجح (جنيه مصري)': item.movingAverageCost,
      'إجمالي القيمة المخزنية (جنيه مصري)': item.currentStock * item.movingAverageCost,
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'المخازن والأصناف');
    XLSX.writeFile(wb, 'Inventory_Valuation_Report.xlsx');
  };

  const filteredItems = inventory.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.code.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesWarehouse =
      selectedWarehouse === 'all' || item.warehouseId === selectedWarehouse;
    return matchesSearch && matchesWarehouse;
  });

  const totalInventoryValue = inventory.reduce(
    (sum, item) => sum + item.currentStock * item.movingAverageCost,
    0
  );

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-l from-slate-900 via-slate-900 to-purple-950/40 border border-slate-800 shadow-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="p-2 rounded-xl bg-purple-600/20 text-purple-400 border border-purple-500/30">
              <Boxes className="w-6 h-6" />
            </span>
            <h2 className="text-xl font-bold text-white">
              إدارة المخازن المتعددة وتقييم المخزون (Moving Average Valuation)
            </h2>
          </div>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            مخازن مستقلة للخامات الأولية، أدوات القطع، المنتجات تحت التشغيل، المنتجات التامة،
            والخردة/الهالك. تقييم مخزني معتمد بسياسة المتوسط المرجح المتحرك والتنبيه الفوري عند نقص
            الرصيد عن حد الطلب.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowStockModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-lg transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>حركة استلام / صرف مخزني</span>
          </button>
          <button
            onClick={exportInventoryToExcel}
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>تصدير إكسل</span>
          </button>
        </div>
      </div>

      {/* Warehouse Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {warehouses.map((w) => {
          const itemsInWh = inventory.filter((i) => i.warehouseId === w.id);
          const valInWh = itemsInWh.reduce((s, i) => s + i.currentStock * i.movingAverageCost, 0);

          return (
            <div
              key={w.id}
              onClick={() => setSelectedWarehouse(w.id === selectedWarehouse ? 'all' : w.id)}
              className={`p-4 rounded-2xl border transition cursor-pointer shadow-md ${
                selectedWarehouse === w.id
                  ? 'bg-purple-950/60 border-purple-500/80 shadow-lg'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex justify-between items-center mb-1">
                <span className="font-mono text-[10px] text-purple-400 font-bold">{w.code}</span>
                <span className="text-[10px] text-slate-500">{itemsInWh.length} أصناف</span>
              </div>
              <h4 className="font-bold text-xs text-white truncate">{w.name}</h4>
              <p className="text-[11px] font-mono font-bold text-emerald-400 mt-2">
                {valInWh.toLocaleString()} ج
              </p>
            </div>
          );
        })}
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 rounded-2xl bg-slate-900 border border-slate-800">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute right-3 top-3 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="بحث باسم الصنف، الكود، الباركود..."
            className="w-full pl-3 pr-9 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-purple-500"
          />
        </div>

        <div className="text-xs text-slate-300">
          إجمالي قيمة المخزون الحالي:{' '}
          <strong className="text-emerald-400 font-mono text-sm">
            {totalInventoryValue.toLocaleString()} جنيه مصري
          </strong>
        </div>
      </div>

      {/* Items Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 overflow-hidden shadow-xl">
        <table className="w-full text-right text-xs">
          <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
            <tr>
              <th className="p-3.5">كود الصنف</th>
              <th className="p-3.5">اسم الصنف والوصف</th>
              <th className="p-3.5">المخزن التابع</th>
              <th className="p-3.5">الرصيد الحالي</th>
              <th className="p-3.5">حد إعادة الطلب</th>
              <th className="p-3.5">متوسط التكلفة المرجح (جنيه مصري)</th>
              <th className="p-3.5">إجمالي القيمة (جنيه مصري)</th>
              <th className="p-3.5 text-center">حالة التوفر</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {filteredItems.map((item) => {
              const isLowStock = item.currentStock <= item.minAlertStock;
              const wh = warehouses.find((w) => w.id === item.warehouseId);

              return (
                <tr key={item.id} className="hover:bg-slate-800/40 transition">
                  <td className="p-3.5 font-mono font-bold text-purple-400">{item.code}</td>
                  <td className="p-3.5">
                    <span className="font-bold text-white block">{item.name}</span>
                    <span className="text-[10px] text-slate-400">الوحدة: {item.unit}</span>
                  </td>
                  <td className="p-3.5 text-slate-300">{wh?.name.split('(')[0] || 'المخزن'}</td>
                  <td className="p-3.5 font-mono font-bold text-white text-sm">
                    {item.currentStock} {item.unit}
                  </td>
                  <td className="p-3.5 font-mono text-slate-400">
                    {item.minAlertStock} {item.unit}
                  </td>
                  <td className="p-3.5 font-mono font-bold text-slate-200">
                    {item.movingAverageCost.toLocaleString()} جنيه مصري
                  </td>
                  <td className="p-3.5 font-mono font-bold text-emerald-400">
                    {(item.currentStock * item.movingAverageCost).toLocaleString()} جنيه مصري
                  </td>
                  <td className="p-3.5 text-center">
                    {isLowStock ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-950 text-rose-400 border border-rose-800 animate-pulse">
                        تنبيه: وشك النفاذ!
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                        متوفر
                      </span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Stock In / Out Modal */}
      {showStockModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-6 text-white shadow-2xl">
            <h3 className="text-base font-bold text-white mb-4">تسجيل حركة مخزنية (استلام أو صرف)</h3>
            <form onSubmit={handleStockMovement} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">اختر الصنف</label>
                <select
                  value={selectedItemId}
                  onChange={(e) => setSelectedItemId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-purple-500"
                  required
                >
                  <option value="">-- حدد الصنف --</option>
                  {inventory.map((item) => (
                    <option key={item.id} value={item.id}>
                      [{item.code}] {item.name} (رصيد: {item.currentStock})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">نوع الحركة</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setMovementType('in')}
                    className={`py-2 rounded-xl border font-bold text-xs transition cursor-pointer ${
                      movementType === 'in'
                        ? 'bg-emerald-950 border-emerald-500 text-emerald-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    استلام وتوريد (وارد)
                  </button>
                  <button
                    type="button"
                    onClick={() => setMovementType('out')}
                    className={`py-2 rounded-xl border font-bold text-xs transition cursor-pointer ${
                      movementType === 'out'
                        ? 'bg-rose-950 border-rose-500 text-rose-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    صرف للتشغيل (منصرف)
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">الكمية</label>
                  <input
                    type="number"
                    min="1"
                    value={quantity}
                    onChange={(e) => setQuantity(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:border-purple-500"
                    required
                  />
                </div>
                {movementType === 'in' && (
                  <div>
                    <label className="block text-slate-400 font-semibold mb-1">
                      سعر شراء الوحدة (جنيه مصري)
                    </label>
                    <input
                      type="number"
                      value={unitCost}
                      onChange={(e) => setUnitCost(parseFloat(e.target.value) || 0)}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:border-purple-500"
                    />
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowStockModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold transition shadow-lg"
                >
                  تأكيد الحركة المخزنية
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
