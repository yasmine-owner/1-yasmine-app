import React, { useMemo, useState } from 'react';
import { useERP } from '../../context/ERPContext';

const TABS: [string, string][] = [
  ['employees', 'الموظفون'], ['attendance', 'الحضور والانصراف'], ['advances', 'السلف والخصومات'], ['payroll', 'الرواتب'],
  ['purchases', 'المشتريات'], ['sales', 'المبيعات'], ['stockMoves', 'حركات المخزن'], ['partnerMoves', 'حركات الشركاء'],
  ['partnerDues', 'المستحقات'], ['parties', 'العملاء والموردون'], ['documents', 'الصور والمستندات'],
];

export const ExtrasModule: React.FC = () => {
  const { extras } = useERP();
  const [tab, setTab] = useState('employees');
  const [q, setQ] = useState('');
  const rows = extras[tab] || [];
  const cols = useMemo(() => (rows[0] ? Object.keys(rows[0]).filter((k) => k !== 'المعرّف' && !k.includes('نص آلي')) : []), [rows]);
  const shown = rows.filter((r) => !q || Object.values(r).some((v) => String(v).includes(q)));
  const salary = tab === 'employees' ? rows.reduce((s, r) => s + (Number(r['الراتب الشهري']) || 0), 0) : 0;

  return (
    <div className="space-y-4" dir="rtl">
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
        <h2 className="text-lg font-bold text-white">الموظفون والسجلات المستوردة</h2>
        <p className="text-xs text-slate-400 mt-1">عرض ومراجعة فقط. السجلات دي جاية من ملف Excel المستورد.</p>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {TABS.map(([k, label]) => (
          <button key={k} onClick={() => setTab(k)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold border ${tab === k ? 'bg-amber-500 text-slate-950 border-amber-500' : 'bg-slate-900 text-slate-300 border-slate-700'}`}>
            {label} ({(extras[k] || []).length})
          </button>
        ))}
      </div>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="بحث..."
        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs" />
      {salary > 0 && <div className="text-xs text-amber-300">إجمالي الرواتب الشهرية: {salary.toLocaleString('en-US')} ج.م</div>}
      <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900">
        {shown.length === 0 ? (
          <p className="p-6 text-center text-xs text-slate-500">لا توجد سجلات في هذا القسم.</p>
        ) : (
          <table className="w-full text-xs text-right">
            <thead className="bg-slate-800 text-slate-300">
              <tr>{cols.map((c) => <th key={c} className="px-3 py-2 font-semibold">{c}</th>)}</tr>
            </thead>
            <tbody>
              {shown.map((r, i) => (
                <tr key={i} className="border-t border-slate-800 text-slate-200">
                  {cols.map((c) => <td key={c} className="px-3 py-2">{String(r[c]).slice(0, 90)}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};
