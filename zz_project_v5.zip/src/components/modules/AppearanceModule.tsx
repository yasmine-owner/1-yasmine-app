/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Check,
  CheckCircle2,
  Eye,
  Layout,
  Palette,
  RefreshCcw,
  Sparkles,
  Type,
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { ThemeConfig } from '../../types/erp';

export const AppearanceModule: React.FC = () => {
  const { theme, updateTheme } = useERP();

  const [companyName, setCompanyName] = useState(theme.companyName);
  const [subtitle, setSubtitle] = useState(theme.companySubtitle);
  const [primaryColor, setPrimaryColor] = useState(theme.primaryColor);
  const [accentColor, setAccentColor] = useState(theme.accentColor);
  const [fontSize, setFontSize] = useState(theme.fontSize);
  const [borderRadius, setBorderRadius] = useState(theme.borderRadius);
  const [layoutDensity, setLayoutDensity] = useState(theme.layoutDensity);

  const presets = [
    {
      id: 'blue',
      name: 'الأزرق الاحترافي (SoftStream Blue)',
      primary: '#2563eb',
      accent: '#38bdf8',
      desc: 'الأزرق التكنولوجي الداكن المعتمد في شاشات المصانع العالمية',
    },
    {
      id: 'navy',
      name: 'كحلي وأبيض ملكي (Royal Navy)',
      primary: '#1e3a8a',
      accent: '#93c5fd',
      desc: 'أزرق داكن فخم مع تباين عالي الجودة',
    },
    {
      id: 'dark',
      name: 'أزرق بترولي وداكن (Titanium Dark)',
      primary: '#0e7490',
      accent: '#22d3ee',
      desc: 'بترولي داكن يريح العين خلال فترات العمل الطويلة',
    },
    {
      id: 'emerald',
      name: 'الأخضر الصناعي (Industrial Emerald)',
      primary: '#059669',
      accent: '#34d399',
      desc: 'أخضر مالي وتصنيعي يعكس وفرة الإنتاج والاستدامة',
    },
    {
      id: 'gray',
      name: 'الرمادي المعدني (Steel Charcoal)',
      primary: '#475569',
      accent: '#94a3b8',
      desc: 'هوية معدنية احترافية مستوحاة من سبائك الصلب والألومنيوم',
    },
    {
      id: 'purple',
      name: 'البنفسجي التقني (Cyber Violet)',
      primary: '#7c3aed',
      accent: '#c084fc',
      desc: 'مظهر عصري ومميز ذو طابع رقمي متقدم',
    },
  ];

  const handleApplyPreset = (p: typeof presets[0]) => {
    setPrimaryColor(p.primary);
    setAccentColor(p.accent);
    updateTheme({
      preset: p.id as any,
      primaryColor: p.primary,
      accentColor: p.accent,
    });
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateTheme({
      companyName,
      companySubtitle: subtitle,
      primaryColor,
      accentColor,
      fontSize,
      borderRadius,
      layoutDensity,
    });
    alert('تم حفظ وتطبيق المظهر العام الجديد بنجاح على كافة الشاشات والأجهزة!');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-l from-slate-900 via-slate-900 to-indigo-950/40 border border-slate-800 shadow-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="p-2 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
              <Palette className="w-6 h-6" />
            </span>
            <h2 className="text-xl font-bold text-white">
              وحدة تخصيص المظهر والهوية (Appearance & UI Customization)
            </h2>
          </div>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            وفقاً للبند 5 من المواصفات: تخصيص شامل للألوان والسمات الجاهزة (الأزرق، الكحلي،
            البترولي، الأخضر، الرمادي، البنفسجي)، اسم الشركة والمصنع، حجم الخطوط، والمسافات مع تطبيق
            فوري على كافة الأجهزة.
          </p>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Ready-made Presets Grid */}
        <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-4 shadow-xl">
          <h3 className="font-bold text-sm text-white flex items-center gap-2 border-b border-slate-800 pb-3">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>السمات اللونية الجاهزة (Theme Presets)</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {presets.map((p) => {
              const isSelected = theme.preset === p.id;

              return (
                <div
                  key={p.id}
                  onClick={() => handleApplyPreset(p)}
                  className={`p-4 rounded-2xl border transition cursor-pointer relative ${
                    isSelected
                      ? 'bg-slate-850 border-blue-500 ring-2 ring-blue-500/30 shadow-lg'
                      : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <span
                      className="w-5 h-5 rounded-full border border-white/20 shadow-sm"
                      style={{ backgroundColor: p.primary }}
                    ></span>
                    <span
                      className="w-5 h-5 rounded-full border border-white/20 shadow-sm"
                      style={{ backgroundColor: p.accent }}
                    ></span>
                    <h4 className="font-bold text-xs text-white mr-1">{p.name}</h4>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">{p.desc}</p>
                  {isSelected && (
                    <div className="absolute top-3 left-3 text-blue-400">
                      <CheckCircle2 className="w-4 h-4" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Company Identity & Typography */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-4 shadow-xl">
            <h3 className="font-bold text-sm text-white flex items-center gap-2 border-b border-slate-800 pb-3">
              <Layout className="w-4 h-4 text-blue-400" />
              <span>هوية واسم المنشأة الصناعية</span>
            </h3>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">اسم المصنع / الشركة</label>
                <input
                  type="text"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">
                  الوصف الفرعي وعنوان النظام
                </label>
                <input
                  type="text"
                  value={subtitle}
                  onChange={(e) => setSubtitle(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>
          </div>

          <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-4 shadow-xl">
            <h3 className="font-bold text-sm text-white flex items-center gap-2 border-b border-slate-800 pb-3">
              <Type className="w-4 h-4 text-purple-400" />
              <span>الخطوط وأبعاد الواجهة والمسافات</span>
            </h3>

            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">حجم الخط الأساسي</label>
                  <select
                    value={fontSize}
                    onChange={(e) => setFontSize(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="small">صغير (دقيق ومكثف)</option>
                    <option value="medium">متوسط (قياسي مريح)</option>
                    <option value="large">كبير (وضوح عالي)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">استدارة الحواف</label>
                  <select
                    value={borderRadius}
                    onChange={(e) => setBorderRadius(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="sm">حواف مستقيمة حادة</option>
                    <option value="md">انحناء متوسط</option>
                    <option value="lg">انحناء ناعم عصري</option>
                    <option value="xl">كبسولات ناعمة جداً</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">كثافة الشاشة والمسافات</label>
                <select
                  value={layoutDensity}
                  onChange={(e) => setLayoutDensity(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="compact">مضغوط (عرض أكبر قدر من البيانات)</option>
                  <option value="normal">متوازن ومريح</option>
                  <option value="spacious">واسع للشاشات الكبيرة</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="flex justify-end gap-3 pt-4">
          <button
            type="submit"
            className="px-6 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-xl shadow-blue-600/30 transition cursor-pointer"
          >
            حفظ وتطبيق المظهر على النظام
          </button>
        </div>
      </form>
    </div>
  );
};
