/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Activity,
  AlertTriangle,
  BadgeDollarSign,
  BarChart3,
  BookOpen,
  Boxes,
  Building2,
  Calculator,
  ChevronLeft,
  Cog,
  Cpu,
  Database,
  DollarSign,
  Factory,
  FileCheck2,
  FileSpreadsheet,
  FileText,
  Flame,
  FolderGit2,
  HelpCircle,
  History,
  Layers,
  LayoutDashboard,
  Lock,
  Package,
  Palette,
  Percent,
  Receipt,
  Scissors,
  Settings,
  Shield,
  ShieldAlert,
  ShoppingCart,
  TrendingUp,
  Truck,
  Users2,
  Wallet,
  Wrench,
  X,
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';

interface SidebarProps {
  activeModule: string;
  setActiveModule: (mod: string) => void;
  collapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
  mobileOpen: boolean;
  setMobileOpen: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeModule,
  setActiveModule,
  collapsed,
  setCollapsed,
  mobileOpen,
  setMobileOpen,
}) => {
  const { currentUser, isOwnerSecretUnlocked, theme } = useERP();

  const isOwner = currentUser.role === 'owner';

  const menuSections = [
    {
      label: 'الرئيسية والتشغيل',
      items: [
        { id: 'dashboard', label: 'لوحة التحكم العامة', icon: LayoutDashboard, badge: 'Live' },
        { id: 'journal', label: 'شاشة القيود الموحدة (المركزية)', icon: BookOpen, badge: 'رئيسي' },
      ],
    },
    {
      label: 'الإدارة المالية والمحاسبية',
      items: [
        { id: 'accounting', label: 'دليل الحسابات والأستاذ والميزان', icon: Receipt },
        { id: 'partners', label: 'الشركاء والماكينات والمخزون (2,400,000 جنيه)', icon: Users2, badge: '2.4 مليون' },
        { id: 'treasury', label: 'الخزينة والبنوك والسيولة', icon: Wallet },
        { id: 'fixed_assets', label: 'الأصول الثابتة والإهلاك', icon: Building2 },
      ],
    },
    {
      label: 'التصنيع والعمليات الفنية',
      items: [
        { id: 'manufacturing', label: 'أوامر الإنتاج والتصنيع وBOM', icon: Factory, badge: 'إنتاج' },
        { id: 'machines', label: 'سجل الماكينات والصيانة', icon: Cpu },
        { id: 'cutting_tools', label: 'أدوات القطع (End Mills)', icon: Scissors, badge: 'أدوات قطع' },
        { id: 'scrap_downtime', label: 'الهالك والأعطال والتوقفات', icon: AlertTriangle },
      ],
    },
    {
      label: 'المخازن والتكاليف والتجارة',
      items: [
        { id: 'inventory', label: 'المخازن والأصناف والتسويات', icon: Boxes },
        { id: 'sales_purchases', label: 'المبيعات والمشتريات والعملاء', icon: ShoppingCart },
        { id: 'costing_pricing', label: 'التكاليف الصناعية والتسعير', icon: Calculator, badge: 'تسعير' },
        { id: 'extras', label: 'الموظفون والسجلات المستوردة', icon: FileText },
        { id: 'reports', label: 'التقارير التحليلية الشاملة', icon: BarChart3 },
      ],
    },
    {
      label: 'التحكم المتقدم والتخصيص',
      items: [
        { id: 'appearance', label: 'تخصيص المظهر والألوان', icon: Palette },
        { id: 'backup_export', label: 'النسخ الاحتياطي وحزمة التثبيت', icon: Database },
        ...(isOwner
          ? [
              {
                id: 'owner_secret',
                label: 'لوحة تحكم المالك السرية',
                icon: Shield,
                specialOwner: true,
                badge: isOwnerSecretUnlocked ? 'مفتوحة' : 'محمية',
              },
            ]
          : []),
      ],
    },
  ];

  const handleItemClick = (id: string) => {
    setActiveModule(id);
    setMobileOpen(false); // Close drawer on mobile selection
  };

  return (
    <>
      {/* Mobile Backdrop Overlay */}
      {mobileOpen && (
        <div
          onClick={() => setMobileOpen(false)}
          className="lg:hidden fixed inset-0 z-40 bg-black/70 backdrop-blur-sm transition-opacity"
        />
      )}

      {/* Main Sidebar Element */}
      <aside
        className={`fixed lg:relative inset-y-0 right-0 z-50 flex flex-col bg-slate-900 border-l border-slate-800 text-slate-200 transition-all duration-300 shadow-2xl ${
          mobileOpen ? 'translate-x-0 w-80 max-w-[85vw]' : 'translate-x-full invisible pointer-events-none lg:visible lg:pointer-events-auto lg:translate-x-0'
        } ${collapsed ? 'lg:w-20' : 'lg:w-72'}`}
      >
        {/* Brand Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 text-white font-bold text-lg shadow-md shrink-0">
              <Factory className="w-6 h-6" />
            </div>
            <div className="truncate">
              <h1 className="font-bold text-sm tracking-wide text-white truncate">
                {theme.companyName || 'النظام المتكامل لإدارة المصنع'}
              </h1>
              <p className="text-[11px] text-blue-400 font-medium">Enterprise Factory ERP</p>
            </div>
          </div>

          {/* Close button on mobile */}
          <button
            onClick={() => setMobileOpen(false)}
            className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation List */}
        <div className="flex-1 overflow-y-auto py-3 px-3 space-y-6">
          {menuSections.map((sec, secIdx) => (
            <div key={secIdx}>
              <p className="px-3 mb-2 text-[11px] font-semibold tracking-wider text-slate-500 uppercase">
                {sec.label}
              </p>
              <div className="space-y-1">
                {sec.items.map((item: any) => {
                  const Icon = item.icon;
                  const isActive = activeModule === item.id;
                  const isSpecial = item.specialOwner;

                  return (
                    <button
                      key={item.id}
                      onClick={() => handleItemClick(item.id)}
                      className={`w-full flex items-center justify-between gap-3 px-3.5 py-2.5 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                        isActive
                          ? isSpecial
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50 shadow-md font-bold'
                            : 'bg-blue-600 text-white shadow-lg shadow-blue-600/30 font-semibold'
                          : isSpecial
                          ? 'text-amber-400/90 hover:bg-amber-500/10 hover:text-amber-300'
                          : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/60'
                      }`}
                    >
                      <div className="flex items-center gap-3 truncate">
                        <Icon
                          className={`w-4 h-4 shrink-0 ${
                            isActive
                              ? 'text-white'
                              : isSpecial
                              ? 'text-amber-400 animate-pulse'
                              : 'text-slate-400'
                          }`}
                        />
                        <span className="truncate">{item.label}</span>
                      </div>

                      {item.badge && (
                        <span
                          className={`px-1.5 py-0.5 text-[10px] font-bold rounded-md uppercase ${
                            isSpecial
                              ? 'bg-amber-500/30 text-amber-300 border border-amber-500/40'
                              : isActive
                              ? 'bg-white/20 text-white'
                              : 'bg-slate-800 text-slate-400 border border-slate-700'
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Collapse Toggle for Desktop */}
        <div className="hidden lg:flex p-3 border-t border-slate-800 items-center justify-between">
          {!collapsed && (
            <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span>نظام محلي مشفر وآمن</span>
            </div>
          )}
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            title={collapsed ? 'توسيع القائمة' : 'طي القائمة'}
          >
            <ChevronLeft
              className={`w-4 h-4 transition-transform duration-200 ${
                collapsed ? 'rotate-180' : ''
              }`}
            />
          </button>
        </div>
      </aside>
    </>
  );
};
