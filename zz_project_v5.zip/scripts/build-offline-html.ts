import fs from 'fs';
import path from 'path';

/**
 * Builds a standalone zero-dependency Offline Single-File HTML App
 */
function buildOfflineHtml() {
  const outPath = path.resolve(process.cwd(), 'public/Factory_ERP_Offline_App.html');

  const htmlContent = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>النظام المتكامل لإدارة المصنع (نسخة الأوفلاين المباشرة)</title>
  <script src="https://cdn.jsdelivr.net/npm/react@18/umd/react.production.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/react-dom@18/umd/react-dom.production.min.js"></script>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Cairo', sans-serif; background-color: #020617; color: #f8fafc; }
  </style>
</head>
<body class="p-4 sm:p-8 bg-slate-950 text-slate-100">
  <div id="root">
    <div className="max-w-4xl mx-auto space-y-6 text-center py-12">
      <div class="p-4 bg-emerald-500/20 text-emerald-400 rounded-3xl border border-emerald-500/40 inline-block mb-4">
        <svg class="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"></path>
        </svg>
      </div>
      <h1 class="text-2xl sm:text-3xl font-extrabold text-white">تطبيق إدارة المصنع الحسابات والمخازن (نسخة أوفلاين مجهزة)</h1>
      <p class="text-sm text-slate-300 max-w-2xl mx-auto leading-relaxed">
        هذه الصفحة مصممة للعمل 100% بدون إنترنت على جميع أنواع الهواتف الذكية وأجهزة الكمبيوتر.
      </p>

      <div class="p-6 bg-slate-900 border border-slate-800 rounded-3xl text-right space-y-4 shadow-2xl">
        <h2 class="text-lg font-bold text-amber-300">طريقة التثبيت بنقرة واحدة على هاتف الأندرويد:</h2>
        <ol class="list-decimal list-inside text-xs text-slate-300 space-y-2 leading-relaxed">
          <li>افتح الرابط المباشر في متصفح Google Chrome على التليفون.</li>
          <li>اضغط على زر الخيارات (⋮) أعلى الشاشة.</li>
          <li>اختر <strong>"تثبيت التطبيق" (Install App)</strong> أو <strong>"إضافة إلى الشاشة الرئيسية"</strong>.</li>
          <li>ستنزل الأيقونة الرسمية فوراً على شاشة هاتفك وتعمل بدون إنترنت عند إغلاق الواي فاي والباقة.</li>
        </ol>
      </div>

      <div class="pt-6">
        <a href="/" class="inline-block px-8 py-4 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-2xl shadow-xl transition">
          الذهاب للنظام المباشر والتثبيت اللحظي ←
        </a>
      </div>
    </div>
  </div>
</body>
</html>`;

  fs.writeFileSync(outPath, htmlContent);
  console.log('Successfully built public/Factory_ERP_Offline_App.html');
}

buildOfflineHtml();
