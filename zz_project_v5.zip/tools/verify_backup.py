#!/usr/bin/env python3
"""Checks an AlYasmeen Excel backup before importing it into the app.
Usage:  python verify_backup.py  AlYasmeen-Backup.xlsx        (needs: pip install openpyxl)
Prints OK / WARN / FAIL lines so you can see exactly where a problem comes from."""
import sys
from collections import defaultdict
import openpyxl

def rows(wb, name):
    if name not in wb.sheetnames:
        return []
    ws = wb[name]
    it = ws.iter_rows(values_only=True)
    head = [str(h).strip() if h is not None else '' for h in next(it, [])]
    return [dict(zip(head, r)) for r in it if any(c not in (None, '') for c in r)]

def n(v):
    try:
        return float(str(v).replace(',', ''))
    except (TypeError, ValueError):
        return 0.0

results = []
def say(level, text):
    results.append(level)
    print(f'[{level}] {text}')

def main(path):
    wb = openpyxl.load_workbook(path, data_only=True)
    for s in ('دليل الحسابات', 'قيود اليومية', 'تفاصيل قيود اليومية'):
        say('OK' if s in wb.sheetnames else 'FAIL', f'ورقة أساسية: {s}')
    accs = rows(wb, 'دليل الحسابات')
    codes = [str(a['كود الحساب']) for a in accs]
    say('OK' if len(codes) == len(set(codes)) else 'FAIL', f'أكواد الحسابات فريدة ({len(codes)} حساب)')
    kind = {str(a['كود الحساب']): str(a['نوع الحساب']) for a in accs}

    lines = rows(wb, 'تفاصيل قيود اليومية')
    heads = {str(h['رقم القيد']): h for h in rows(wb, 'قيود اليومية')}
    per = defaultdict(lambda: [0.0, 0.0])
    bal = defaultdict(float)
    for l in lines:
        c = str(l['كود الحساب'])
        if c not in kind:
            say('FAIL', f"قيد {l['رقم القيد']} يستخدم حساباً غير موجود: {c}")
        d, k = n(l['مدين']), n(l['دائن'])
        per[str(l['رقم القيد'])][0] += d
        per[str(l['رقم القيد'])][1] += k
        natural_debit = 'أصول' in kind.get(c, '') or 'مصروف' in kind.get(c, '')
        bal[c] += (d - k) if natural_debit else (k - d)
    for no, (d, k) in per.items():
        say('OK' if abs(d - k) < 0.01 else 'FAIL', f'قيد {no}: مدين {d:,.0f} / دائن {k:,.0f}')
        h = heads.get(no)
        if h and abs(n(h['إجمالي المدين']) - d) > 0.01:
            say('WARN', f'قيد {no}: إجمالي رأس القيد يختلف عن مجموع التفاصيل')
    tot_d = sum(v[0] for v in per.values()); tot_c = sum(v[1] for v in per.values())
    say('OK' if abs(tot_d - tot_c) < 0.01 else 'FAIL', f'ميزان المراجعة: مدين {tot_d:,.0f} = دائن {tot_c:,.0f}')

    bad = 0
    for r in rows(wb, 'أرصدة الحسابات'):
        c = str(r['كود الحساب'])
        if c in kind:
            natural_debit = 'أصول' in kind[c] or 'مصروف' in kind[c]
            exp = (n(r['مدين']) - n(r['دائن'])) if natural_debit else (n(r['دائن']) - n(r['مدين']))
            if abs(exp - bal.get(c, 0.0)) > 0.01:
                bad += 1
                say('WARN', f'رصيد {c} في الملف يختلف عن المحسوب من القيود')
    if not bad:
        say('OK', 'أرصدة الحسابات في الملف = المحسوبة من القيود')

    items = rows(wb, 'الأصناف')
    stock_value = sum(n(m['القيمة']) for m in rows(wb, 'حركات المخزن'))
    gl_inv = sum(v for c, v in bal.items() if c.startswith('113'))
    say('OK' if abs(stock_value - gl_inv) < 0.01 else 'WARN',
        f'قيمة مخزون الحركات {stock_value:,.0f} مقابل حسابات المخزون 113x في الأستاذ {gl_inv:,.0f}')
    if items and not any(n(i['الرصيد']) for i in items):
        say('WARN', 'ورقة الأصناف أرصدتها صفر؛ التطبيق يعيد بناء الأرصدة من حركات المخزن')

    purchases = sum(n(p['الإجمالي']) for p in rows(wb, 'المشتريات'))
    with_machines = {str(l['رقم القيد']) for l in lines if str(l['كود الحساب']) == '1201'}
    partner_credit = sum(n(l['دائن']) for l in lines
                         if str(l['كود الحساب']).startswith('310') and str(l['كود الحساب']) != '3101'
                         and str(l['رقم القيد']) not in with_machines)
    if abs(purchases - partner_credit) > 0.01:
        say('WARN', f'فواتير المشتريات {purchases:,.0f} بينما ما سُجّل لجاري الشركاء (غير شراء الماكينات) {partner_credit:,.0f}: راجع القيود مع المحاسب')

    machines = rows(wb, 'الماكينات')
    if not machines and bal.get('1201', 0) > 0:
        say('WARN', f"سجل الماكينات فاضي بينما حساب الماكينات 1201 = {bal['1201']:,.0f}")

    for a in rows(wb, 'الحضور والانصراف'):
        t = str(a['وقت الدخول'] or '')[:5]
        if t and (t < '05:00' or t > '22:00'):
            say('WARN', f"حضور {a['اسم الموظف']} {a['التاريخ']} وقت دخول غريب ({t})")
    fails = results.count('FAIL'); warns = results.count('WARN')
    print(f'\nالخلاصة: {fails} خطأ، {warns} تنبيه.')
    return 1 if fails else 0

if __name__ == '__main__':
    if len(sys.argv) < 2:
        sys.exit('usage: python verify_backup.py file.xlsx')
    sys.exit(main(sys.argv[1]))
