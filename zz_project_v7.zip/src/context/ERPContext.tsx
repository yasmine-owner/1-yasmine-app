/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useEffect, useState } from 'react';
import { normDigits } from '../utils/digits';
import {
  INITIAL_ACCOUNTS,
  INITIAL_AUDIT_LOGS,
  INITIAL_BOMS,
  INITIAL_CUTTING_TOOLS,
  INITIAL_INVENTORY,
  INITIAL_JOURNAL_ENTRIES,
  INITIAL_MACHINES,
  INITIAL_PARTNERS,
  INITIAL_PRODUCTION_ORDERS,
  INITIAL_SCRAP_LOGS,
  INITIAL_THEME,
  INITIAL_USERS,
  INITIAL_WAREHOUSES,
} from '../data/initialData';
import {
  Account,
  AuditLog,
  CuttingTool,
  InventoryItem,
  JournalEntry,
  Machine,
  Partner,
  ProductBOM,
  ProductionOrder,
  ScrapDowntimeLog,
  ThemeConfig,
  User,
  Warehouse,
} from '../types/erp';

interface ERPContextType {
  currentUser: User;
  users: User[];
  accounts: Account[];
  journalEntries: JournalEntry[];
  partners: Partner[];
  machines: Machine[];
  cuttingTools: CuttingTool[];
  inventory: InventoryItem[];
  warehouses: Warehouse[];
  boms: ProductBOM[];
  productionOrders: ProductionOrder[];
  scrapLogs: ScrapDowntimeLog[];
  auditLogs: AuditLog[];
  theme: ThemeConfig;
  isOwnerSecretUnlocked: boolean;
  ownerSecretPin: string;

  // Actions
  switchUser: (userId: string) => void;
  unlockOwnerSecret: (pin: string) => boolean;
  lockOwnerSecret: () => void;
  updateOwnerSecretPin: (oldPin: string, newPin: string) => { success: boolean; message: string };
  updateTheme: (newTheme: Partial<ThemeConfig>) => void;
  
  // Journal & Accounting (Single unified journal page with auto-posting)
  addJournalEntry: (entry: {
    date: string;
    description: string;
    referenceType?: JournalEntry['referenceType'];
    referenceId?: string;
    lines: { accountId: string; accountCode: string; accountName: string; debit: number; credit: number; note?: string }[];
  }) => { success: boolean; message: string; entryId?: string };
  reverseJournalEntry: (entryId: string, reason: string) => { success: boolean; message: string };

  // Operations
  addProductionOrder: (order: Partial<ProductionOrder>) => void;
  updateProductionOrder: (id: string, updates: Partial<ProductionOrder>) => void;
  addCuttingTool: (tool: Omit<CuttingTool, 'id'>) => void;
  updateToolStatus: (id: string, status: CuttingTool['status'], breakageReason?: CuttingTool['breakageReason'], notes?: string) => void;
  addMachine: (machine: Omit<Machine, 'id'>) => void;
  updateMachineStatus: (id: string, status: Machine['status']) => void;
  addInventoryItem: (item: Omit<InventoryItem, 'id'>) => void;
  updateStock: (id: string, deltaQuantity: number, type: 'in' | 'out', unitCost?: number) => void;
  addScrapLog: (log: Omit<ScrapDowntimeLog, 'id'>) => void;
  
  // User & Security Management (Owner secret)
  updateUserPermissions: (userId: string, permissions: Partial<User['permissions']>) => void;
  addNewUser: (user: Omit<User, 'id'>) => void;
  toggleUserStatus: (userId: string) => void;

  // Backup & Reset
  exportDatabaseAsJSON: () => string;
  extras: Record<string, Record<string, any>[]>;
  startFromZero: () => void;
  replaceCollection: (name: string, items: any[]) => void;
  restoreDatabaseFromJSON: (jsonStr: string) => { success: boolean; message: string };
  resetDatabaseToDefaults: () => void;
}

const ERPContext = createContext<ERPContextType | null>(null);

const STORAGE_KEY = 'factory_erp_medical_clean_v6';

export const ERPProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load from local storage or defaults
  const [isLoaded, setIsLoaded] = useState(false);
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [currentUser, setCurrentUser] = useState<User>(INITIAL_USERS[0]); // Default: Owner
  const [accounts, setAccounts] = useState<Account[]>(INITIAL_ACCOUNTS);
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>(INITIAL_JOURNAL_ENTRIES);
  const [partners, setPartners] = useState<Partner[]>(INITIAL_PARTNERS);
  const [machines, setMachines] = useState<Machine[]>(INITIAL_MACHINES);
  const [cuttingTools, setCuttingTools] = useState<CuttingTool[]>(INITIAL_CUTTING_TOOLS);
  const [inventory, setInventory] = useState<InventoryItem[]>(INITIAL_INVENTORY);
  const [warehouses, setWarehouses] = useState<Warehouse[]>(INITIAL_WAREHOUSES);
  const [boms, setBoms] = useState<ProductBOM[]>(INITIAL_BOMS);
  const [productionOrders, setProductionOrders] = useState<ProductionOrder[]>(INITIAL_PRODUCTION_ORDERS);
  const [scrapLogs, setScrapLogs] = useState<ScrapDowntimeLog[]>(INITIAL_SCRAP_LOGS);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);
  const [theme, setTheme] = useState<ThemeConfig>(INITIAL_THEME);
  const [extras, setExtras] = useState<Record<string, Record<string, any>[]>>({});

  // Owner Secret Control Room Protection
  const [isOwnerSecretUnlocked, setIsOwnerSecretUnlocked] = useState<boolean>(false);
  const [ownerSecretPin, setOwnerSecretPin] = useState<string>('7890'); // Default Master Owner Secret PIN

  // Load state on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.users) setUsers(parsed.users);
        if (parsed.accounts) setAccounts(parsed.accounts);
        if (parsed.journalEntries) setJournalEntries(parsed.journalEntries);
        if (parsed.partners) setPartners(parsed.partners);
        if (parsed.machines) setMachines(parsed.machines);
        if (parsed.cuttingTools) setCuttingTools(parsed.cuttingTools);
        if (parsed.inventory) setInventory(parsed.inventory);
        if (parsed.warehouses) setWarehouses(parsed.warehouses);
        if (parsed.boms) setBoms(parsed.boms);
        if (parsed.productionOrders) setProductionOrders(parsed.productionOrders);
        if (parsed.scrapLogs) setScrapLogs(parsed.scrapLogs);
        if (parsed.auditLogs) setAuditLogs(parsed.auditLogs);
        if (parsed.theme) setTheme(parsed.theme);
        if (parsed.extras) setExtras(parsed.extras);
        if (parsed.ownerSecretPin) setOwnerSecretPin(parsed.ownerSecretPin);
      }
    } catch (e) {
      console.error('Failed to load from storage:', e);
    } finally {
      setIsLoaded(true);
    }
  }, []);

  // Save state on change
  useEffect(() => {
    if (!isLoaded) return;
    try {
      const dump = {
        users,
        accounts,
        journalEntries,
        partners,
        machines,
        cuttingTools,
        inventory,
        warehouses,
        boms,
        productionOrders,
        scrapLogs,
        auditLogs,
        theme,
        extras,
        ownerSecretPin,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(dump));
    } catch (e) {
      console.error('Failed to save to storage:', e);
    }
  }, [
    isLoaded,
    users,
    accounts,
    journalEntries,
    partners,
    machines,
    cuttingTools,
    inventory,
    warehouses,
    boms,
    productionOrders,
    scrapLogs,
    auditLogs,
    theme,
    extras,
    ownerSecretPin,
  ]);

  // Log audit helper
  const addAudit = (action: AuditLog['action'], module: string, details: string) => {
    const newLog: AuditLog = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
      userId: currentUser.id,
      userName: currentUser.name,
      action,
      module,
      details,
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  const switchUser = (userId: string) => {
    const target = users.find((u) => u.id === userId);
    if (target) {
      setCurrentUser(target);
      // Lock secret panel if user is not owner
      if (target.role !== 'owner') {
        setIsOwnerSecretUnlocked(false);
      }
      addAudit('login', 'المصادقة', `تبديل المستخدم النشط إلى: ${target.name} (${target.role})`);
    }
  };

  const unlockOwnerSecret = (pin: string) => {
    if (normDigits(pin.trim()) === normDigits(ownerSecretPin)) {
      setIsOwnerSecretUnlocked(true);
      addAudit('login', 'لوحة المالك السرية', 'تم التحقق بنجاح وفتح لوحة المالك الرئيسية السرية');
      return true;
    }
    addAudit('login', 'محاولة اختراق', `محاولة فاشلة لفتح لوحة المالك برمز غير صحيح`);
    return false;
  };

  const lockOwnerSecret = () => {
    setIsOwnerSecretUnlocked(false);
    addAudit('login', 'لوحة المالك السرية', 'تم قفل لوحة المالك والخروج الآمن');
  };

  const updateOwnerSecretPin = (oldPin: string, newPin: string) => {
    if (normDigits(oldPin.trim()) !== normDigits(ownerSecretPin)) {
      return { success: false, message: 'الرمز السري الحالي غير صحيح!' };
    }
    if (newPin.trim().length < 4) {
      return { success: false, message: 'الرمز السري الجديد يجب أن بيتكون من 4 أرقام أو أحرف على الأقل.' };
    }
    const cleanPin = normDigits(newPin.trim());
    setOwnerSecretPin(cleanPin);
    addAudit('update', 'لوحة المالك السرية', 'تم تغيير وتحديث الرمز السري الفولاذي للوحة تحكم المالك');
    return { success: true, message: 'تم تحديث وتغيير الرمز السري للمالك بنجاح تام.' };
  };

  const updateTheme = (newTheme: Partial<ThemeConfig>) => {
    setTheme((prev) => ({ ...prev, ...newTheme }));
    addAudit('update', 'تخصيص المظهر', 'تحديث إعدادات الألوان وهوية النظام');
  };

  // Add Journal Entry (The core unified double-entry ledger screen)
  const addJournalEntry = ({
    date,
    description,
    referenceType = 'manual',
    referenceId,
    lines,
  }: {
    date: string;
    description: string;
    referenceType?: JournalEntry['referenceType'];
    referenceId?: string;
    lines: { accountId: string; accountCode: string; accountName: string; debit: number; credit: number; note?: string }[];
  }) => {
    const totalDebit = lines.reduce((acc, curr) => acc + (Number(curr.debit) || 0), 0);
    const totalCredit = lines.reduce((acc, curr) => acc + (Number(curr.credit) || 0), 0);

    if (Math.abs(totalDebit - totalCredit) > 0.01) {
      return {
        success: false,
        message: `القيد غير متوازن! إجمالي المدين (${totalDebit.toLocaleString()} ج) لا يساوي إجمالي الدائن (${totalCredit.toLocaleString()} ج). الفرق: ${Math.abs(totalDebit - totalCredit).toLocaleString()} ج`,
      };
    }

    if (totalDebit <= 0) {
      return { success: false, message: 'قيمة القيد يجب أن تكون أكبر من صفر.' };
    }

    const nextNumber = `JE-${new Date().getFullYear()}-${String(journalEntries.length + 1).padStart(4, '0')}`;
    const newEntry: JournalEntry = {
      id: `je-${Date.now()}`,
      entryNumber: nextNumber,
      date,
      description,
      referenceType,
      referenceId,
      isPosted: true, // Auto-post immediately from the central page
      createdBy: currentUser.name,
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      lines,
      totalAmount: totalDebit,
    };

    // Auto-update Account Balances (الترحيل الفوري التلقائي للأستاذ العام وميزان المراجعة)
    setAccounts((prevAccounts) => {
      const updated = [...prevAccounts];
      lines.forEach((line) => {
        const accIdx = updated.findIndex((a) => a.id === line.accountId || a.code === line.accountCode);
        if (accIdx !== -1) {
          const acc = { ...updated[accIdx] };
          // For Assets & Expenses: Debit increases balance, Credit decreases balance
          if (acc.type === 'asset' || acc.type === 'expense') {
            acc.balance = (acc.balance || 0) + (line.debit || 0) - (line.credit || 0);
          } else {
            // For Liabilities, Equity, Revenues: Credit increases balance, Debit decreases balance
            acc.balance = (acc.balance || 0) + (line.credit || 0) - (line.debit || 0);
          }
          updated[accIdx] = acc;
        }
      });
      return updated;
    });

    setJournalEntries((prev) => [newEntry, ...prev]);
    addAudit('post', 'شاشة القيود اليومية الموحدة', `تسجيل وترحيل القيد اليومي الموحد رقم ${nextNumber} بمبلغ ${totalDebit.toLocaleString()} ج: ${description}`);

    return {
      success: true,
      message: `تم حفظ وترحيل القيد ${nextNumber} بنجاح إلى كافة الحسابات والأستاذ وميزان المراجعة.`,
      entryId: newEntry.id,
    };
  };

  // Reverse Journal Entry (Audited reversing entry)
  const reverseJournalEntry = (entryId: string, reason: string) => {
    const target = journalEntries.find((j) => j.id === entryId);
    if (!target) return { success: false, message: 'القيد غير موجود.' };
    if (target.isReversed) return { success: false, message: 'هذا القيد تم عكسه مسبقاً.' };

    // Reverse lines (swap debit & credit)
    const reversedLines = target.lines.map((l) => ({
      accountId: l.accountId,
      accountCode: l.accountCode,
      accountName: l.accountName,
      debit: l.credit,
      credit: l.debit,
      note: `عكس للسطر: ${l.note || ''}`,
    }));

    const result = addJournalEntry({
      date: new Date().toISOString().slice(0, 10),
      description: `قيد تسوية عكسي للقيد رقم (${target.entryNumber}): ${reason}`,
      referenceType: 'manual',
      referenceId: target.id,
      lines: reversedLines,
    });

    if (result.success) {
      setJournalEntries((prev) =>
        prev.map((e) => (e.id === entryId ? { ...e, isReversed: true } : e))
      );
      addAudit('reverse', 'القيود المحاسبية', `إنشاء قيد عكسي للقيد ${target.entryNumber}. السبب: ${reason}`);
    }

    return result;
  };

  const addProductionOrder = (order: Partial<ProductionOrder>) => {
    const newOrder: ProductionOrder = {
      id: `ord-${Date.now()}`,
      orderNumber: `WO-${new Date().getFullYear()}-${String(productionOrders.length + 1).padStart(4, '0')}`,
      bomId: order.bomId || '',
      productName: order.productName || 'منتج مخصص',
      requiredQuantity: order.requiredQuantity || 1,
      producedQuantity: 0,
      acceptedQuantity: 0,
      rejectedQuantity: 0,
      reworkedQuantity: 0,
      scrapQuantity: 0,
      startDate: order.startDate || new Date().toISOString().slice(0, 10),
      expectedEndDate: order.expectedEndDate || new Date().toISOString().slice(0, 10),
      status: 'planned',
      assignedMachineId: order.assignedMachineId || machines[0]?.id || '',
      assignedOperator: order.assignedOperator || 'فني التشغيل',
      actualMaterialCost: order.actualMaterialCost || 0,
      actualDirectLaborCost: order.actualDirectLaborCost || 0,
      actualMachineOperatingCost: order.actualMachineOperatingCost || 0,
      actualToolingCost: order.actualToolingCost || 0,
      totalActualCost: order.totalActualCost || 0,
      costPerAcceptedUnit: 0,
      notes: order.notes,
    };
    setProductionOrders((prev) => [newOrder, ...prev]);
    addAudit('create', 'أوامر الإنتاج', `إنشاء أمر إنتاج جديد: ${newOrder.orderNumber} - ${newOrder.productName} بكمية ${newOrder.requiredQuantity}`);
  };

  const updateProductionOrder = (id: string, updates: Partial<ProductionOrder>) => {
    setProductionOrders((prev) =>
      prev.map((ord) => {
        if (ord.id === id) {
          const updated = { ...ord, ...updates };
          const accepted = updated.acceptedQuantity || 0;
          const totalCost = (updated.actualMaterialCost || 0) +
            (updated.actualDirectLaborCost || 0) +
            (updated.actualMachineOperatingCost || 0) +
            (updated.actualToolingCost || 0);
          updated.totalActualCost = totalCost;
          updated.costPerAcceptedUnit = accepted > 0 ? Number((totalCost / accepted).toFixed(2)) : 0;
          return updated;
        }
        return ord;
      })
    );
    addAudit('update', 'أوامر الإنتاج', `تحديث بيانات وتكاليف أمر الإنتاج: ${id}`);
  };

  const addCuttingTool = (tool: Omit<CuttingTool, 'id'>) => {
    const newTool: CuttingTool = {
      ...tool,
      id: `tool-${Date.now()}`,
    };
    setCuttingTools((prev) => [newTool, ...prev]);
    addAudit('create', 'أدوات القطع والـ End Mills', `إضافة أداة قطع جديدة: ${newTool.name} - ${newTool.code}`);
  };

  const updateToolStatus = (id: string, status: CuttingTool['status'], breakageReason?: CuttingTool['breakageReason'], notes?: string) => {
    setCuttingTools((prev) =>
      prev.map((t) => (t.id === id ? { ...t, status, breakageReason, notes: notes || t.notes, replacementDate: new Date().toISOString().slice(0, 10) } : t))
    );
    addAudit('update', 'أدوات القطع', `تغيير حالة أداة القطع ${id} إلى ${status} (${breakageReason || 'طبيعي'})`);
  };

  const addMachine = (machine: Omit<Machine, 'id'>) => {
    const newM: Machine = {
      ...machine,
      id: `m-${Date.now()}`,
    };
    setMachines((prev) => [newM, ...prev]);
    addAudit('create', 'الماكينات والمعدات', `تسجيل أصل وماكينة جديدة: ${newM.name} (${newM.code})`);
  };

  const updateMachineStatus = (id: string, status: Machine['status']) => {
    setMachines((prev) =>
      prev.map((m) => (m.id === id ? { ...m, status } : m))
    );
    addAudit('update', 'الماكينات', `تحديث حالة تشغيل الماكينة ${id} إلى ${status}`);
  };

  const addInventoryItem = (item: Omit<InventoryItem, 'id'>) => {
    const newItem: InventoryItem = {
      ...item,
      id: `item-${Date.now()}`,
    };
    setInventory((prev) => [newItem, ...prev]);
    addAudit('create', 'المخازن', `تعريف كود صنف جديد بالمخازن: ${newItem.name} (${newItem.code})`);
  };

  const updateStock = (id: string, deltaQuantity: number, type: 'in' | 'out', unitCost?: number) => {
    setInventory((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const oldStock = item.currentStock;
          const oldCost = item.movingAverageCost;
          let newStock = type === 'in' ? oldStock + deltaQuantity : Math.max(0, oldStock - deltaQuantity);
          let newCost = oldCost;
          // Moving average formula on incoming stock
          if (type === 'in' && unitCost && (oldStock + deltaQuantity) > 0) {
            newCost = ((oldStock * oldCost) + (deltaQuantity * unitCost)) / (oldStock + deltaQuantity);
          }
          return {
            ...item,
            currentStock: newStock,
            movingAverageCost: Number(newCost.toFixed(2)),
          };
        }
        return item;
      })
    );
    addAudit('update', 'حركات المخزن', `حركة مخزنية (${type}) للصنف ${id} بمقدار ${deltaQuantity}`);
  };

  const addScrapLog = (log: Omit<ScrapDowntimeLog, 'id'>) => {
    const newLog: ScrapDowntimeLog = {
      ...log,
      id: `scrap-${Date.now()}`,
    };
    setScrapLogs((prev) => [newLog, ...prev]);
    addAudit('create', 'الهالك والتوقفات', `تسجيل حدث هالك/توقف: ${newLog.reason} بتكلفة ${newLog.financialImpact} ج`);
  };

  const updateUserPermissions = (userId: string, permissions: Partial<User['permissions']>) => {
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === userId) {
          return {
            ...u,
            permissions: { ...u.permissions, ...permissions },
          };
        }
        return u;
      })
    );
    addAudit('permission_change', 'الصلاحيات والأمان', `تعديل صلاحيات المستخدم: ${userId} من لوحة المالك`);
  };

  const addNewUser = (user: Omit<User, 'id'>) => {
    const newUser: User = {
      ...user,
      id: `user-${Date.now()}`,
    };
    setUsers((prev) => [...prev, newUser]);
    addAudit('create', 'المستخدمون', `إنشاء حساب مستخدم جديد: ${newUser.name} برتبة (${newUser.role}) وبصلاحيات افتراضية مقيدة`);
  };

  const toggleUserStatus = (userId: string) => {
    setUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, isActive: !u.isActive } : u))
    );
    addAudit('update', 'المستخدمون', `تغيير حالة تفعيل المستخدم: ${userId}`);
  };

  const exportDatabaseAsJSON = () => {
    const backup = {
      timestamp: new Date().toISOString(),
      version: '2.5.0-enterprise',
      system: 'Factory ERP Suite',
      data: {
        users,
        accounts,
        journalEntries,
        partners,
        machines,
        cuttingTools,
        inventory,
        warehouses,
        boms,
        productionOrders,
        scrapLogs,
        auditLogs,
        theme,
      },
    };
    addAudit('backup', 'النسخ الاحتياطي', 'تصدير نسخة احتياطية كاملة لقاعدة البيانات');
    return JSON.stringify(backup, null, 2);
  };

  const restoreDatabaseFromJSON = (jsonStr: string) => {
    try {
      const parsed = JSON.parse(jsonStr);
      if (!parsed.data) {
        return { success: false, message: 'ملف النسخة الاحتياطية غير صالح أو تالف.' };
      }
      const d = parsed.data;
      if (d.users) setUsers(d.users);
      if (d.accounts) setAccounts(d.accounts);
      if (d.journalEntries) setJournalEntries(d.journalEntries);
      if (d.partners) setPartners(d.partners);
      if (d.machines) setMachines(d.machines);
      if (d.cuttingTools) setCuttingTools(d.cuttingTools);
      if (d.inventory) setInventory(d.inventory);
      if (d.warehouses) setWarehouses(d.warehouses);
      if (d.boms) setBoms(d.boms);
      if (d.productionOrders) setProductionOrders(d.productionOrders);
      if (d.scrapLogs) setScrapLogs(d.scrapLogs);
      if (d.auditLogs) setAuditLogs(d.auditLogs);
      if (d.theme) setTheme(d.theme);
      if (d.extras) setExtras(d.extras);

      addAudit('backup', 'استعادة البيانات', 'تمت استعادة قاعدة البيانات بنجاح من ملف نسخة احتياطية');
      return { success: true, message: 'تمت استعادة كافة البيانات بنجاح تام.' };
    } catch (e: any) {
      return { success: false, message: `فشل فك تشفير النسخة الاحتياطية: ${e.message}` };
    }
  };

  const resetDatabaseToDefaults = () => {
    setUsers(INITIAL_USERS);
    setCurrentUser(INITIAL_USERS[0]);
    setAccounts(INITIAL_ACCOUNTS);
    setJournalEntries(INITIAL_JOURNAL_ENTRIES);
    setPartners(INITIAL_PARTNERS);
    setMachines(INITIAL_MACHINES);
    setCuttingTools(INITIAL_CUTTING_TOOLS);
    setInventory(INITIAL_INVENTORY);
    setWarehouses(INITIAL_WAREHOUSES);
    setBoms(INITIAL_BOMS);
    setProductionOrders(INITIAL_PRODUCTION_ORDERS);
    setScrapLogs(INITIAL_SCRAP_LOGS);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setExtras({});
    setTheme(INITIAL_THEME);
    setIsOwnerSecretUnlocked(false);
    localStorage.removeItem(STORAGE_KEY);
    addAudit('delete', 'إعادة ضبط النظام', 'تمت إعادة ضبط المصنع لقاعدة البيانات واستعادة التهيئات النموذجية');
  };

  const startFromZero = () => {
    if (currentUser.role !== 'owner') return;
    setJournalEntries([]);
    setAccounts((prev) => prev.map((a) => ({ ...a, balance: 0 })));
    setPartners((prev) => prev.map((p) => ({ ...p, initialContribution: 0, currentBalance: 0 })));
    setInventory((prev) => prev.map((i) => ({ ...i, currentStock: 0 })));
    setMachines([]);
    setCuttingTools([]);
    setProductionOrders([]);
    setScrapLogs([]);
    addAudit('delete', 'تصفير النظام', 'تم تصفير كل الأرصدة والحركات والبدء من صفر');
  };

  const replaceCollection = (name: string, items: any[]) => {
    if (currentUser.role !== 'owner') return;
    const setters: Record<string, (v: any) => void> = {
      accounts: setAccounts, partners: setPartners, machines: setMachines, cuttingTools: setCuttingTools,
      inventory: setInventory, warehouses: setWarehouses, productionOrders: setProductionOrders, scrapLogs: setScrapLogs, boms: setBoms,
    };
    if (name.startsWith('extras:')) {
      const k = name.slice(7);
      setExtras((prev) => ({ ...prev, [k]: items }));
    } else if (setters[name]) {
      setters[name](items);
    } else {
      return;
    }
    addAudit('update', 'تعديل البيانات', `تعديل سجلات ${name} (العدد الآن ${items.length})`);
  };

  return (
    <ERPContext.Provider
      value={{
        extras,
        startFromZero,
        replaceCollection,
        currentUser,
        users,
        accounts,
        journalEntries,
        partners,
        machines,
        cuttingTools,
        inventory,
        warehouses,
        boms,
        productionOrders,
        scrapLogs,
        auditLogs,
        theme,
        isOwnerSecretUnlocked,
        ownerSecretPin,
        switchUser,
        unlockOwnerSecret,
        lockOwnerSecret,
        updateOwnerSecretPin,
        updateTheme,
        addJournalEntry,
        reverseJournalEntry,
        addProductionOrder,
        updateProductionOrder,
        addCuttingTool,
        updateToolStatus,
        addMachine,
        updateMachineStatus,
        addInventoryItem,
        updateStock,
        addScrapLog,
        updateUserPermissions,
        addNewUser,
        toggleUserStatus,
        exportDatabaseAsJSON,
        restoreDatabaseFromJSON,
        resetDatabaseToDefaults,
      }}
    >
      {children}
    </ERPContext.Provider>
  );
};

export const useERP = () => {
  const context = useContext(ERPContext);
  if (!context) throw new Error('useERP must be used within an ERPProvider');
  return context;
};
