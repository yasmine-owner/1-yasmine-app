/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { writeWorkbook } from '../../utils/excelExport';
import {
  AlertOctagon,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Cpu,
  FileSpreadsheet,
  Plus,
  Trash2,
  Wrench,
  XCircle,
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import * as XLSX from 'xlsx';

export const ScrapDowntimeModule: React.FC = () => {
  const { scrapLogs, machines, productionOrders, addScrapLog } = useERP();
  const [showAddModal, setShowAddModal] = useState(false);

  // Form State
  const [logType, setLogType] = useState<'scrap' | 'downtime' | 'tool_breakage'>('scrap');
  const [machineId, setMachineId] = useState(machines[0]?.id || '');
  const [orderId, setOrderId] = useState(productionOrders[0]?.id || '');
  const [qtyOrHours, setQtyOrHours] = useState(2);
  const [unit, setUnit] = useState<'pieces' | 'kg' | 'hours'>('pieces');
  const [isNormal, setIsNormal] = useState(true);
  const [reason, setReason] = useState('');
  const [responsiblePerson, setResponsiblePerson] = useState('');
  const [financialImpact, setFinancialImpact] = useState(350);
  const [correctiveAction, setCorrectiveAction] = useState('');

  const handleAddLog = (e: React.FormEvent) => {
    e.preventDefault();
    addScrapLog({
      date: new Date().toISOString().slice(0, 10),
      time: new Date().toTimeString().slice(0, 5),
      type: logType,
      machineId,
      productionOrderId: orderId,
      quantityOrHours: Number(qtyOrHours),
      unit,
      isNormal,
      reason,
      responsiblePerson,
      financialImpact: Number(financialImpact),
      correctiveAction,
      isApproved: true,
    });
    setShowAddModal(false);
    setReason('');
    setCorrectiveAction('');
  };

  const exportScrapToExcel = () => {
    const data = scrapLogs.map((s) => ({
      'التاريخ': s.date,
      'الوقت': s.time,
      'النوع': s.type,
      'التصنيف': s.isNormal ? 'طبيعي ومخطط' : 'استثنائي وخسارة',
      'الكمية / المدة': `${s.quantityOrHours} ${s.unit}`,
      'السبب': s.reason,
      'المسؤول': s.responsiblePerson,
      'التكلفة والأثر المالي (جنيه مصري)': s.financialImpact,
      'الإجراء التصحيحي': s.correctiveAction,
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'سجل الهالك والتوقفات');
    writeWorkbook(wb, 'Scrap_and_Downtime_Log.xlsx');
  };

  const totalFinancialLoss = scrapLogs.reduce((s, log) => s + log.financialImpact, 0);
  const exceptionalLoss = scrapLogs
    .filter((l) => !l.isNormal)
    .reduce((s, log) => s + log.financialImpact, 0);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-l from-slate-900 via-slate-900 to-rose-950/40 border border-slate-800 shadow-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="p-2 rounded-xl bg-rose-600/20 text-rose-400 border border-rose-500/30">
              <AlertTriangle className="w-6 h-6" />
            </span>
            <h2 className="text-xl font-bold text-white">
              سجل الهالك والأعطال وتوقفات الماكينات (Scrap & Downtime)
            </h2>
          </div>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            توثيق دقيق لكل حدث هالك خامات، أو كسر عِدد، أو توقف ماكينة، مع الفصل المحاسبي الصارم
            بين الهالك الطبيعي المصرح به والخسائر الاستثنائية، وربطها بالمسؤول والإجراء التصحيحي.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>تسجيل حدث هالك أو توقف</span>
          </button>
          <button
            onClick={exportScrapToExcel}
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>تصدير إكسل</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-xs text-slate-400">إجمالي الأثر المالي للأحداث المسجلة</span>
          <p className="text-2xl font-bold text-white font-mono mt-1">
            {totalFinancialLoss.toLocaleString()} ج
          </p>
        </div>
        <div className="p-4 rounded-2xl bg-rose-950/40 border border-rose-800/50">
          <span className="text-xs text-rose-400">خسائر استثنائية (غير طبيعية)</span>
          <p className="text-2xl font-bold text-rose-400 font-mono mt-1">
            {exceptionalLoss.toLocaleString()} ج
          </p>
        </div>
        <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-800/50">
          <span className="text-xs text-emerald-400">هالك تشغيلي طبيعي معتمد</span>
          <p className="text-2xl font-bold text-emerald-400 font-mono mt-1">
            {(totalFinancialLoss - exceptionalLoss).toLocaleString()} ج
          </p>
        </div>
      </div>

      {/* Logs Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 overflow-hidden shadow-xl">
        <table className="w-full text-right text-xs">
          <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
            <tr>
              <th className="p-3.5">التاريخ والوقت</th>
              <th className="p-3.5">النوع</th>
              <th className="p-3.5">التصنيف</th>
              <th className="p-3.5">الكمية / المدة</th>
              <th className="p-3.5">السبب والتفاصيل</th>
              <th className="p-3.5">المسؤول</th>
              <th className="p-3.5">الأثر المالي (جنيه مصري)</th>
              <th className="p-3.5">الإجراء التصحيحي</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {scrapLogs.map((log) => (
              <tr key={log.id} className="hover:bg-slate-800/40 transition">
                <td className="p-3.5 font-mono text-slate-300">
                  {log.date} <span className="text-slate-500 text-[10px]">{log.time}</span>
                </td>
                <td className="p-3.5 font-bold text-white">
                  {log.type === 'scrap'
                    ? 'هالك خامات'
                    : log.type === 'tool_breakage'
                    ? 'كسر أداة قطع'
                    : 'توقف ماكينة'}
                </td>
                <td className="p-3.5">
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                      log.isNormal
                        ? 'bg-blue-950 text-blue-400 border-blue-800'
                        : 'bg-rose-950 text-rose-400 border-rose-800'
                    }`}
                  >
                    {log.isNormal ? 'طبيعي ومخطط' : 'استثنائي (خسارة)'}
                  </span>
                </td>
                <td className="p-3.5 font-mono font-bold text-slate-200">
                  {log.quantityOrHours} {log.unit}
                </td>
                <td className="p-3.5 text-slate-300 max-w-xs">{log.reason}</td>
                <td className="p-3.5 text-slate-400">{log.responsiblePerson}</td>
                <td className="p-3.5 font-mono font-bold text-rose-400">
                  {log.financialImpact.toLocaleString()} جنيه مصري
                </td>
                <td className="p-3.5 text-emerald-400 max-w-xs">{log.correctiveAction}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add Log Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-6 text-white shadow-2xl">
            <h3 className="text-base font-bold text-white mb-4">تسجيل حدث هالك أو توقف ماكينة</h3>
            <form onSubmit={handleAddLog} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">نوع الحدث</label>
                  <select
                    value={logType}
                    onChange={(e) => {
                      setLogType(e.target.value as any);
                      if (e.target.value === 'downtime') setUnit('hours');
                      else setUnit('pieces');
                    }}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-rose-500"
                  >
                    <option value="scrap">هالك خامات أو منتجات</option>
                    <option value="downtime">توقف أو عطل ماكينة</option>
                    <option value="tool_breakage">كسر أداة قطع (End Mill)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">التصنيف</label>
                  <select
                    value={isNormal ? 'normal' : 'exceptional'}
                    onChange={(e) => setIsNormal(e.target.value === 'normal')}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-rose-500"
                  >
                    <option value="normal">طبيعي ومخطط له</option>
                    <option value="exceptional">استثنائي (خسارة وإهمال)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">الكمية أو الساعات</label>
                  <input
                    type="number"
                    step="any"
                    value={qtyOrHours}
                    onChange={(e) => setQtyOrHours(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:border-rose-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">
                    الأثر المالي المقدر (جنيه مصري)
                  </label>
                  <input
                    type="number"
                    value={financialImpact}
                    onChange={(e) => setFinancialImpact(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">السبب الرئيسي</label>
                <input
                  type="text"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="مثال: تلف خامة أثناء التثبيت، أو عطل كهربائي مفاجئ..."
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-rose-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">المسؤول عن الحدث</label>
                  <input
                    type="text"
                    value={responsiblePerson}
                    onChange={(e) => setResponsiblePerson(e.target.value)}
                    placeholder="فني التشغيل أو مهندس الصيانة"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-rose-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">
                    الإجراء التصحيحي المتخذ
                  </label>
                  <input
                    type="text"
                    value={correctiveAction}
                    onChange={(e) => setCorrectiveAction(e.target.value)}
                    placeholder="إعادة الضبط أو تبديل الحساس"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold transition shadow-lg"
                >
                  تسجيل الحدث
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
