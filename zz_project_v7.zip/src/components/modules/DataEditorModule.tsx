import React, { useState } from 'react';
import { Trash2, Plus } from 'lucide-react';
import { useERP } from '../../context/ERPContext';

type Rec = Record<string, any>;
const COLLS: [string, string][] = [
  ['accounts', 'دليل الحسابات'], ['partners', 'الشركاء'], ['inventory', 'الأصناف'], ['warehouses', 'المخازن'],
  ['machines', 'الماكينات'], ['cuttingTools', 'أدوات القطع'], ['productionOrders', 'أوامر الإنتاج'], ['scrapLogs', 'الهالك والتوقفات'],
  ['extras:employees', 'الموظفون'], ['extras:attendance', 'الحضور'], ['extras:purchases', 'المشتريات'],
  ['extras:stockMoves', 'حركات المخزن'], ['extras:partnerMoves', 'حركات الشركاء'], ['extras:documents', 'المستندات'],
];
const LBL: Record<string, string> = {
  asset: 'أصول', liability: 'التزامات', equity: 'حقوق ملكية', revenue: 'إيرادات', expense: 'مصروفات',
  raw: 'خامات', tools: 'أدوات', wip: 'تحت التشغيل', finished: 'منتج تام', scrap: 'هالك',
  raw_materials: 'خامات', cutting_tools: 'أدوات قطع', finished_goods: 'منتج تام',
  running: 'يعمل', idle: 'متوقف', maintenance: 'صيانة', breakdown: 'عطل', active: 'نشط', worn_out: 'مستهلك', broken: 'مكسور',
};
const ENUMS: Record<string, string[]> = {
  'accounts.type': ['asset', 'liability', 'equity', 'revenue', 'expense'],
  'warehouses.type': ['raw', 'tools', 'wip', 'finished', 'scrap'],
  'inventory.category': ['raw_materials', 'cutting_tools', 'wip', 'finished_goods', 'scrap'],
  'machines.status': ['running', 'idle', 'maintenance', 'breakdown'],
  'cuttingTools.status': ['active', 'worn_out', 'broken'],
};
const AR: Record<string, string> = {
  name: 'الاسم', code: 'الكود', unit: 'الوحدة', currentStock: 'الرصيد', minAlertStock: 'حد إعادة الطلب',
  movingAverageCost: 'متوسط التكلفة', lastPurchasePrice: 'آخر سعر شراء', sellingPrice: 'سعر البيع', warehouseId: 'كود المخزن',
  balance: 'الرصيد (يُحسب من القيود)', type: 'النوع', category: 'التصنيف', initialContribution: 'الحصة', currentBalance: 'الرصيد الحالي',
  notes: 'ملاحظات', purchaseCost: 'التكلفة', purchaseDate: 'تاريخ الشراء', status: 'الحالة', location: 'الموقع', brand: 'الماركة',
  model: 'الموديل', size: 'المقاس', supplier: 'المورد', unitPrice: 'السعر', managerName: 'المسؤول',
};
const READONLY = new Set(['id', 'المعرّف']);
const title = (r: Rec) => String(r.name || r['اسم الموظف'] || r['اسم الصنف'] || r['رقم المستند'] || r['العنوان'] || r.orderNumber || r.code || r.id || '—');

export const DataEditorModule: React.FC = () => {
  const erp = useERP();
  const { currentUser, extras, journalEntries, replaceCollection } = erp;
  const [coll, setColl] = useState('accounts');
  const [q, setQ] = useState('');
  const [openIdx, setOpenIdx] = useState<number | null>(null);
  const [draft, setDraft] = useState<Rec>({});
  const [msg, setMsg] = useState('');

  if (currentUser.role !== 'owner') return <p className="p-6 text-center text-xs text-slate-400">هذه الشاشة للمالك فقط.</p>;

  const list: Rec[] = coll.startsWith('extras:') ? extras[coll.slice(7)] || [] : ((erp as any)[coll] as Rec[]) || [];
  const shown = list.map((r, i) => ({ r, i })).filter(({ r }) => !q || Object.values(r).some((v) => String(v).includes(q)));

  const save = (idx: number) => {
    const next = [...list];
    next[idx] = draft;
    replaceCollection(coll, next);
    setOpenIdx(null);
    setMsg('تم الحفظ.');
  };
  const remove = (idx: number) => {
    const r = list[idx];
    if (coll === 'accounts' && (Number(r.balance) !== 0 || journalEntries.some((e) => e.lines.some((l) => l.accountCode === r.code)))) {
      return setMsg('لا يمكن حذف حساب عليه رصيد أو حركات. اعكس القيود أولاً.');
    }
    if (coll === 'warehouses' && ((erp as any).inventory as Rec[]).some((i) => i.warehouseId === r.id)) {
      return setMsg('لا يمكن حذف مخزن فيه أصناف. انقل الأصناف أو احذفها أولاً.');
    }
    if (!window.confirm(`حذف "${title(r)}" نهائياً؟`)) return;
    replaceCollection(coll, list.filter((_, i) => i !== idx));
    setOpenIdx(null);
    setMsg('تم الحذف.');
  };
  const add = () => {
    const tpl: Rec = list[0] ? Object.fromEntries(Object.entries(list[0]).map(([k, v]) => [k, typeof v === 'number' ? 0 : typeof v === 'boolean' ? false : typeof v === 'string' ? '' : v])) : { name: '' };
    if ('id' in tpl) tpl.id = `new-${Date.now()}`;
    if ('المعرّف' in tpl) tpl['المعرّف'] = `new-${Date.now()}`;
    replaceCollection(coll, [...list, tpl]);
    setOpenIdx(list.length);
    setDraft(tpl);
  };

  const field = (k: string) => {
    const v = draft[k];
    const ro = READONLY.has(k) || (coll === 'accounts' && k === 'balance');
    const en = ENUMS[`${coll}.${k}`];
    const base = 'w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs disabled:opacity-50';
    if (v !== null && typeof v === 'object') return <div className="text-[10px] text-slate-500">محتوى مركّب (غير قابل للتعديل هنا)</div>;
    if (en) return (
      <select value={String(v ?? '')} onChange={(e) => setDraft({ ...draft, [k]: e.target.value })} className={base}>
        {en.map((o) => <option key={o} value={o}>{LBL[o] || o}</option>)}
      </select>
    );
    if (typeof v === 'boolean') return <input type="checkbox" checked={v} onChange={(e) => setDraft({ ...draft, [k]: e.target.checked })} />;
    if (typeof v === 'number') return <input type="number" inputMode="decimal" value={v} disabled={ro} onChange={(e) => setDraft({ ...draft, [k]: Number(e.target.value) })} className={base} />;
    return <input type="text" value={String(v ?? '')} disabled={ro} onChange={(e) => setDraft({ ...draft, [k]: e.target.value })} className={base} />;
  };

  return (
    <div className="space-y-4" dir="rtl">
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
        <h2 className="text-lg font-bold text-white">تعديل البيانات (للمالك)</h2>
        <p className="text-xs text-slate-400 mt-1">عدّل أو احذف أو أضف أي سجل. القيود المحاسبية تتعدّل بعكس القيد من صفحة القيود، والأرصدة بتتحسب منها.</p>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {COLLS.map(([k, label]) => (
          <button key={k} onClick={() => { setColl(k); setOpenIdx(null); setMsg(''); }}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold border ${coll === k ? 'bg-amber-500 text-slate-950 border-amber-500' : 'bg-slate-900 text-slate-300 border-slate-700'}`}>
            {label}
          </button>
        ))}
      </div>
      <div className="flex gap-2">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="بحث..." className="flex-1 px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs" />
        <button onClick={add} className="px-3 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold flex items-center gap-1"><Plus className="w-4 h-4" /> إضافة</button>
      </div>
      {msg && <p className="text-xs text-amber-300">{msg}</p>}
      <div className="text-[11px] text-slate-500">{list.length} سجل</div>
      <div className="space-y-2">
        {shown.slice(0, 200).map(({ r, i }) => (
          <div key={i} className="rounded-xl bg-slate-900 border border-slate-800">
            <button className="w-full p-3 text-right text-xs text-white font-semibold flex justify-between"
              onClick={() => { setOpenIdx(openIdx === i ? null : i); setDraft({ ...r }); setMsg(''); }}>
              <span>{title(r)}</span><span className="text-slate-500">{r.code || ''}</span>
            </button>
            {openIdx === i && (
              <div className="p-3 border-t border-slate-800 space-y-2">
                {Object.keys(draft).map((k) => (
                  <div key={k}><label className="block text-[10px] text-slate-400 mb-1">{AR[k] || k}</label>{field(k)}</div>
                ))}
                <div className="flex gap-2 pt-1">
                  <button onClick={() => save(i)} className="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 text-xs font-bold">حفظ</button>
                  <button onClick={() => remove(i)} className="px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-bold flex items-center gap-1"><Trash2 className="w-4 h-4" /> حذف</button>
                </div>
              </div>
            )}
          </div>
        ))}
        {shown.length > 200 && <p className="text-[11px] text-slate-500">عرض أول 200 سجل. استخدم البحث لباقي السجلات.</p>}
      </div>
    </div>
  );
};
