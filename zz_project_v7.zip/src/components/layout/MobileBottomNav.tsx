/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  BookOpen,
  Boxes,
  FileText,
  LayoutDashboard,
  Menu,
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';

interface MobileBottomNavProps {
  activeModule: string;
  setActiveModule: (mod: string) => void;
  openMobileMenu: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeModule,
  setActiveModule,
  openMobileMenu,
}) => {
  const { currentUser } = useERP();
  const isOwner = currentUser.role === 'owner';

  const navItems = [
    { id: 'dashboard', label: 'الرئيسية', icon: LayoutDashboard },
    { id: 'journal', label: 'دخول وخروج', icon: BookOpen },
    { id: 'inventory', label: 'المخازن', icon: Boxes },
    { id: 'reports', label: 'التقارير', icon: FileText },
  ];

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-900/95 backdrop-blur-md border-t border-slate-800 text-slate-400 px-2 py-1.5 shadow-2xl flex items-center justify-around safe-area-pb">
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = activeModule === item.id;

        return (
          <button
            key={item.id}
            onClick={() => setActiveModule(item.id)}
            className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition text-center ${
              isActive
                ? 'text-amber-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Icon className={`w-5 h-5 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
            <span className="text-[10px] mt-0.5 leading-tight">{item.label}</span>
          </button>
        );
      })}

      {/* Menu / Drawer Toggle */}
      <button
        onClick={openMobileMenu}
        className="flex flex-col items-center justify-center py-1 px-2.5 rounded-xl text-slate-400 hover:text-slate-200 transition text-center"
      >
        <Menu className="w-5 h-5 text-amber-400" />
        <span className="text-[10px] mt-0.5 leading-tight text-amber-300 font-medium">المزيد</span>
      </button>
    </nav>
  );
};
