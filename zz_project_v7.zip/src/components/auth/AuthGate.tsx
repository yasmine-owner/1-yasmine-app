import React, { useCallback, useEffect, useState } from 'react';
import { Lock, ShieldCheck } from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { AutoBackupRunner } from '../common/AutoBackupRunner';
import { decryptBackup } from '../../utils/backupCrypto';
import {
  clearFailures,
  getLockUntil,
  hasCredential,
  recordFailure,
  setCredential,
  verifyCredential,
} from '../../utils/auth';

const IDLE_MS = 5 * 60 * 1000;
const BACKGROUND_MS = 60 * 1000;
const DEFAULT_PIN = '7890';

export const AuthGate: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const {
    users,
    switchUser,
    ownerSecretPin,
    updateOwnerSecretPin,
    isOwnerSecretUnlocked,
    lockOwnerSecret,
    restoreDatabaseFromJSON,
    startFromZero,
  } = useERP();

  const [authed, setAuthed] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [password2, setPassword2] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [info, setInfo] = useState('');
  const [zeroStart, setZeroStart] = useState(true);
  const [restorePw, setRestorePw] = useState('');

  const owner = users.find((u) => u.role === 'owner');
  const needsSetup = !!owner && !hasCredential(owner.username);
  const pinIsDefault = ownerSecretPin === DEFAULT_PIN;

  const lock = useCallback(() => {
    setAuthed(false);
    setPassword('');
    setPassword2('');
    setPin('');
    setError('');
  }, []);

  // Keep the owner's secret panel locked whenever the session is locked
  useEffect(() => {
    if (!authed && isOwnerSecretUnlocked) lockOwnerSecret();
  }, [authed, isOwnerSecretUnlocked]);

  // Auto-lock: inactivity, app sent to background, or manual logout event
  useEffect(() => {
    if (!authed) return;
    let timer = window.setTimeout(lock, IDLE_MS);
    let hiddenAt = 0;
    const reset = () => {
      window.clearTimeout(timer);
      timer = window.setTimeout(lock, IDLE_MS);
    };
    const onVisibility = () => {
      if (document.hidden) {
        hiddenAt = Date.now();
      } else if (hiddenAt && Date.now() - hiddenAt > BACKGROUND_MS) {
        lock();
      }
    };
    const events = ['click', 'keydown', 'touchstart', 'scroll'];
    events.forEach((ev) => window.addEventListener(ev, reset, { passive: true }));
    window.addEventListener('erp-lock', lock);
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      window.clearTimeout(timer);
      events.forEach((ev) => window.removeEventListener(ev, reset));
      window.removeEventListener('erp-lock', lock);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, [authed, lock]);

  const submitSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!owner) return;
    if (password.length < 8) return setError('كلمة المرور لازم تكون 8 أحرف على الأقل.');
    if (password !== password2) return setError('كلمتا المرور غير متطابقتين.');
    if (pinIsDefault && (pin.trim().length < 6 || pin.trim() === DEFAULT_PIN)) {
      return setError('الرمز السري للوحة المالك لازم يكون 6 أحرف أو أرقام على الأقل.');
    }
    setBusy(true);
    try {
      await setCredential(owner.username, password);
      if (pinIsDefault) updateOwnerSecretPin(DEFAULT_PIN, pin.trim());
      switchUser(owner.id);
      if (zeroStart) startFromZero();
      lock();
      setAuthed(true);
    } catch {
      setError('تعذر حفظ كلمة المرور على هذا الجهاز.');
    }
    setBusy(false);
  };

  const restoreFromFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    setError('');
    setInfo('');
    try {
      const text = await f.text();
      let plain = text;
      const p = JSON.parse(text);
      if (p && p.app === 'factory-erp' && p.d) {
        if (!restorePw) return setError('اكتب كلمة مرور النسخة المشفرة أولاً ثم اختر الملف.');
        plain = await decryptBackup(text, restorePw);
      }
      const res = restoreDatabaseFromJSON(plain);
      if (res.success) {
        setZeroStart(false);
        setInfo(res.message + ' أكمل إعداد كلمة مرور المالك.');
      }
      else setError(res.message);
    } catch {
      setError('تعذر قراءة الملف، أو كلمة مرور النسخة غير صحيحة.');
    }
  };

  const submitLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const wait = getLockUntil() - Date.now();
    if (wait > 0) return setError(`محاولات كثيرة خاطئة. حاول بعد ${Math.ceil(wait / 1000)} ثانية.`);
    setBusy(true);
    try {
      const u = users.find(
        (x) => x.isActive && x.username.toLowerCase() === username.trim().toLowerCase()
      );
      const ok = u ? await verifyCredential(u.username, password) : false;
      if (u && ok) {
        clearFailures();
        switchUser(u.id);
        setPassword('');
        setAuthed(true);
      } else {
        recordFailure();
        setError('اسم المستخدم أو كلمة المرور غير صحيحة.');
      }
    } catch {
      setError('تعذر التحقق من كلمة المرور على هذا الجهاز.');
    }
    setBusy(false);
  };

  if (authed) {
    return (
      <>
        <AutoBackupRunner />
        {children}
      </>
    );
  }

  const inputCls =
    'w-full px-3 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:border-amber-400';

  return (
    <div dir="rtl" className="min-h-dvh flex items-center justify-center bg-slate-950 p-4 text-slate-100">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl">
        <div className="flex flex-col items-center text-center mb-5">
          <div className="p-3 rounded-2xl bg-amber-500/15 border border-amber-500/40 text-amber-400 mb-3">
            {needsSetup ? <ShieldCheck className="w-8 h-8" /> : <Lock className="w-8 h-8" />}
          </div>
          <h1 className="text-lg font-bold">{needsSetup ? 'إعداد حساب المالك' : 'تسجيل الدخول'}</h1>
          <p className="text-xs text-slate-400 mt-1">
            {needsSetup
              ? 'أول مرة: اختر كلمة مرور قوية. لا يمكن استرجاعها إذا نسيتها.'
              : 'النظام المتكامل لإدارة المصنع'}
          </p>
        </div>

        {needsSetup ? (
          <form onSubmit={submitSetup} className="space-y-3">
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)}
              placeholder="كلمة مرور المالك (8 أحرف على الأقل)" className={inputCls} autoComplete="new-password" />
            <input type="password" value={password2} onChange={(e) => setPassword2(e.target.value)}
              placeholder="أعد كتابة كلمة المرور" className={inputCls} autoComplete="new-password" />
            {pinIsDefault && (
              <input type="password" value={pin} onChange={(e) => setPin(e.target.value)}
                placeholder="رمز سري جديد للوحة المالك (6 على الأقل)" className={inputCls} />
            )}
            <label className="flex items-center gap-2 text-xs text-slate-300">
              <input type="checkbox" checked={zeroStart} onChange={(e) => setZeroStart(e.target.checked)} />
              ابدأ من صفر (يمسح البيانات التجريبية)
            </label>
            {error && <p className="text-xs text-rose-400">{error}</p>}
            {info && <p className="text-xs text-emerald-400">{info}</p>}
            <button type="submit" disabled={busy}
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold disabled:opacity-60">
              {busy ? 'جاري الحفظ...' : 'حفظ والدخول'}
            </button>
            <div className="pt-3 mt-1 border-t border-slate-800 space-y-2">
              <p className="text-[11px] text-slate-400">جهاز جديد أو أعدت تثبيت التطبيق؟ استعد بياناتك من ملف نسخة احتياطية:</p>
              <input type="password" value={restorePw} onChange={(e) => setRestorePw(e.target.value)}
                placeholder="كلمة مرور النسخة (للنسخ المشفرة فقط)" className={inputCls} />
              <label className="block w-full text-center py-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-200 text-xs font-semibold cursor-pointer">
                اختيار ملف النسخة الاحتياطية
                <input type="file" className="hidden" onChange={restoreFromFile} />
              </label>
            </div>
          </form>
        ) : (
          <form onSubmit={submitLogin} className="space-y-3">
            <input type="text" value={username} onChange={(e) => setUsername(e.target.value)}
              placeholder="اسم المستخدم" className={inputCls} autoComplete="username" autoCapitalize="none" />
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)}
              placeholder="كلمة المرور" className={inputCls} autoComplete="current-password" />
            {error && <p className="text-xs text-rose-400">{error}</p>}
            <button type="submit" disabled={busy}
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold disabled:opacity-60">
              {busy ? 'جاري التحقق...' : 'دخول'}
            </button>
            <p className="text-[11px] text-slate-500 text-center">
              لو نسيت كلمة المرور، المالك يعيد تعيينها من لوحة المالك.
            </p>
          </form>
        )}
      </div>
    </div>
  );
};
