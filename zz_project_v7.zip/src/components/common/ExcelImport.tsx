import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import { FileSpreadsheet } from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { buildDump, ImportSummary, Sheets } from '../../utils/importBackup';
import { takeSnapshot } from '../../utils/backupStore';

const LABELS: Record<string, string> = {
  accounts: 'حسابات', journalEntries: 'قيود يومية', partners: 'شركاء', inventory: 'أصناف', warehouses: 'مخازن',
  employees: 'موظفين', attendance: 'سجل حضور', advances: 'سلف وخصومات', payroll: 'رواتب', partnerMoves: 'حركات شركاء',
  partnerDues: 'مستحقات', stockMoves: 'حركات مخزن', purchases: 'مشتريات', sales: 'مبيعات', parties: 'عملاء وموردين',
  documents: 'مستندات وصور',
};

export const ExcelImport: React.FC = () => {
  const { currentUser, restoreDatabaseFromJSON } = useERP();
  const [pending, setPending] = useState<{ data: Record<string, any>; summary: ImportSummary; file: string } | null>(null);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [noBalances, setNoBalances] = useState(true);
  const [skipItems, setSkipItems] = useState(true);

  if (currentUser.role !== 'owner') return null;

  const pick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    setMsg(null);
    setPending(null);
    setBusy(true);
    try {
      const wb = XLSX.read(await f.arrayBuffer(), { type: 'array' });
      const sheets: Sheets = {};
      wb.SheetNames.forEach((n) => {
        sheets[n] = XLSX.utils.sheet_to_json(wb.Sheets[n], { header: 1, raw: true, defval: '' }) as unknown[][];
      });
      const { data, summary } = buildDump(sheets);
      setPending({ data, summary, file: f.name });
    } catch (err) {
      setMsg({ ok: false, text: err instanceof Error ? err.message : 'تعذر قراءة ملف الإكسل.' });
    }
    setBusy(false);
  };

  const confirmImport = async () => {
    if (!pending) return;
    if (!window.confirm('الاستيراد هيستبدل الحسابات والقيود والشركاء والمخزن بالموجود في الملف. متأكد؟')) return;
    setBusy(true);
    try {
      await takeSnapshot('قبل الاستيراد', true);
      const d = skipItems ? { ...pending.data, inventory: [] } : pending.data;
      const data = noBalances
        ? { ...d, journalEntries: [], accounts: d.accounts.map((a: any) => ({ ...a, balance: 0 })),
            partners: d.partners.map((p: any) => ({ ...p, initialContribution: 0, currentBalance: 0 })),
            inventory: d.inventory.map((i: any) => ({ ...i, currentStock: 0 })) }
        : d;
      const res = restoreDatabaseFromJSON(JSON.stringify({ data }));
      setMsg({ ok: res.success, text: res.success ? 'تم الاستيراد. نسخة من وضعك السابق محفوظة في النسخ التلقائية.' : res.message });
      if (res.success) setPending(null);
    } catch {
      setMsg({ ok: false, text: 'فشل الاستيراد.' });
    }
    setBusy(false);
  };

  return (
    <div className="p-4 rounded-2xl bg-slate-900 border border-sky-500/40 space-y-3 text-xs">
      <div className="flex items-center gap-2 text-sky-300 font-bold text-sm">
        <FileSpreadsheet className="w-4 h-4" /> استيراد من ملف Excel (للمالك)
      </div>
      <p className="text-slate-400">اختر ملف نسخة الياسمين (xlsx). هتشوف ملخص الأول، ومفيش حاجة بتتغير إلا بعد ما توافق.</p>
      <label className="inline-block px-4 py-2 rounded-xl bg-sky-600 text-white font-bold cursor-pointer">
        اختيار ملف Excel
        <input type="file" accept=".xlsx,.xls" className="hidden" onChange={pick} disabled={busy} />
      </label>
      {pending && (
        <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
          <div className="text-white font-semibold">{pending.file}</div>
          <div className="flex flex-wrap gap-1.5">
            {Object.entries(pending.summary.counts).filter(([, n]) => n > 0).map(([k, n]) => (
              <span key={k} className="px-2 py-1 rounded-lg bg-slate-800 text-slate-200">{LABELS[k] || k}: {n}</span>
            ))}
          </div>
          <div className="text-slate-300">
            إجمالي المدين {pending.summary.totalDebit.toLocaleString('en-US')} · إجمالي الدائن {pending.summary.totalCredit.toLocaleString('en-US')}
          </div>
          {pending.summary.warnings.length > 0 && (
            <ul className="text-amber-300 list-disc pr-4">
              {pending.summary.warnings.slice(0, 8).map((w, i) => <li key={i}>{w}</li>)}
            </ul>
          )}
          <label className="flex items-center gap-2 text-slate-300">
            <input type="checkbox" checked={noBalances} onChange={(e) => setNoBalances(e.target.checked)} />
            استيراد الهيكل فقط (الحسابات والأصناف والشركاء) والأرصدة صفر
          </label>
          <label className="flex items-center gap-2 text-slate-300">
            <input type="checkbox" checked={skipItems} onChange={(e) => setSkipItems(e.target.checked)} />
            لا تستورد الأصناف (هدخلها بنفسي)
          </label>
          <button onClick={confirmImport} disabled={busy} className="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold">
            استيراد واستبدال البيانات
          </button>
        </div>
      )}
      {msg && <p className={msg.ok ? 'text-emerald-400' : 'text-rose-400'}>{msg.text}</p>}
    </div>
  );
};
