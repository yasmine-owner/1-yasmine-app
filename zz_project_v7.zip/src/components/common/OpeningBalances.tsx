import React, { useMemo, useState } from 'react';
import { Scale } from 'lucide-react';
import { useERP } from '../../context/ERPContext';

const fmt = (n: number) => (Number(n) || 0).toLocaleString('en-US');

export const OpeningBalances: React.FC = () => {
  const { accounts, journalEntries, addJournalEntry, currentUser } = useERP();
  const [open, setOpen] = useState(false);
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [vals, setVals] = useState<Record<string, { d: string; c: string }>>({});
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const leaf = useMemo(() => accounts.filter((a) => !accounts.some((x) => x.parentCode === a.code)), [accounts]);
  const existing = journalEntries.find((e) => !e.isReversed && /أول المدة/.test(e.description));

  if (!currentUser.permissions.canPost) return null;

  const set = (id: string, k: 'd' | 'c', v: string) => setVals((p) => ({ ...p, [id]: { d: p[id]?.d || '', c: p[id]?.c || '', [k]: v } }));
  const totD = leaf.reduce((s, a) => s + (Number(vals[a.id]?.d) || 0), 0);
  const totC = leaf.reduce((s, a) => s + (Number(vals[a.id]?.c) || 0), 0);
  const diff = totD - totC;

  const post = () => {
    const lines = leaf
      .filter((a) => (Number(vals[a.id]?.d) || 0) > 0 || (Number(vals[a.id]?.c) || 0) > 0)
      .map((a) => ({ accountId: a.id, accountCode: a.code, accountName: a.name,
        debit: Number(vals[a.id]?.d) || 0, credit: Number(vals[a.id]?.c) || 0 }));
    if (!lines.length) return setMsg({ ok: false, text: 'اكتب رصيداً واحداً على الأقل.' });
    const res = addJournalEntry({ date, description: 'أرصدة أول المدة', referenceType: 'capital', lines });
    setMsg({ ok: res.success, text: res.message });
    if (res.success) setVals({});
  };

  const cls = 'w-24 px-2 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-white text-xs text-left';

  return (
    <div className="p-4 rounded-2xl bg-slate-900 border border-violet-500/40 space-y-3 text-xs">
      <button onClick={() => setOpen(!open)} className="w-full flex items-center justify-between text-violet-300 font-bold text-sm">
        <span className="flex items-center gap-2"><Scale className="w-4 h-4" /> أرصدة أول المدة</span>
        <span>{open ? 'إخفاء' : 'فتح'}</span>
      </button>
      {open && (
        <>
          {existing && (
            <p className="text-amber-300">
              يوجد قيد أول مدة بتاريخ {existing.date}. لتعديل الأرصدة: اعكس القيد ({existing.entryNumber}) من سجل القيود ثم أعد الإدخال هنا.
            </p>
          )}
          <p className="text-slate-400">اكتب رصيد كل حساب في خانة مدين أو دائن. القيد لازم يتوازن قبل الترحيل.</p>
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)}
            className="px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs" />
          <div className="max-h-80 overflow-y-auto space-y-1.5">
            <div className="flex justify-between text-[10px] text-slate-500 px-1"><span>الحساب</span><span className="flex gap-2"><span className="w-24 text-center">مدين</span><span className="w-24 text-center">دائن</span></span></div>
            {leaf.map((a) => (
              <div key={a.id} className="flex items-center justify-between gap-2 p-1.5 rounded-lg bg-slate-950 border border-slate-800">
                <span className="text-slate-200 flex-1">{a.code} — {a.name}</span>
                <input type="number" inputMode="decimal" min="0" value={vals[a.id]?.d || ''} onChange={(e) => set(a.id, 'd', e.target.value)} className={cls} />
                <input type="number" inputMode="decimal" min="0" value={vals[a.id]?.c || ''} onChange={(e) => set(a.id, 'c', e.target.value)} className={cls} />
              </div>
            ))}
          </div>
          <div className="flex justify-between text-slate-300">
            <span>مدين {fmt(totD)}</span><span>دائن {fmt(totC)}</span>
            <span className={Math.abs(diff) < 0.01 ? 'text-emerald-400' : 'text-rose-400'}>الفرق {fmt(diff)}</span>
          </div>
          {msg && <p className={msg.ok ? 'text-emerald-400' : 'text-rose-400'}>{msg.text}</p>}
          <button onClick={post} disabled={Math.abs(diff) > 0.01 || totD <= 0}
            className="w-full py-2.5 rounded-xl bg-violet-600 text-white font-bold disabled:opacity-50">ترحيل قيد أول المدة</button>
        </>
      )}
    </div>
  );
};
