import React, { useState } from 'react';
import { Eraser } from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { takeSnapshot } from '../../utils/backupStore';

export const ZeroReset: React.FC = () => {
  const { currentUser, startFromZero } = useERP();
  const [msg, setMsg] = useState('');
  if (currentUser.role !== 'owner') return null;

  const run = async () => {
    if (!window.confirm('هيتم مسح كل القيود، وتصفير أرصدة الحسابات والشركاء والمخزون، ومسح الماكينات والأدوات وأوامر الإنتاج والهالك. دليل الحسابات وقائمة الأصناف والمستخدمين يفضلوا. متأكد؟')) return;
    await takeSnapshot('قبل التصفير', true).catch(() => null);
    startFromZero();
    setMsg('تم التصفير. نسخة من وضعك السابق محفوظة في النسخ التلقائية لو احتجت ترجع.');
  };

  return (
    <div className="p-4 rounded-2xl bg-slate-900 border border-rose-500/40 space-y-3 text-xs">
      <div className="flex items-center gap-2 text-rose-300 font-bold text-sm">
        <Eraser className="w-4 h-4" /> البدء من صفر (للمالك)
      </div>
      <p className="text-slate-400">يمسح الحركات والأرصدة التجريبية ويخلي كل حاجة صفر، وبعدها تدخل أرصدة أول المدة بنفسك من صفحة القيود.</p>
      <button onClick={run} className="px-4 py-2 rounded-xl bg-rose-600 text-white font-bold">تصفير الأرصدة والحركات</button>
      {msg && <p className="text-emerald-400">{msg}</p>}
    </div>
  );
};
