// Converts Arabic-Indic (٠-٩) and Persian (۰-۹) digits to 0-9 so PINs typed on an Arabic keyboard still match.
export const normDigits = (s: string): string =>
  s.replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d))).replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)));
