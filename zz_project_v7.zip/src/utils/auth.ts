// Local password vault (PBKDF2-SHA256). Stored separately from the ERP data dump.
const KEY = 'erp_auth_v1';
const ITER = 150000;
import { normDigits } from './digits';
const enc = new TextEncoder();

interface Cred { s: string; h: string; i: number }
interface Store { creds: Record<string, Cred>; n: number; until: number }

const load = (): Store => {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const p = JSON.parse(raw);
      return { creds: p.creds || {}, n: p.n || 0, until: p.until || 0 };
    }
  } catch {
    /* ignore */
  }
  return { creds: {}, n: 0, until: 0 };
};

const save = (s: Store) => {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    /* ignore */
  }
};

const b64 = (buf: ArrayBuffer | Uint8Array) =>
  btoa(String.fromCharCode(...new Uint8Array(buf as ArrayBuffer)));
const fromB64 = (s: string) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

async function derive(pw: string, salt: Uint8Array, iter: number): Promise<string> {
  const key = await crypto.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt: salt as BufferSource, iterations: iter, hash: 'SHA-256' },
    key,
    256
  );
  return b64(bits);
}

const norm = (u: string) => u.trim().toLowerCase();

export const hasCredential = (username: string): boolean => !!load().creds[norm(username)];

export async function setCredential(username: string, password: string): Promise<void> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const h = await derive(normDigits(password), salt, ITER);
  const s = load();
  s.creds[norm(username)] = { s: b64(salt), h, i: ITER };
  save(s);
}

export async function verifyCredential(username: string, password: string): Promise<boolean> {
  const c = load().creds[norm(username)];
  if (!c) return false;
  const same = (h: string) => {
    if (h.length !== c.h.length) return false;
    let diff = 0;
    for (let i = 0; i < h.length; i++) diff |= h.charCodeAt(i) ^ c.h.charCodeAt(i);
    return diff === 0;
  };
  if (same(await derive(password, fromB64(c.s), c.i))) return true;
  const n = normDigits(password);
  return n !== password && same(await derive(n, fromB64(c.s), c.i));
}

export const getLockUntil = (): number => load().until;

export const recordFailure = () => {
  const s = load();
  s.n += 1;
  if (s.n >= 5) {
    s.until = Date.now() + 60000;
    s.n = 0;
  }
  save(s);
};

export const clearFailures = () => {
  const s = load();
  s.n = 0;
  s.until = 0;
  save(s);
};
