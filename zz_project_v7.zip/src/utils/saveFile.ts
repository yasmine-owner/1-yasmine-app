import { Capacitor } from '@capacitor/core';

const FOLDER = 'FactoryERP';
const remember = () => { try { localStorage.setItem('erp_last_export', String(Date.now())); } catch { /* ignore */ } };

// Android app: try Documents/FactoryERP first, fall back to the app cache, then open the share sheet.
async function saveNative(filename: string, data: string, utf8: boolean): Promise<boolean> {
  const { Filesystem, Directory, Encoding } = await import('@capacitor/filesystem');
  const { Share } = await import('@capacitor/share');
  const opts = (directory: any, path: string) => ({ path, data, directory, recursive: true, ...(utf8 ? { encoding: Encoding.UTF8 } : {}) });
  let uri = '';
  let inFolder = false;
  try {
    await Filesystem.requestPermissions().catch(() => undefined);
    uri = (await Filesystem.writeFile(opts(Directory.Documents, `${FOLDER}/${filename}`))).uri;
    inFolder = true;
  } catch {
    uri = (await Filesystem.writeFile(opts(Directory.Cache, filename))).uri;
  }
  remember();
  try { await Share.share({ title: filename, url: uri, dialogTitle: 'حفظ أو مشاركة الملف' }); } catch { /* user closed the sheet */ }
  return inFolder;
}

function saveWeb(filename: string, blob: Blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
  remember();
}

export async function saveTextFile(filename: string, content: string, mime = 'application/json') {
  if (Capacitor.isNativePlatform()) {
    const inFolder = await saveNative(filename, content, true);
    if (inFolder) window.alert(`تم حفظ الملف في مجلد Documents/${FOLDER}`);
    return;
  }
  saveWeb(filename, new Blob([content], { type: mime }));
}

export async function saveBase64File(filename: string, base64: string, mime: string) {
  if (Capacitor.isNativePlatform()) {
    const inFolder = await saveNative(filename, base64, false);
    if (inFolder) window.alert(`تم حفظ الملف في مجلد Documents/${FOLDER}`);
    return;
  }
  const bytes = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
  saveWeb(filename, new Blob([bytes], { type: mime }));
}
