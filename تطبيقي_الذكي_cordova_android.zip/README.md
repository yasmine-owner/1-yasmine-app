# تطبيقي الذكي - Apache Cordova APK Build Package

تعليمات تحويل المشروع إلى ملف APK لنظام الأندرويد:

### الطريقة الأولى: باستخدام الحاسوب و Cordova CLI (الموصى بها)
1. قم بفك الضغط عن هذا الملف في مجلد على حاسوبك.
2. تأكد من تثبيت Node.js ثم افتح موجه الأوامر (Terminal) وثبّت Cordova:
   ```bash
   npm install -g cordova
   ```
3. قم بإضافة منصة الأندرويد:
   ```bash
   cordova platform add android
   ```
4. قم ببناء ملف الـ APK:
   ```bash
   cordova build android --release
   ```
5. ستجد ملف الـ APK جاهزاً في المجلد:
   `platforms/android/app/build/outputs/apk/release/app-release-unsigned.apk`

---

### الطريقة الثانية: تحويل أونلاين بضغطة زر (بدون تثبيت أدوات)
1. قم برفع هذا الملف المضغوط إلى موقع VoltBuilder (voltbuilder.com) أو PWABuilder (pwabuilder.com).
2. اختر بناء ملف APK وسيقوم الموقع بتسليمه لك مباشرة في ثوانٍ معدودة!

---

English Instructions:
1. Extract zip file.
2. Install cordova: `npm install -g cordova`
3. Add platform: `cordova platform add android`
4. Build APK: `cordova build android --release`
