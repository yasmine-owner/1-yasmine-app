// App Interactive Logic
let counter = 0;

function updateCounter(val) {
  counter += val;
  const counterEl = document.getElementById('counterValue');
  if (counterEl) {
    counterEl.innerText = counter;
  }
}

function saveData() {
  const input = document.getElementById('userInput');
  const result = document.getElementById('savedResult');
  if (input && input.value.trim() !== '') {
    localStorage.setItem('my_app_data', input.value);
    if (result) {
      result.innerText = 'تم الحفظ بنجاح: ' + input.value;
    }
  }
}

function goToSecondPage() {
  window.location.href = 'page2.html';
}

function showNativeAlert() {
  alert('مرحباً بك! هذا تنبيه أندرويد يعمل بشكل ممتاز في تطبيقك 🚀');
}

// Load saved data on start
document.addEventListener('DOMContentLoaded', () => {
  const saved = localStorage.getItem('my_app_data');
  const result = document.getElementById('savedResult');
  if (saved && result) {
    result.innerText = 'البيانات المحفوظة سابقاً: ' + saved;
  }
});