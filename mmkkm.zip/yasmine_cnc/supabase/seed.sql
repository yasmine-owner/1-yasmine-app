-- Reference data only. No fake users, listings, OTP codes or administrator passwords.

insert into public.categories (slug, name_ar, name_en, icon, sort_order) values
  ('cnc-machines','ماكينات CNC','CNC Machines','precision_manufacturing',10),
  ('turning-milling','خراطة وتفريز','Turning & Milling','settings',20),
  ('laser-cutting','ليزر وقطع','Laser & Cutting','content_cut',30),
  ('cad-cam','تصميم وبرمجة CAD/CAM','CAD/CAM Design','architecture',40),
  ('cutting-tools','عدد وأدوات قاطعة','Cutting Tools','handyman',50),
  ('raw-materials','خامات ومعادن','Raw Materials','view_in_ar',60),
  ('spare-parts','قطع غيار','Spare Parts','build',70),
  ('molds','قوالب وإسطمبات','Molds & Dies','category',80),
  ('medical-manufacturing','تصنيع طبي','Medical Manufacturing','medical_services',90),
  ('training','تعليم وتدريب','Education & Training','school',100)
on conflict (slug) do update set
  name_ar = excluded.name_ar,
  name_en = excluded.name_en,
  icon = excluded.icon,
  sort_order = excluded.sort_order;

insert into public.app_settings (key, value, is_public) values
  ('theme', '{
    "primary": 4278921802,
    "secondary": 4278236376,
    "success": 4279286145,
    "background": 4294047225,
    "text": 4279249475,
    "darkMode": false,
    "fontFamily": "NotoSansArabic",
    "fontScale": 1,
    "borderRadius": 16
  }'::jsonb, true),
  ('general', '{
    "platform_name_ar": "ياسمين CNC",
    "platform_name_en": "Yasmine CNC",
    "commission_rate": 5
  }'::jsonb, true)
on conflict (key) do nothing;

insert into public.home_sections (key, title_ar, title_en, section_type, sort_order) values
  ('hero','من الرسم إلى التصنيع','From drawing to manufacturing','hero',10),
  ('services','الخدمات الأساسية','Core services','services',20),
  ('requests','أحدث طلبات التصنيع','Latest manufacturing requests','requests',30),
  ('products','المختار من السوق','Marketplace picks','products',40),
  ('workshops','ورش ومصانع موثّقة','Verified industrial facilities','workshops',50)
on conflict (key) do update set
  title_ar = excluded.title_ar,
  title_en = excluded.title_en,
  section_type = excluded.section_type,
  sort_order = excluded.sort_order;

-- After the first owner signs up through real OTP, promote that account explicitly:
-- update public.profiles set role = 'admin' where id = 'AUTH-USER-UUID';
-- This statement is intentionally commented: never ship a default administrator.
