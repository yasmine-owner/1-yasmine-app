-- Yasmine CNC: authorization, transactional operations, RLS and private storage

create or replace function public.is_active_user()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and is_active = true
  );
$$;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin' and is_active = true
  );
$$;

create or replace function public.is_org_member(p_organization_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.organization_members
    where organization_id = p_organization_id
      and user_id = auth.uid()
      and is_active = true
  );
$$;

create or replace function public.is_org_manager(p_organization_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.organization_members
    where organization_id = p_organization_id
      and user_id = auth.uid()
      and role in ('owner','manager')
      and is_active = true
  );
$$;

create or replace function public.is_conversation_participant(p_conversation_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.conversation_participants
    where conversation_id = p_conversation_id and user_id = auth.uid()
  );
$$;

create or replace function public.can_view_request(p_request_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.manufacturing_requests r
    where r.id = p_request_id and (
      r.owner_id = auth.uid()
      or (r.visibility = 'public' and r.status <> 'draft')
      or exists (
        select 1 from public.request_invitations i
        where i.request_id = r.id and public.is_org_member(i.organization_id)
      )
      or exists (
        select 1 from public.quotes q
        where q.request_id = r.id and public.is_org_member(q.provider_id)
      )
    )
  );
$$;

create or replace function public.can_access_request_files(p_request_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select public.is_admin() or exists (
    select 1 from public.manufacturing_requests r
    where r.id = p_request_id and (
      r.owner_id = auth.uid()
      or exists (
        select 1 from public.request_invitations i
        where i.request_id = r.id and public.is_org_member(i.organization_id)
      )
      or exists (
        select 1 from public.quotes q
        where q.request_id = r.id and public.is_org_member(q.provider_id)
      )
    )
  );
$$;

create or replace function public.can_access_order(p_order_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.orders o
    where o.id = p_order_id
      and (o.customer_id = auth.uid() or public.is_org_member(o.provider_id))
  );
$$;

create or replace function public.protect_profile_fields()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is not null and not public.is_admin() and (
    new.role is distinct from old.role
    or new.is_active is distinct from old.is_active
    or new.is_verified is distinct from old.is_verified
  ) then
    raise exception 'Only an administrator can change role, active or verification status';
  end if;
  return new;
end;
$$;

create trigger protect_profile_fields_trigger
before update on public.profiles
for each row execute function public.protect_profile_fields();

create or replace function public.protect_organization_fields()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is not null and not public.is_admin() and (
    new.owner_id is distinct from old.owner_id
    or new.verification_status is distinct from old.verification_status
    or new.is_active is distinct from old.is_active
  ) then
    raise exception 'Only an administrator can change ownership, active or verification status';
  end if;
  return new;
end;
$$;

create trigger protect_organization_fields_trigger
before update on public.organizations
for each row execute function public.protect_organization_fields();

create or replace function public.protect_workshop_fields()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is not null and not public.is_admin() and (
    new.verification_status is distinct from old.verification_status
    or new.is_active is distinct from old.is_active
  ) then
    raise exception 'Only an administrator can change workshop active or verification status';
  end if;
  return new;
end;
$$;

create trigger protect_workshop_fields_trigger
before update on public.workshops
for each row execute function public.protect_workshop_fields();

create or replace function public.get_public_stats()
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select jsonb_build_object(
    'users', (select count(*) from public.profiles where is_active),
    'requests', (select count(*) from public.manufacturing_requests where status = 'open' and visibility = 'public'),
    'products', (select count(*) from public.products where status = 'active')
  );
$$;

create or replace function public.create_facility(
  p_name_ar text,
  p_name_en text,
  p_description text,
  p_city text,
  p_capabilities text[] default '{}'
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_organization_id uuid;
  v_workshop_id uuid;
begin
  if not public.is_active_user() then
    raise exception 'An active authenticated profile is required';
  end if;
  if char_length(trim(p_name_ar)) < 2 or char_length(trim(p_name_en)) < 2 then
    raise exception 'Facility names are required';
  end if;
  if char_length(trim(p_description)) < 10 or char_length(trim(p_city)) < 2 then
    raise exception 'Description and city are required';
  end if;

  insert into public.organizations (
    owner_id, kind, name_ar, name_en, description, city, verification_status
  ) values (
    auth.uid(), 'workshop', trim(p_name_ar), trim(p_name_en), trim(p_description), trim(p_city), 'pending'
  ) returning id into v_organization_id;

  insert into public.organization_members (organization_id, user_id, role)
  values (v_organization_id, auth.uid(), 'owner');

  insert into public.workshops (
    organization_id, description, city, capabilities, verification_status
  ) values (
    v_organization_id, trim(p_description), trim(p_city), coalesce(p_capabilities, '{}'), 'pending'
  ) returning id into v_workshop_id;

  insert into public.verification_requests (
    user_id, organization_id, document_type, notes
  ) values (
    auth.uid(), v_organization_id, 'facility_profile', 'Facility profile submitted for administrative review'
  );

  insert into public.audit_logs (actor_id, action, entity_type, entity_id, new_data)
  values (auth.uid(), 'facility_created', 'organization', v_organization_id::text,
    jsonb_build_object('workshop_id', v_workshop_id, 'status', 'pending'));

  return v_organization_id;
end;
$$;

create or replace function public.accept_quote(p_quote_id uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_quote public.quotes%rowtype;
  v_request public.manufacturing_requests%rowtype;
  v_order_id uuid;
  v_conversation_id uuid;
  v_commission numeric(5,2);
begin
  if not public.is_active_user() then
    raise exception 'An active authenticated profile is required';
  end if;

  select * into v_quote from public.quotes where id = p_quote_id for update;
  if not found then raise exception 'Quote not found'; end if;

  select * into v_request from public.manufacturing_requests
  where id = v_quote.request_id for update;

  if v_request.owner_id <> auth.uid() then
    raise exception 'Only the request owner can accept a quote';
  end if;
  if v_request.status <> 'open' or v_quote.status <> 'pending' then
    raise exception 'This quote can no longer be accepted';
  end if;

  update public.quotes set status = 'accepted' where id = v_quote.id;
  update public.quotes set status = 'rejected'
  where request_id = v_quote.request_id and id <> v_quote.id and status = 'pending';
  update public.manufacturing_requests set status = 'in_progress' where id = v_request.id;

  select coalesce((value ->> 'commission_rate')::numeric, 0)
  into v_commission from public.app_settings where key = 'general';
  v_commission := coalesce(v_commission, 0);

  insert into public.orders (
    request_id, quote_id, customer_id, provider_id, total, commission_rate, status
  ) values (
    v_request.id, v_quote.id, auth.uid(), v_quote.provider_id, v_quote.amount, v_commission, 'in_progress'
  ) returning id into v_order_id;

  insert into public.order_status_history (order_id, changed_by, to_status, notes)
  values (v_order_id, auth.uid(), 'in_progress', 'Quote accepted');

  insert into public.conversations (request_id, order_id, title, created_by)
  values (v_request.id, v_order_id, v_request.title, auth.uid())
  returning id into v_conversation_id;

  insert into public.conversation_participants (conversation_id, user_id)
  values (v_conversation_id, auth.uid());

  insert into public.conversation_participants (conversation_id, user_id)
  select v_conversation_id, user_id from public.organization_members
  where organization_id = v_quote.provider_id and is_active
  on conflict do nothing;

  insert into public.notifications (user_id, type, title, body, data)
  select m.user_id, 'quote_accepted',
    case p.preferred_language
      when 'ar' then 'تم قبول عرض السعر'
      else 'Quote accepted'
    end,
    case p.preferred_language
      when 'ar' then 'تم قبول عرض السعر وإنشاء الطلب.'
      else 'Your quote was accepted and an order was created.'
    end,
    jsonb_build_object('order_id', v_order_id, 'conversation_id', v_conversation_id)
  from public.organization_members m
  join public.profiles p on p.id = m.user_id
  where m.organization_id = v_quote.provider_id and m.is_active;

  insert into public.audit_logs (actor_id, action, entity_type, entity_id, new_data)
  values (auth.uid(), 'quote_accepted', 'order', v_order_id::text,
    jsonb_build_object('quote_id', v_quote.id, 'total', v_quote.amount));

  return v_order_id;
end;
$$;

create or replace function public.change_order_status(
  p_order_id uuid,
  p_new_status text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_order public.orders%rowtype;
  v_is_customer boolean;
  v_is_provider boolean;
  v_allowed boolean := false;
  v_customer_language text;
begin
  if not public.is_active_user() then raise exception 'An active profile is required'; end if;
  select * into v_order from public.orders where id = p_order_id for update;
  if not found then raise exception 'Order not found'; end if;
  v_is_customer := v_order.customer_id = auth.uid();
  v_is_provider := public.is_org_manager(v_order.provider_id);
  if not v_is_customer and not v_is_provider then raise exception 'Order access denied'; end if;

  v_allowed := case
    when p_new_status = 'quality_check' then v_is_provider and v_order.status = 'in_progress'
    when p_new_status = 'shipped' then v_is_provider and v_order.status = 'quality_check'
    when p_new_status = 'completed' then v_is_customer and v_order.status = 'shipped'
    when p_new_status = 'cancelled' then v_is_customer and v_order.status = 'in_progress'
    when p_new_status = 'disputed' then v_order.status not in ('completed','cancelled','disputed')
    else false
  end;
  if not v_allowed then raise exception 'Invalid order status transition'; end if;

  update public.orders set status = p_new_status where id = v_order.id;
  insert into public.order_status_history (order_id, changed_by, from_status, to_status)
  values (v_order.id, auth.uid(), v_order.status, p_new_status);

  update public.manufacturing_requests
  set status = case p_new_status
    when 'completed' then 'completed'
    when 'cancelled' then 'cancelled'
    when 'disputed' then 'disputed'
    else 'in_progress'
  end where id = v_order.request_id;

  if p_new_status = 'completed' then
    update public.workshops set completed_orders = completed_orders + 1
    where organization_id = v_order.provider_id;
  end if;

  if v_is_customer then
    insert into public.notifications (user_id, type, title, body, data)
    select m.user_id, 'order_status',
      case p.preferred_language
        when 'ar' then 'تم تحديث حالة الطلب'
        else 'Order status updated'
      end,
      case p.preferred_language
        when 'ar' then 'الطلب ' || v_order.order_number || ' أصبح الآن: ' ||
          case p_new_status
            when 'quality_check' then 'فحص الجودة'
            when 'shipped' then 'تم الشحن'
            when 'completed' then 'مكتمل'
            when 'cancelled' then 'ملغي'
            when 'disputed' then 'قيد النزاع'
            else 'قيد التنفيذ'
          end
        else 'Order ' || v_order.order_number || ' is now ' || p_new_status
      end,
      jsonb_build_object('order_id', v_order.id, 'status', p_new_status)
    from public.organization_members m
    join public.profiles p on p.id = m.user_id
    where m.organization_id = v_order.provider_id and m.is_active;
  else
    select coalesce(preferred_language, 'ar') into v_customer_language
    from public.profiles where id = v_order.customer_id;
    insert into public.notifications (user_id, type, title, body, data)
    values (v_order.customer_id, 'order_status',
      case v_customer_language
        when 'ar' then 'تم تحديث حالة الطلب'
        else 'Order status updated'
      end,
      case v_customer_language
        when 'ar' then 'الطلب ' || v_order.order_number || ' أصبح الآن: ' ||
          case p_new_status
            when 'quality_check' then 'فحص الجودة'
            when 'shipped' then 'تم الشحن'
            when 'completed' then 'مكتمل'
            when 'cancelled' then 'ملغي'
            when 'disputed' then 'قيد النزاع'
            else 'قيد التنفيذ'
          end
        else 'Order ' || v_order.order_number || ' is now ' || p_new_status
      end,
      jsonb_build_object('order_id', v_order.id, 'status', p_new_status));
  end if;

  insert into public.audit_logs (actor_id, action, entity_type, entity_id, new_data)
  values (auth.uid(), 'order_status_changed', 'order', v_order.id::text,
    jsonb_build_object('from', v_order.status, 'to', p_new_status));
end;
$$;

create or replace function public.review_verification(
  p_request_id uuid,
  p_approved boolean,
  p_notes text default ''
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_request public.verification_requests%rowtype;
  v_status text;
  v_language text;
begin
  if not public.is_admin() then raise exception 'Administrator access required'; end if;
  select * into v_request from public.verification_requests where id = p_request_id for update;
  if not found or v_request.status <> 'pending' then
    raise exception 'Pending verification request not found';
  end if;
  v_status := case when p_approved then 'approved' else 'rejected' end;

  update public.verification_requests
  set status = v_status, notes = trim(p_notes), reviewed_by = auth.uid(), reviewed_at = now()
  where id = p_request_id;

  if v_request.organization_id is not null then
    update public.organizations set verification_status = v_status where id = v_request.organization_id;
    update public.workshops set verification_status = v_status where organization_id = v_request.organization_id;
  end if;
  if v_request.user_id is not null and p_approved then
    update public.profiles set is_verified = true where id = v_request.user_id;
  end if;

  if v_request.user_id is not null then
    select coalesce(preferred_language, 'ar') into v_language
    from public.profiles where id = v_request.user_id;
    insert into public.notifications (user_id, type, title, body, data)
    values (v_request.user_id, 'verification_reviewed',
      case v_language
        when 'ar' then case when p_approved then 'تم اعتماد التوثيق' else 'طلب التوثيق يحتاج مراجعة' end
        else 'Verification ' || v_status
      end,
      case v_language
        when 'ar' then case when p_approved then 'تم اعتماد طلب التوثيق بنجاح.' else 'يرجى مراجعة ملاحظات الإدارة واستكمال المطلوب.' end
        else case when p_approved then 'Your verification has been approved.' else 'Your verification needs attention.' end
      end,
      jsonb_build_object('verification_id', p_request_id, 'status', v_status));
  elsif v_request.organization_id is not null then
    insert into public.notifications (user_id, type, title, body, data)
    select m.user_id, 'verification_reviewed',
      case p.preferred_language
        when 'ar' then case when p_approved then 'تم اعتماد التوثيق' else 'طلب التوثيق يحتاج مراجعة' end
        else 'Verification ' || v_status
      end,
      case p.preferred_language
        when 'ar' then case when p_approved then 'تم اعتماد طلب التوثيق بنجاح.' else 'يرجى مراجعة ملاحظات الإدارة واستكمال المطلوب.' end
        else case when p_approved then 'Your verification has been approved.' else 'Your verification needs attention.' end
      end,
      jsonb_build_object('verification_id', p_request_id, 'status', v_status)
    from public.organization_members m
    join public.profiles p on p.id = m.user_id
    where m.organization_id = v_request.organization_id and m.is_active;
  end if;

  insert into public.audit_logs (actor_id, action, entity_type, entity_id, new_data)
  values (auth.uid(), 'verification_reviewed', 'verification_request', p_request_id::text,
    jsonb_build_object('approved', p_approved, 'notes', p_notes));
end;
$$;

create or replace function public.toggle_post_like(p_post_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_active_user() then raise exception 'An active profile is required'; end if;
  if not exists (select 1 from public.posts where id = p_post_id and status = 'published') then
    raise exception 'Post not found';
  end if;
  if exists (select 1 from public.post_likes where post_id = p_post_id and user_id = auth.uid()) then
    delete from public.post_likes where post_id = p_post_id and user_id = auth.uid();
    return false;
  end if;
  insert into public.post_likes (post_id, user_id) values (p_post_id, auth.uid());
  return true;
end;
$$;

create or replace function public.write_audit_log(
  p_action text,
  p_entity_type text,
  p_entity_id text,
  p_new_data jsonb default '{}'::jsonb
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_admin() then raise exception 'Administrator access required'; end if;
  insert into public.audit_logs (actor_id, action, entity_type, entity_id, new_data)
  values (auth.uid(), p_action, p_entity_type, p_entity_id, p_new_data);
end;
$$;

create or replace function public.refresh_organization_rating()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_organization uuid := coalesce(new.organization_id, old.organization_id);
begin
  update public.organizations set updated_at = now() where id = v_organization;
  update public.workshops w
  set rating_average = stats.average, rating_count = stats.total
  from (
    select organization_id, round(avg(rating)::numeric, 2) as average, count(*) as total
    from public.reviews where organization_id = v_organization group by organization_id
  ) stats
  where w.organization_id = stats.organization_id;
  if not exists (select 1 from public.reviews where organization_id = v_organization) then
    update public.workshops set rating_average = 0, rating_count = 0 where organization_id = v_organization;
  end if;
  return coalesce(new, old);
end;
$$;

create trigger refresh_rating_after_review
after insert or update or delete on public.reviews
for each row execute function public.refresh_organization_rating();

create or replace function public.touch_conversation_on_message()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.conversations set updated_at = now() where id = new.conversation_id;
  return new;
end;
$$;

create trigger touch_conversation_after_message
after insert on public.messages
for each row execute function public.touch_conversation_on_message();

-- Row Level Security
do $$
declare table_name text;
begin
  foreach table_name in array array[
    'profiles','organizations','organization_members','verification_requests',
    'categories','workshops','machines','products','product_images',
    'manufacturing_requests','request_invitations','request_attachments','quotes',
    'orders','order_status_history','conversations','conversation_participants',
    'messages','jobs','job_applications','posts','post_comments','post_likes',
    'courses','course_enrollments','favorites','reviews','reports','disputes',
    'notifications','user_devices','app_settings','home_sections','app_banners','audit_logs'
  ] loop
    execute format('alter table public.%I enable row level security', table_name);
    execute format(
      'create policy %I_admin_all on public.%I for all to authenticated using (public.is_admin()) with check (public.is_admin())',
      table_name, table_name
    );
  end loop;
end;
$$;

-- Profiles: professional data is readable by signed-in users; sensitive state changes are trigger-protected.
create policy profiles_read on public.profiles for select to authenticated
using (is_active or id = auth.uid());
create policy profiles_update_own on public.profiles for update to authenticated
using (id = auth.uid()) with check (id = auth.uid());

create policy organizations_read on public.organizations for select to authenticated
using ((verification_status = 'approved' and is_active) or public.is_org_member(id));
create policy organizations_update_manager on public.organizations for update to authenticated
using (public.is_org_manager(id)) with check (public.is_org_manager(id));

create policy organization_members_read on public.organization_members for select to authenticated
using (user_id = auth.uid() or public.is_org_member(organization_id));
create policy organization_members_manage on public.organization_members for all to authenticated
using (public.is_org_manager(organization_id))
with check (public.is_org_manager(organization_id));

create policy verification_read_own on public.verification_requests for select to authenticated
using (user_id = auth.uid() or public.is_org_manager(organization_id));
create policy verification_insert_own on public.verification_requests for insert to authenticated
with check (public.is_active_user() and (user_id = auth.uid() or public.is_org_manager(organization_id)));

create policy categories_public_read on public.categories for select to anon, authenticated
using (is_active);

create policy workshops_read on public.workshops for select to authenticated
using (is_active or public.is_org_member(organization_id));
create policy workshops_manage on public.workshops for update to authenticated
using (public.is_org_manager(organization_id)) with check (public.is_org_manager(organization_id));

create policy machines_read on public.machines for select to authenticated
using (exists (
  select 1 from public.workshops w where w.id = workshop_id and (w.is_active or public.is_org_member(w.organization_id))
));
create policy machines_manage on public.machines for all to authenticated
using (exists (select 1 from public.workshops w where w.id = workshop_id and public.is_org_manager(w.organization_id)))
with check (exists (select 1 from public.workshops w where w.id = workshop_id and public.is_org_manager(w.organization_id)));

create policy products_read on public.products for select to authenticated
using (status = 'active' or seller_id = auth.uid() or public.is_org_member(organization_id));
create policy products_insert on public.products for insert to authenticated
with check (public.is_active_user() and seller_id = auth.uid() and status = 'pending');
create policy products_update_seller on public.products for update to authenticated
using (seller_id = auth.uid() and status = 'pending')
with check (seller_id = auth.uid() and status = 'pending');

create policy product_images_read on public.product_images for select to authenticated
using (exists (select 1 from public.products p where p.id = product_id and (p.status = 'active' or p.seller_id = auth.uid())));
create policy product_images_manage on public.product_images for all to authenticated
using (exists (select 1 from public.products p where p.id = product_id and p.seller_id = auth.uid()))
with check (exists (select 1 from public.products p where p.id = product_id and p.seller_id = auth.uid()));

create policy requests_read on public.manufacturing_requests for select to authenticated
using (public.can_view_request(id));
create policy requests_insert on public.manufacturing_requests for insert to authenticated
with check (public.is_active_user() and owner_id = auth.uid());
create policy requests_update_owner on public.manufacturing_requests for update to authenticated
using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy invitations_read on public.request_invitations for select to authenticated
using (public.can_view_request(request_id));
create policy invitations_manage on public.request_invitations for all to authenticated
using (exists (select 1 from public.manufacturing_requests r where r.id = request_id and r.owner_id = auth.uid()))
with check (exists (select 1 from public.manufacturing_requests r where r.id = request_id and r.owner_id = auth.uid()));

create policy attachments_read on public.request_attachments for select to authenticated
using (public.can_access_request_files(request_id));
create policy attachments_insert on public.request_attachments for insert to authenticated
with check (uploaded_by = auth.uid() and exists (
  select 1 from public.manufacturing_requests r where r.id = request_id and r.owner_id = auth.uid()
));
create policy attachments_delete on public.request_attachments for delete to authenticated
using (uploaded_by = auth.uid());

create policy quotes_read on public.quotes for select to authenticated
using (public.is_org_member(provider_id) or exists (
  select 1 from public.manufacturing_requests r where r.id = request_id and r.owner_id = auth.uid()
));
create policy quotes_insert on public.quotes for insert to authenticated
with check (
  public.is_active_user() and public.is_org_member(provider_id) and status = 'pending'
  and exists (
    select 1 from public.manufacturing_requests r
    where r.id = request_id and r.status = 'open' and r.owner_id <> auth.uid()
      and (r.visibility = 'public' or exists (
        select 1 from public.request_invitations i where i.request_id = r.id and i.organization_id = provider_id
      ))
  )
);
create policy quotes_update_provider on public.quotes for update to authenticated
using (public.is_org_manager(provider_id) and status = 'pending')
with check (public.is_org_manager(provider_id) and status in ('pending','withdrawn'));

create policy orders_read on public.orders for select to authenticated
using (public.can_access_order(id));
create policy order_history_read on public.order_status_history for select to authenticated
using (public.can_access_order(order_id));
create policy order_history_insert on public.order_status_history for insert to authenticated
with check (public.can_access_order(order_id) and changed_by = auth.uid());

create policy conversations_read on public.conversations for select to authenticated
using (public.is_conversation_participant(id));
create policy participants_read on public.conversation_participants for select to authenticated
using (public.is_conversation_participant(conversation_id));
create policy participants_update_own on public.conversation_participants for update to authenticated
using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy messages_read on public.messages for select to authenticated
using (public.is_conversation_participant(conversation_id));
create policy messages_insert on public.messages for insert to authenticated
with check (
  public.is_active_user() and sender_id = auth.uid()
  and public.is_conversation_participant(conversation_id)
);

create policy jobs_read on public.jobs for select to authenticated
using (status = 'open' or public.is_org_member(organization_id));
create policy jobs_manage on public.jobs for all to authenticated
using (public.is_org_manager(organization_id)) with check (public.is_org_manager(organization_id));

create policy applications_read on public.job_applications for select to authenticated
using (applicant_id = auth.uid() or exists (
  select 1 from public.jobs j where j.id = job_id and public.is_org_member(j.organization_id)
));
create policy applications_insert on public.job_applications for insert to authenticated
with check (public.is_active_user() and applicant_id = auth.uid() and exists (
  select 1 from public.jobs j where j.id = job_id and j.status = 'open'
));
create policy applications_update_own on public.job_applications for update to authenticated
using (applicant_id = auth.uid()) with check (applicant_id = auth.uid() and status = 'withdrawn');

create policy posts_read on public.posts for select to authenticated
using (status = 'published' or author_id = auth.uid());
create policy posts_insert on public.posts for insert to authenticated
with check (public.is_active_user() and author_id = auth.uid() and status = 'published');
create policy posts_update_own on public.posts for update to authenticated
using (author_id = auth.uid()) with check (author_id = auth.uid());

create policy comments_read on public.post_comments for select to authenticated
using (status = 'published' or author_id = auth.uid());
create policy comments_insert on public.post_comments for insert to authenticated
with check (public.is_active_user() and author_id = auth.uid() and exists (
  select 1 from public.posts p where p.id = post_id and p.status = 'published'
));
create policy comments_update_own on public.post_comments for update to authenticated
using (author_id = auth.uid()) with check (author_id = auth.uid());

create policy likes_read on public.post_likes for select to authenticated using (true);
create policy likes_manage_own on public.post_likes for all to authenticated
using (user_id = auth.uid()) with check (user_id = auth.uid() and public.is_active_user());

create policy courses_read on public.courses for select to authenticated
using (status = 'published' or public.is_org_member(provider_id));
create policy courses_manage on public.courses for all to authenticated
using (public.is_org_manager(provider_id)) with check (public.is_org_manager(provider_id));
create policy enrollments_read on public.course_enrollments for select to authenticated
using (user_id = auth.uid() or exists (
  select 1 from public.courses c where c.id = course_id and public.is_org_member(c.provider_id)
));
create policy enrollments_insert on public.course_enrollments for insert to authenticated
with check (public.is_active_user() and user_id = auth.uid());
create policy enrollments_update_own on public.course_enrollments for update to authenticated
using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy favorites_manage_own on public.favorites for all to authenticated
using (user_id = auth.uid()) with check (user_id = auth.uid() and public.is_active_user());

create policy reviews_read on public.reviews for select to authenticated using (true);
create policy reviews_insert on public.reviews for insert to authenticated
with check (
  reviewer_id = auth.uid() and public.can_access_order(order_id)
  and exists (select 1 from public.orders o where o.id = order_id and o.status = 'completed' and o.customer_id = auth.uid())
);

create policy reports_read_own on public.reports for select to authenticated using (reporter_id = auth.uid());
create policy reports_insert on public.reports for insert to authenticated
with check (public.is_active_user() and reporter_id = auth.uid());

create policy disputes_read on public.disputes for select to authenticated
using (public.can_access_order(order_id));
create policy disputes_insert on public.disputes for insert to authenticated
with check (opened_by = auth.uid() and public.can_access_order(order_id));

create policy notifications_read_own on public.notifications for select to authenticated
using (user_id = auth.uid());
create policy notifications_update_own on public.notifications for update to authenticated
using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy devices_manage_own on public.user_devices for all to authenticated
using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy settings_public_read on public.app_settings for select to anon, authenticated
using (is_public);
create policy home_sections_public_read on public.home_sections for select to anon, authenticated
using (is_enabled);
create policy banners_public_read on public.app_banners for select to anon, authenticated
using (is_enabled and (starts_at is null or starts_at <= now()) and (ends_at is null or ends_at > now()));

-- Signed-in users can see only conversations in which they participate.
create view public.conversation_summaries
with (security_invoker = true) as
select
  c.id,
  c.title,
  coalesce(last_message.body, '') as last_message,
  last_message.created_at as last_message_at
from public.conversations c
left join lateral (
  select m.body, m.created_at from public.messages m
  where m.conversation_id = c.id
  order by m.created_at desc limit 1
) last_message on true
where public.is_conversation_participant(c.id);

grant select on public.conversation_summaries to authenticated;
grant execute on function public.get_public_stats() to anon, authenticated;
grant execute on function public.create_facility(text,text,text,text,text[]) to authenticated;
grant execute on function public.accept_quote(uuid) to authenticated;
grant execute on function public.change_order_status(uuid,text) to authenticated;
grant execute on function public.review_verification(uuid,boolean,text) to authenticated;
grant execute on function public.toggle_post_like(uuid) to authenticated;
grant execute on function public.write_audit_log(text,text,text,jsonb) to authenticated;

-- Storage buckets. Engineering files, CVs and verification documents are private.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('avatars','avatars',true,5242880,array['image/jpeg','image/png','image/webp']),
  ('product-images','product-images',true,10485760,array['image/jpeg','image/png','image/webp']),
  ('request-files','request-files',false,15728640,null),
  ('verification-documents','verification-documents',false,15728640,array['application/pdf','image/jpeg','image/png']),
  ('cvs','cvs',false,10485760,array['application/pdf'])
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

create policy storage_public_images_read on storage.objects for select to anon, authenticated
using (bucket_id in ('avatars','product-images'));

create policy storage_own_files_read on storage.objects for select to authenticated
using (
  bucket_id in ('request-files','verification-documents','cvs')
  and (storage.foldername(name))[1] = auth.uid()::text
);

create policy storage_request_files_read on storage.objects for select to authenticated
using (
  bucket_id = 'request-files' and exists (
    select 1 from public.request_attachments a
    where a.bucket_id = 'request-files' and a.storage_path = name
      and public.can_access_request_files(a.request_id)
  )
);

create policy storage_own_files_insert on storage.objects for insert to authenticated
with check (
  bucket_id in ('avatars','product-images','request-files','verification-documents','cvs')
  and (storage.foldername(name))[1] = auth.uid()::text
  and public.is_active_user()
);

create policy storage_own_files_update on storage.objects for update to authenticated
using ((storage.foldername(name))[1] = auth.uid()::text)
with check ((storage.foldername(name))[1] = auth.uid()::text);

create policy storage_own_files_delete on storage.objects for delete to authenticated
using ((storage.foldername(name))[1] = auth.uid()::text);

create policy storage_admin_all on storage.objects for all to authenticated
using (public.is_admin()) with check (public.is_admin());
