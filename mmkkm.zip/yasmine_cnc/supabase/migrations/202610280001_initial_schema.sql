-- Yasmine CNC: complete initial PostgreSQL schema
-- Run through Supabase migrations. Never expose the service-role key to Flutter.

create extension if not exists pgcrypto;

create sequence if not exists public.order_number_seq start 100001;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  account_type text not null default 'client' check (account_type in ('client','engineer','technician','workshop','factory','supplier')),
  role text not null default 'user' check (role in ('user','moderator','admin')),
  preferred_language text not null default 'ar' check (preferred_language in ('ar','en')),
  specialty text not null default '',
  city text not null default '',
  bio text not null default '',
  avatar_path text,
  is_active boolean not null default true,
  is_verified boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.organizations (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete restrict,
  kind text not null default 'workshop' check (kind in ('workshop','factory','supplier','training_provider')),
  name_ar text not null,
  name_en text not null,
  description text not null default '',
  registration_number text unique,
  tax_number text,
  phone text,
  email text,
  website text,
  city text not null default '',
  address text not null default '',
  verification_status text not null default 'pending' check (verification_status in ('pending','approved','rejected','suspended')),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.organization_members (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','manager','member')),
  is_active boolean not null default true,
  joined_at timestamptz not null default now(),
  primary key (organization_id, user_id)
);

create table public.verification_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  organization_id uuid references public.organizations(id) on delete cascade,
  document_type text not null,
  storage_path text,
  notes text not null default '',
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  reviewed_by uuid references public.profiles(id) on delete set null,
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  check (user_id is not null or organization_id is not null)
);

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  parent_id uuid references public.categories(id) on delete set null,
  slug text not null unique,
  name_ar text not null,
  name_en text not null,
  icon text not null default 'category',
  sort_order integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.workshops (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null unique references public.organizations(id) on delete cascade,
  description text not null default '',
  city text not null default '',
  address text not null default '',
  latitude double precision,
  longitude double precision,
  capabilities text[] not null default '{}',
  materials text[] not null default '{}',
  rating_average numeric(3,2) not null default 0 check (rating_average between 0 and 5),
  rating_count integer not null default 0,
  completed_orders integer not null default 0,
  response_minutes integer,
  verification_status text not null default 'pending' check (verification_status in ('pending','approved','rejected','suspended')),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.machines (
  id uuid primary key default gen_random_uuid(),
  workshop_id uuid not null references public.workshops(id) on delete cascade,
  name text not null,
  machine_type text not null,
  axes integer check (axes between 1 and 9),
  max_length_mm numeric,
  max_width_mm numeric,
  max_height_mm numeric,
  materials text[] not null default '{}',
  status text not null default 'available' check (status in ('available','busy','maintenance','inactive')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id) on delete restrict,
  organization_id uuid references public.organizations(id) on delete set null,
  category_id uuid references public.categories(id) on delete set null,
  title text not null,
  description text not null,
  price numeric(14,2) not null check (price >= 0),
  currency text not null default 'EGP' check (currency = 'EGP'),
  condition text not null default 'new' check (condition in ('new','used','refurbished')),
  city text not null default '',
  stock integer not null default 1 check (stock >= 0),
  status text not null default 'pending' check (status in ('pending','active','rejected','sold','archived')),
  reviewed_by uuid references public.profiles(id) on delete set null,
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.product_images (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  storage_path text not null unique,
  alt_text text not null default '',
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table public.manufacturing_requests (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete restrict,
  category_id uuid references public.categories(id) on delete set null,
  title text not null,
  details text not null,
  material text not null default '',
  quantity integer not null check (quantity > 0),
  unit text not null default 'piece',
  tolerance text not null default '',
  finish text not null default '',
  deadline date,
  budget numeric(14,2) check (budget >= 0),
  visibility text not null default 'public' check (visibility in ('public','invited')),
  status text not null default 'open' check (status in ('draft','open','in_progress','completed','cancelled','disputed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.request_invitations (
  request_id uuid not null references public.manufacturing_requests(id) on delete cascade,
  organization_id uuid not null references public.organizations(id) on delete cascade,
  invited_by uuid not null references public.profiles(id) on delete restrict,
  created_at timestamptz not null default now(),
  primary key (request_id, organization_id)
);

create table public.request_attachments (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null references public.manufacturing_requests(id) on delete cascade,
  uploaded_by uuid not null references public.profiles(id) on delete restrict,
  bucket_id text not null default 'request-files',
  storage_path text not null unique,
  file_name text not null,
  mime_type text,
  size_bytes bigint not null check (size_bytes > 0 and size_bytes <= 15728640),
  created_at timestamptz not null default now()
);

create table public.quotes (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null references public.manufacturing_requests(id) on delete cascade,
  provider_id uuid not null references public.organizations(id) on delete restrict,
  amount numeric(14,2) not null check (amount > 0),
  delivery_days integer not null check (delivery_days > 0),
  notes text not null default '',
  status text not null default 'pending' check (status in ('pending','accepted','rejected','withdrawn')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (request_id, provider_id)
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique default 'YC-' || nextval('public.order_number_seq'),
  request_id uuid not null unique references public.manufacturing_requests(id) on delete restrict,
  quote_id uuid not null unique references public.quotes(id) on delete restrict,
  customer_id uuid not null references public.profiles(id) on delete restrict,
  provider_id uuid not null references public.organizations(id) on delete restrict,
  total numeric(14,2) not null check (total > 0),
  commission_rate numeric(5,2) not null default 0 check (commission_rate between 0 and 30),
  currency text not null default 'EGP',
  status text not null default 'in_progress' check (status in ('in_progress','quality_check','shipped','completed','cancelled','disputed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.order_status_history (
  id bigint generated always as identity primary key,
  order_id uuid not null references public.orders(id) on delete cascade,
  changed_by uuid references public.profiles(id) on delete set null,
  from_status text,
  to_status text not null,
  notes text not null default '',
  created_at timestamptz not null default now()
);

create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  request_id uuid references public.manufacturing_requests(id) on delete set null,
  order_id uuid unique references public.orders(id) on delete set null,
  title text not null default '',
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.conversation_participants (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  last_read_at timestamptz,
  joined_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete restrict,
  body text not null check (char_length(body) between 1 and 10000),
  attachment_path text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.jobs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  title text not null,
  description text not null,
  city text not null default '',
  employment_type text not null default 'full_time' check (employment_type in ('full_time','part_time','contract','internship','remote')),
  salary_min numeric(12,2),
  salary_max numeric(12,2),
  currency text not null default 'EGP',
  skills text[] not null default '{}',
  status text not null default 'open' check (status in ('draft','open','closed','archived')),
  expires_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (salary_max is null or salary_min is null or salary_max >= salary_min)
);

create table public.job_applications (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  applicant_id uuid not null references public.profiles(id) on delete cascade,
  cover_letter text not null default '',
  cv_path text,
  status text not null default 'submitted' check (status in ('submitted','reviewed','shortlisted','accepted','rejected','withdrawn')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (job_id, applicant_id)
);

create table public.posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references public.profiles(id) on delete cascade,
  organization_id uuid references public.organizations(id) on delete set null,
  category_id uuid references public.categories(id) on delete set null,
  body text not null check (char_length(body) between 1 and 5000),
  media_path text,
  status text not null default 'published' check (status in ('draft','published','hidden','removed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.post_comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  author_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 2000),
  status text not null default 'published' check (status in ('published','hidden','removed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.post_likes (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table public.courses (
  id uuid primary key default gen_random_uuid(),
  provider_id uuid not null references public.organizations(id) on delete cascade,
  title_ar text not null,
  title_en text not null,
  description text not null default '',
  city text not null default '',
  delivery_mode text not null default 'onsite' check (delivery_mode in ('onsite','online','hybrid')),
  price numeric(12,2) not null default 0,
  starts_at timestamptz,
  ends_at timestamptz,
  capacity integer check (capacity > 0),
  status text not null default 'published' check (status in ('draft','published','cancelled','completed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.course_enrollments (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'enrolled' check (status in ('enrolled','attended','completed','cancelled')),
  certificate_path text,
  created_at timestamptz not null default now(),
  unique (course_id, user_id)
);

create table public.favorites (
  user_id uuid not null references public.profiles(id) on delete cascade,
  entity_type text not null check (entity_type in ('product','workshop','job','post','course')),
  entity_id uuid not null,
  created_at timestamptz not null default now(),
  primary key (user_id, entity_type, entity_id)
);

create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  reviewer_id uuid not null references public.profiles(id) on delete restrict,
  organization_id uuid not null references public.organizations(id) on delete cascade,
  rating integer not null check (rating between 1 and 5),
  comment text not null default '',
  created_at timestamptz not null default now(),
  unique (order_id, reviewer_id)
);

create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete restrict,
  entity_type text not null check (entity_type in ('profile','organization','product','request','job','post','comment','message')),
  entity_id uuid not null,
  reason text not null,
  details text not null default '',
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  handled_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.disputes (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  opened_by uuid not null references public.profiles(id) on delete restrict,
  reason text not null,
  evidence_path text,
  status text not null default 'open' check (status in ('open','reviewing','resolved','closed')),
  resolution text not null default '',
  handled_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  type text not null,
  title text not null,
  body text not null default '',
  data jsonb not null default '{}'::jsonb,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.user_devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  push_token text not null unique,
  platform text not null check (platform in ('android','ios','web')),
  locale text not null default 'ar',
  last_seen_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table public.app_settings (
  key text primary key,
  value jsonb not null,
  is_public boolean not null default false,
  updated_by uuid references public.profiles(id) on delete set null,
  updated_at timestamptz not null default now()
);

create table public.home_sections (
  id uuid primary key default gen_random_uuid(),
  key text not null unique,
  title_ar text not null,
  title_en text not null,
  section_type text not null,
  configuration jsonb not null default '{}'::jsonb,
  sort_order integer not null default 0,
  is_enabled boolean not null default true,
  updated_at timestamptz not null default now()
);

create table public.app_banners (
  id uuid primary key default gen_random_uuid(),
  title_ar text not null,
  title_en text not null,
  body_ar text not null default '',
  body_en text not null default '',
  image_path text,
  target_route text,
  starts_at timestamptz,
  ends_at timestamptz,
  is_enabled boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id text,
  old_data jsonb,
  new_data jsonb,
  created_at timestamptz not null default now()
);

-- Query and moderation indexes
create index organizations_status_idx on public.organizations (verification_status, is_active);
create index organization_members_user_idx on public.organization_members (user_id, is_active);
create index verification_status_idx on public.verification_requests (status, created_at desc);
create index workshops_city_idx on public.workshops (city, verification_status, is_active);
create index products_public_idx on public.products (status, created_at desc);
create index products_seller_idx on public.products (seller_id, created_at desc);
create index products_category_idx on public.products (category_id, status);
create index requests_public_idx on public.manufacturing_requests (visibility, status, created_at desc);
create index requests_owner_idx on public.manufacturing_requests (owner_id, created_at desc);
create index attachments_request_idx on public.request_attachments (request_id);
create index quotes_request_idx on public.quotes (request_id, status, amount);
create index quotes_provider_idx on public.quotes (provider_id, created_at desc);
create index orders_customer_idx on public.orders (customer_id, created_at desc);
create index orders_provider_idx on public.orders (provider_id, created_at desc);
create index participants_user_idx on public.conversation_participants (user_id, conversation_id);
create index messages_conversation_idx on public.messages (conversation_id, created_at);
create index jobs_public_idx on public.jobs (status, created_at desc);
create index applications_applicant_idx on public.job_applications (applicant_id, created_at desc);
create index posts_public_idx on public.posts (status, created_at desc);
create index comments_post_idx on public.post_comments (post_id, created_at);
create index notifications_user_idx on public.notifications (user_id, created_at desc);
create index notifications_unread_idx on public.notifications (user_id, read_at) where read_at is null;
create index audit_entity_idx on public.audit_logs (entity_type, entity_id, created_at desc);
create index audit_actor_idx on public.audit_logs (actor_id, created_at desc);

create or replace function public.touch_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

do $$
declare table_name text;
begin
  foreach table_name in array array[
    'profiles','organizations','workshops','machines','products',
    'manufacturing_requests','quotes','orders','conversations','jobs',
    'job_applications','posts','post_comments','courses','reports',
    'disputes','app_settings','home_sections'
  ] loop
    execute format(
      'create trigger %I_updated_at before update on public.%I for each row execute function public.touch_updated_at()',
      table_name, table_name
    );
  end loop;
end;
$$;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, preferred_language)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    case when new.raw_user_meta_data ->> 'preferred_language' = 'en' then 'en' else 'ar' end
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();
