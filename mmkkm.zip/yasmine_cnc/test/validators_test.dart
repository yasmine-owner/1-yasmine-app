import 'package:flutter_test/flutter_test.dart';
import 'package:yasmine_cnc/core/utils/validators.dart';

void main() {
  group('OTP and contact validation', () {
    test('accepts valid email addresses', () {
      expect(Validators.email('engineer@example.com'), isTrue);
      expect(Validators.email('name+work@company.co.uk'), isTrue);
    });

    test('rejects malformed email addresses', () {
      expect(Validators.email('not-an-email'), isFalse);
      expect(Validators.email('a@b'), isFalse);
      expect(Validators.email('a b@example.com'), isFalse);
    });

    test('accepts international phone numbers only', () {
      expect(Validators.phone('+201000000000'), isTrue);
      expect(Validators.phone('01000000000'), isFalse);
      expect(Validators.phone('+0123'), isFalse);
    });

    test('OTP must contain exactly six digits', () {
      expect(Validators.otp('123456'), isTrue);
      expect(Validators.otp('12345'), isFalse);
      expect(Validators.otp('1234567'), isFalse);
      expect(Validators.otp('12a456'), isFalse);
    });
  });
}
