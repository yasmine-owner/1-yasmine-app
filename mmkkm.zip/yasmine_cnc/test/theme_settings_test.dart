import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:yasmine_cnc/core/theme/theme_settings.dart';

void main() {
  group('Theme settings', () {
    test('round trips through JSON without losing values', () {
      const settings = AppThemeSettings(
        primary: Color(0xFF0B2A4A),
        secondary: Color(0xFF00B4D8),
        fontScale: 1.15,
        borderRadius: 20,
        darkMode: true,
      );
      final restored = AppThemeSettings.decode(settings.encode());
      expect(restored.primary, settings.primary);
      expect(restored.secondary, settings.secondary);
      expect(restored.fontScale, settings.fontScale);
      expect(restored.borderRadius, settings.borderRadius);
      expect(restored.darkMode, isTrue);
    });

    test('invalid persisted JSON falls back safely', () {
      expect(
        AppThemeSettings.decode('{bad json').primary,
        AppThemeSettings.defaults.primary,
      );
      expect(AppThemeSettings.decode(null).fontFamily, 'NotoSansArabic');
    });

    test('untrusted values are constrained', () {
      final settings = AppThemeSettings.fromMap({
        'fontScale': 99,
        'borderRadius': -10,
        'fontFamily': 'UntrustedFont',
      });
      expect(settings.fontScale, 1.3);
      expect(settings.borderRadius, 4);
      expect(settings.fontFamily, 'NotoSansArabic');
    });

    test('hex colors parse and format consistently', () {
      const color = Color(0xFF00B4D8);
      expect(AppThemeSettings.parseHex('#00B4D8'), color);
      expect(AppThemeSettings.parseHex('00b4d8'), color);
      expect(AppThemeSettings.hex(color), '#00B4D8');
      expect(AppThemeSettings.parseHex('red'), isNull);
    });
  });
}
