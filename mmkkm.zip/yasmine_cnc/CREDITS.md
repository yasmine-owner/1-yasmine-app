# Credits

- **Noto Sans Arabic, Noto Kufi Arabic, Noto Naskh Arabic**: Google Noto project, distributed under the SIL Open Font License. The license/copyright text supplied with the installed Noto font package is included at `assets/fonts/LICENSE.txt`.
- **Flutter and Supabase packages**: retain their respective upstream licenses; dependencies are resolved through `pubspec.yaml` and `pubspec.lock`.
- Application icons and interface graphics are generated for Yasmine CNC from Flutter Material icons and simple brand shapes; no third-party photograph is bundled.
