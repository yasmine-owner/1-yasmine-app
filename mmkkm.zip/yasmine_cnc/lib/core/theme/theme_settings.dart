import 'dart:convert';
import 'package:flutter/material.dart';

@immutable
class AppThemeSettings {
  const AppThemeSettings({
    this.primary = const Color(0xFF0B2A4A),
    this.secondary = const Color(0xFF00B4D8),
    this.success = const Color(0xFF10B981),
    this.background = const Color(0xFFF1F5F9),
    this.text = const Color(0xFF102A43),
    this.darkMode = false,
    this.fontFamily = 'NotoSansArabic',
    this.fontScale = 1,
    this.borderRadius = 16,
  });

  final Color primary;
  final Color secondary;
  final Color success;
  final Color background;
  final Color text;
  final bool darkMode;
  final String fontFamily;
  final double fontScale;
  final double borderRadius;

  static const defaults = AppThemeSettings();

  static const navy = AppThemeSettings();
  static const ocean = AppThemeSettings(
    primary: Color(0xFF083B66),
    secondary: Color(0xFF0284C7),
    success: Color(0xFF059669),
    background: Color(0xFFF0F9FF),
    text: Color(0xFF0C4A6E),
  );
  static const emerald = AppThemeSettings(
    primary: Color(0xFF12372A),
    secondary: Color(0xFF0D9488),
    success: Color(0xFF16A34A),
    background: Color(0xFFF0FDF4),
    text: Color(0xFF14332B),
  );

  AppThemeSettings copyWith({
    Color? primary,
    Color? secondary,
    Color? success,
    Color? background,
    Color? text,
    bool? darkMode,
    String? fontFamily,
    double? fontScale,
    double? borderRadius,
  }) => AppThemeSettings(
    primary: primary ?? this.primary,
    secondary: secondary ?? this.secondary,
    success: success ?? this.success,
    background: background ?? this.background,
    text: text ?? this.text,
    darkMode: darkMode ?? this.darkMode,
    fontFamily: fontFamily ?? this.fontFamily,
    fontScale: fontScale ?? this.fontScale,
    borderRadius: borderRadius ?? this.borderRadius,
  );

  Map<String, dynamic> toMap() => {
    'primary': primary.toARGB32(),
    'secondary': secondary.toARGB32(),
    'success': success.toARGB32(),
    'background': background.toARGB32(),
    'text': text.toARGB32(),
    'darkMode': darkMode,
    'fontFamily': fontFamily,
    'fontScale': fontScale,
    'borderRadius': borderRadius,
  };

  String encode() => jsonEncode(toMap());

  factory AppThemeSettings.fromMap(Map<String, dynamic>? map) {
    if (map == null) return defaults;
    Color color(String key, Color fallback) {
      final value = map[key];
      return value is num ? Color(value.toInt()) : fallback;
    }

    double number(String key, double fallback, double min, double max) {
      final value = map[key];
      return value is num
          ? value.toDouble().clamp(min, max).toDouble()
          : fallback;
    }

    const allowedFonts = {
      'NotoSansArabic',
      'NotoKufiArabic',
      'NotoNaskhArabic',
    };
    final font = map['fontFamily'];
    return AppThemeSettings(
      primary: color('primary', defaults.primary),
      secondary: color('secondary', defaults.secondary),
      success: color('success', defaults.success),
      background: color('background', defaults.background),
      text: color('text', defaults.text),
      darkMode: map['darkMode'] == true,
      fontFamily: allowedFonts.contains(font)
          ? font as String
          : defaults.fontFamily,
      fontScale: number('fontScale', 1, .85, 1.3),
      borderRadius: number('borderRadius', 16, 4, 28),
    );
  }

  static AppThemeSettings decode(String? value) {
    if (value == null || value.isEmpty) return defaults;
    try {
      final map = jsonDecode(value);
      return map is Map<String, dynamic>
          ? AppThemeSettings.fromMap(map)
          : defaults;
    } on FormatException {
      return defaults;
    }
  }

  static String hex(Color color) =>
      '#${color.toARGB32().toRadixString(16).padLeft(8, '0').substring(2).toUpperCase()}';

  static Color? parseHex(String input) {
    final value = input.trim().replaceFirst('#', '');
    if (!RegExp(r'^[0-9a-fA-F]{6}$').hasMatch(value)) return null;
    return Color(int.parse('FF$value', radix: 16));
  }
}
