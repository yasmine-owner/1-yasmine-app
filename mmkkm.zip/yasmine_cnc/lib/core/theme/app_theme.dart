import 'package:flutter/material.dart';
import 'theme_settings.dart';

class AppTheme {
  const AppTheme._();

  static Color contrast(Color background) =>
      ThemeData.estimateBrightnessForColor(background) == Brightness.dark
      ? Colors.white
      : const Color(0xFF102A43);

  static ThemeData build(AppThemeSettings settings) {
    final dark = settings.darkMode;
    final surface = dark ? const Color(0xFF102838) : Colors.white;
    final scaffold = dark ? const Color(0xFF071A28) : settings.background;
    final onSurface = dark ? const Color(0xFFF1F5F9) : settings.text;
    final muted = dark ? const Color(0xFFA9BAC7) : const Color(0xFF64748B);
    final scheme = ColorScheme(
      brightness: dark ? Brightness.dark : Brightness.light,
      primary: settings.primary,
      onPrimary: contrast(settings.primary),
      secondary: settings.secondary,
      onSecondary: contrast(settings.secondary),
      error: const Color(0xFFDC2626),
      onError: Colors.white,
      surface: surface,
      onSurface: onSurface,
      surfaceContainerHighest: dark
          ? const Color(0xFF1A3444)
          : const Color(0xFFE7EDF2),
      onSurfaceVariant: muted,
      outline: dark ? const Color(0xFF38505F) : const Color(0xFFD6E0E8),
      outlineVariant: dark ? const Color(0xFF294150) : const Color(0xFFE3EAF0),
      shadow: const Color(0xFF000000),
      scrim: const Color(0xFF000000),
      inverseSurface: onSurface,
      onInverseSurface: surface,
      inversePrimary: settings.secondary,
      tertiary: settings.success,
      onTertiary: contrast(settings.success),
    );
    final radius = BorderRadius.circular(settings.borderRadius);
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      fontFamily: settings.fontFamily,
      scaffoldBackgroundColor: scaffold,
      visualDensity: VisualDensity.standard,
      appBarTheme: AppBarTheme(
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        backgroundColor: scaffold,
        foregroundColor: onSurface,
        titleTextStyle: TextStyle(
          fontFamily: settings.fontFamily,
          color: onSurface,
          fontSize: 20,
          fontWeight: FontWeight.w700,
        ),
      ),
      cardTheme: CardThemeData(
        color: surface,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: radius,
          side: BorderSide(color: scheme.outlineVariant),
        ),
      ),
      inputDecorationTheme: InputDecorationThemeData(
        filled: true,
        fillColor: dark ? const Color(0xFF102838) : Colors.white,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(settings.borderRadius * .75),
          borderSide: BorderSide(color: scheme.outline),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(settings.borderRadius * .75),
          borderSide: BorderSide(color: scheme.outline),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(settings.borderRadius * .75),
          borderSide: BorderSide(color: settings.secondary, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(settings.borderRadius * .75),
          borderSide: BorderSide(color: scheme.error),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size(48, 50),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(settings.borderRadius * .75),
          ),
          textStyle: const TextStyle(fontWeight: FontWeight.w700),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size(48, 50),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(settings.borderRadius * .75),
          ),
          side: BorderSide(color: scheme.outline),
          textStyle: const TextStyle(fontWeight: FontWeight.w700),
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: surface,
        indicatorColor: settings.secondary.withValues(alpha: .14),
        labelTextStyle: WidgetStatePropertyAll(
          TextStyle(fontFamily: settings.fontFamily, fontSize: 12),
        ),
      ),
      navigationRailTheme: NavigationRailThemeData(
        backgroundColor: surface,
        indicatorColor: settings.secondary.withValues(alpha: .14),
        selectedIconTheme: IconThemeData(color: settings.primary),
        selectedLabelTextStyle: TextStyle(
          color: settings.primary,
          fontWeight: FontWeight.w700,
        ),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: settings.secondary.withValues(alpha: .08),
        side: BorderSide.none,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        labelStyle: TextStyle(color: onSurface),
      ),
      dividerTheme: DividerThemeData(color: scheme.outlineVariant),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: settings.secondary,
      ),
    );
  }
}
