import 'package:supabase_flutter/supabase_flutter.dart';

class Validators {
  const Validators._();

  static bool email(String value) =>
      RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(value.trim());

  static bool phone(String value) =>
      RegExp(r'^\+[1-9][0-9]{7,14}$').hasMatch(value.trim());

  static bool otp(String value) => RegExp(r'^[0-9]{6}$').hasMatch(value.trim());

  static double? positiveDouble(String value) {
    final number = double.tryParse(value.trim());
    return number != null && number > 0 ? number : null;
  }

  static int? positiveInt(String value) {
    final number = int.tryParse(value.trim());
    return number != null && number > 0 ? number : null;
  }
}

String readableError(Object error) {
  if (error is AuthException) return error.message;
  if (error is PostgrestException) {
    if (error.code == '42501') return 'Permission denied by database policy.';
    return error.message;
  }
  if (error is StorageException) return error.message;
  return error.toString().replaceFirst('Exception: ', '');
}
