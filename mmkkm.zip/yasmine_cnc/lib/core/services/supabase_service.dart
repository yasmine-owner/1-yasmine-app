import 'package:supabase_flutter/supabase_flutter.dart';
import '../config/env.dart';

class SupabaseService {
  const SupabaseService._();

  static Future<void> initialize() async {
    if (!Env.isConfigured) return;
    await Supabase.initialize(
      url: Env.supabaseUrl,
      publishableKey: Env.supabaseAnonKey,
      authOptions: const FlutterAuthClientOptions(
        authFlowType: AuthFlowType.pkce,
        autoRefreshToken: true,
      ),
    );
  }

  static SupabaseClient get client => Supabase.instance.client;
  static Session? get session =>
      Env.isConfigured ? client.auth.currentSession : null;
  static User? get user => client.auth.currentUser;
  static String get userId {
    final id = user?.id;
    if (id == null) throw StateError('No authenticated user.');
    return id;
  }
}
