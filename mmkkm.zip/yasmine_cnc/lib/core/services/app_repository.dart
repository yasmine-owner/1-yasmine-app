import 'dart:typed_data';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../models/app_models.dart';
import '../theme/theme_settings.dart';
import 'supabase_service.dart';

class AppRepository {
  SupabaseClient get _db => SupabaseService.client;
  String get _uid => SupabaseService.userId;

  Future<Profile?> fetchProfile() async {
    final data = await _db
        .from('profiles')
        .select()
        .eq('id', _uid)
        .maybeSingle();
    return data == null ? null : Profile.fromMap(data);
  }

  Future<void> updateProfile({
    required String fullName,
    required String accountType,
    required String specialty,
    required String city,
    required String bio,
  }) async {
    await _db
        .from('profiles')
        .update({
          'full_name': fullName.trim(),
          'account_type': accountType,
          'specialty': specialty.trim(),
          'city': city.trim(),
          'bio': bio.trim(),
        })
        .eq('id', _uid);
  }

  Future<AppThemeSettings> fetchPublicTheme() async {
    final data = await _db
        .from('app_settings')
        .select('value')
        .eq('key', 'theme')
        .maybeSingle();
    final value = data?['value'];
    return value is Map<String, dynamic>
        ? AppThemeSettings.fromMap(value)
        : AppThemeSettings.defaults;
  }

  Future<void> publishTheme(AppThemeSettings settings) async {
    await _db.from('app_settings').upsert({
      'key': 'theme',
      'value': settings.toMap(),
      'is_public': true,
      'updated_by': _uid,
    });
  }

  Future<Map<String, dynamic>> fetchGeneralSettings() async {
    final data = await _db
        .from('app_settings')
        .select('value')
        .eq('key', 'general')
        .maybeSingle();
    final value = data?['value'];
    return value is Map<String, dynamic> ? value : <String, dynamic>{};
  }

  Future<void> saveGeneralSettings({
    required String platformNameAr,
    required String platformNameEn,
    required double commission,
  }) async {
    await _db.from('app_settings').upsert({
      'key': 'general',
      'value': {
        'platform_name_ar': platformNameAr.trim(),
        'platform_name_en': platformNameEn.trim(),
        'commission_rate': commission,
      },
      'is_public': true,
      'updated_by': _uid,
    });
  }

  Future<List<Map<String, dynamic>>> fetchCategories() async {
    final rows = await _db
        .from('categories')
        .select('id,slug,name_ar,name_en')
        .eq('is_active', true)
        .order('sort_order');
    return rows.cast<Map<String, dynamic>>();
  }

  Future<List<Product>> fetchProducts({String query = ''}) async {
    var request = _db
        .from('products')
        .select('*,categories(name_ar,name_en)')
        .eq('status', 'active');
    final clean = _filterText(query);
    if (clean.isNotEmpty) {
      request = request.or('title.ilike.%$clean%,description.ilike.%$clean%');
    }
    final rows = await request.order('created_at', ascending: false).limit(60);
    return rows.map(Product.fromMap).toList();
  }

  Future<void> createProduct({
    required String title,
    required String description,
    required double price,
    required String city,
    required String condition,
    required int stock,
    String? categoryId,
  }) async {
    await _db.from('products').insert({
      'seller_id': _uid,
      'category_id': categoryId,
      'title': title.trim(),
      'description': description.trim(),
      'price': price,
      'city': city.trim(),
      'condition': condition,
      'stock': stock,
      'status': 'pending',
    });
  }

  Future<List<ManufacturingRequest>> fetchManufacturingRequests() async {
    final rows = await _db
        .from('manufacturing_requests')
        .select('*,quotes(count)')
        .order('created_at', ascending: false)
        .limit(80);
    return rows.map(ManufacturingRequest.fromMap).toList();
  }

  Future<String> createManufacturingRequest({
    required String title,
    required String details,
    required String material,
    required int quantity,
    required DateTime? deadline,
    required double? budget,
  }) async {
    final row = await _db
        .from('manufacturing_requests')
        .insert({
          'owner_id': _uid,
          'title': title.trim(),
          'details': details.trim(),
          'material': material.trim(),
          'quantity': quantity,
          'deadline': deadline?.toIso8601String(),
          'budget': budget,
          'visibility': 'public',
          'status': 'open',
        })
        .select('id')
        .single();
    return row['id'].toString();
  }

  Future<void> uploadRequestAttachment({
    required String requestId,
    required String fileName,
    required Uint8List bytes,
    required String? mimeType,
  }) async {
    if (bytes.length > 15 * 1024 * 1024) {
      throw const AppRepositoryException('Attachment exceeds 15 MB.');
    }
    final safeName = fileName.replaceAll(RegExp(r'[^a-zA-Z0-9._-]'), '_');
    final path =
        '$_uid/$requestId/${DateTime.now().millisecondsSinceEpoch}-$safeName';
    await _db.storage
        .from('request-files')
        .uploadBinary(
          path,
          bytes,
          fileOptions: FileOptions(contentType: mimeType, upsert: false),
        );
    await _db.from('request_attachments').insert({
      'request_id': requestId,
      'uploaded_by': _uid,
      'bucket_id': 'request-files',
      'storage_path': path,
      'file_name': fileName,
      'mime_type': mimeType,
      'size_bytes': bytes.length,
    });
  }

  Future<List<Quote>> fetchQuotes(String requestId) async {
    final rows = await _db
        .from('quotes')
        .select('*,organizations(name_ar,name_en)')
        .eq('request_id', requestId)
        .order('amount');
    return rows.map(Quote.fromMap).toList();
  }

  Future<void> addQuote({
    required String requestId,
    required String providerId,
    required double amount,
    required int deliveryDays,
    required String notes,
  }) async {
    await _db.from('quotes').insert({
      'request_id': requestId,
      'provider_id': providerId,
      'amount': amount,
      'delivery_days': deliveryDays,
      'notes': notes.trim(),
      'status': 'pending',
    });
  }

  Future<String> acceptQuote(String quoteId) async {
    final result = await _db.rpc(
      'accept_quote',
      params: {'p_quote_id': quoteId},
    );
    return result.toString();
  }

  Future<List<Workshop>> fetchWorkshops() async {
    final rows = await _db
        .from('workshops')
        .select()
        .eq('is_active', true)
        .order('rating_average', ascending: false)
        .limit(80);
    return rows.map(Workshop.fromMap).toList();
  }

  Future<List<Map<String, dynamic>>> fetchMyOrganizations() async {
    final rows = await _db
        .from('organization_members')
        .select(
          'organization_id,role,organizations(name_ar,name_en,verification_status)',
        )
        .eq('user_id', _uid)
        .eq('is_active', true);
    return rows.cast<Map<String, dynamic>>();
  }

  Future<String> createFacility({
    required String nameAr,
    required String nameEn,
    required String description,
    required String city,
    required List<String> capabilities,
  }) async {
    final result = await _db.rpc(
      'create_facility',
      params: {
        'p_name_ar': nameAr.trim(),
        'p_name_en': nameEn.trim(),
        'p_description': description.trim(),
        'p_city': city.trim(),
        'p_capabilities': capabilities,
      },
    );
    return result.toString();
  }

  Future<List<Job>> fetchJobs() async {
    final rows = await _db
        .from('jobs')
        .select('*,organizations(name_ar,name_en)')
        .eq('status', 'open')
        .order('created_at', ascending: false)
        .limit(80);
    return rows.map(Job.fromMap).toList();
  }

  Future<void> applyForJob(String jobId, String coverLetter) async {
    await _db.from('job_applications').insert({
      'job_id': jobId,
      'applicant_id': _uid,
      'cover_letter': coverLetter.trim(),
      'status': 'submitted',
    });
  }

  Future<void> createJob({
    required String organizationId,
    required String title,
    required String description,
    required String city,
    required String employmentType,
    required List<String> skills,
  }) async {
    await _db.from('jobs').insert({
      'organization_id': organizationId,
      'title': title.trim(),
      'description': description.trim(),
      'city': city.trim(),
      'employment_type': employmentType,
      'skills': skills,
      'status': 'open',
    });
  }

  Future<List<OrderItem>> fetchOrders() async {
    final rows = await _db
        .from('orders')
        .select(
          '*,manufacturing_requests(title),organizations(name_ar,name_en)',
        )
        .order('created_at', ascending: false);
    return rows.map(OrderItem.fromMap).toList();
  }

  Future<void> changeOrderStatus(String orderId, String status) async {
    await _db.rpc(
      'change_order_status',
      params: {'p_order_id': orderId, 'p_new_status': status},
    );
  }

  Future<List<CourseItem>> fetchCourses() async {
    final rows = await _db
        .from('courses')
        .select('*,organizations(name_ar,name_en)')
        .eq('status', 'published')
        .order('starts_at')
        .limit(80);
    return rows.map(CourseItem.fromMap).toList();
  }

  Future<void> enrollInCourse(String courseId) async {
    await _db.from('course_enrollments').insert({
      'course_id': courseId,
      'user_id': _uid,
      'status': 'enrolled',
    });
  }

  Future<List<Post>> fetchPosts() async {
    final rows = await _db
        .from('posts')
        .select('*,profiles(full_name),post_likes(count),post_comments(count)')
        .eq('status', 'published')
        .order('created_at', ascending: false)
        .limit(80);
    return rows.map((row) {
      final profile = row['profiles'];
      final likes = row['post_likes'];
      final comments = row['post_comments'];
      return Post.fromMap({
        ...row,
        'author_name': profile is Map ? profile['full_name'] : '',
        'likes_count': _aggregateCount(likes),
        'comments_count': _aggregateCount(comments),
      });
    }).toList();
  }

  Future<void> createPost(String body) async {
    await _db.from('posts').insert({
      'author_id': _uid,
      'body': body.trim(),
      'status': 'published',
    });
  }

  Future<bool> togglePostLike(String postId) async {
    final result = await _db.rpc(
      'toggle_post_like',
      params: {'p_post_id': postId},
    );
    return result == true;
  }

  Future<List<Map<String, dynamic>>> fetchPostComments(String postId) async {
    final rows = await _db
        .from('post_comments')
        .select('id,body,created_at,profiles(full_name)')
        .eq('post_id', postId)
        .order('created_at');
    return rows.cast<Map<String, dynamic>>();
  }

  Future<void> addPostComment(String postId, String body) async {
    await _db.from('post_comments').insert({
      'post_id': postId,
      'author_id': _uid,
      'body': body.trim(),
    });
  }

  Future<List<Conversation>> fetchConversations() async {
    final rows = await _db
        .from('conversation_summaries')
        .select()
        .order('last_message_at', ascending: false);
    return rows.map(Conversation.fromMap).toList();
  }

  Future<List<Message>> fetchMessages(String conversationId) async {
    final rows = await _db
        .from('messages')
        .select()
        .eq('conversation_id', conversationId)
        .order('created_at')
        .limit(500);
    return rows.map(Message.fromMap).toList();
  }

  Future<void> sendMessage(String conversationId, String body) async {
    await _db.from('messages').insert({
      'conversation_id': conversationId,
      'sender_id': _uid,
      'body': body.trim(),
    });
  }

  Future<List<NotificationItem>> fetchNotifications() async {
    final rows = await _db
        .from('notifications')
        .select()
        .eq('user_id', _uid)
        .order('created_at', ascending: false)
        .limit(100);
    return rows.map(NotificationItem.fromMap).toList();
  }

  Future<void> markNotificationRead(String id) async {
    await _db
        .from('notifications')
        .update({'read_at': DateTime.now().toUtc().toIso8601String()})
        .eq('id', id)
        .eq('user_id', _uid);
  }

  Future<DashboardStats> fetchPublicStats() async {
    final data = await _db.rpc('get_public_stats');
    final map = Map<String, dynamic>.from(data as Map);
    return DashboardStats(
      users: _mapInt(map['users']),
      requests: _mapInt(map['requests']),
      products: _mapInt(map['products']),
    );
  }

  Future<DashboardStats> fetchDashboardStats() async {
    final responses = await Future.wait([
      _db.from('profiles').select('id').count(CountOption.exact),
      _db.from('manufacturing_requests').select('id').count(CountOption.exact),
      _db.from('products').select('id').count(CountOption.exact),
      _db
          .from('verification_requests')
          .select('id')
          .eq('status', 'pending')
          .count(CountOption.exact),
    ]);
    return DashboardStats(
      users: responses[0].count,
      requests: responses[1].count,
      products: responses[2].count,
      pendingVerifications: responses[3].count,
    );
  }

  Future<List<Map<String, dynamic>>> fetchVerificationRequests() async {
    final rows = await _db
        .from('verification_requests')
        .select('*,organizations(name_ar,name_en)')
        .order('created_at', ascending: false)
        .limit(100);
    return rows.cast<Map<String, dynamic>>();
  }

  Future<void> reviewVerification(
    String id,
    bool approved,
    String notes,
  ) async {
    await _db.rpc(
      'review_verification',
      params: {
        'p_request_id': id,
        'p_approved': approved,
        'p_notes': notes.trim(),
      },
    );
  }

  Future<List<Map<String, dynamic>>> fetchUsers() async {
    final rows = await _db
        .from('profiles')
        .select(
          'id,full_name,account_type,role,city,is_active,is_verified,created_at',
        )
        .order('created_at', ascending: false)
        .limit(200);
    return rows.cast<Map<String, dynamic>>();
  }

  Future<void> setUserActive(String id, bool active) async {
    await _db.from('profiles').update({'is_active': active}).eq('id', id);
    await _db.rpc(
      'write_audit_log',
      params: {
        'p_action': active ? 'user_reactivated' : 'user_suspended',
        'p_entity_type': 'profile',
        'p_entity_id': id,
        'p_new_data': {'is_active': active},
      },
    );
  }

  Future<List<Map<String, dynamic>>> fetchPendingProducts() async {
    final rows = await _db
        .from('products')
        .select('id,title,price,city,created_at,profiles(full_name)')
        .eq('status', 'pending')
        .order('created_at')
        .limit(100);
    return rows.cast<Map<String, dynamic>>();
  }

  Future<void> moderateProduct(String id, bool approved) async {
    await _db
        .from('products')
        .update({
          'status': approved ? 'active' : 'rejected',
          'reviewed_by': _uid,
          'reviewed_at': DateTime.now().toUtc().toIso8601String(),
        })
        .eq('id', id);
  }

  static int _mapInt(Object? value) =>
      value is num ? value.toInt() : int.tryParse(value?.toString() ?? '') ?? 0;

  static int _aggregateCount(Object? value) {
    if (value is List && value.isNotEmpty && value.first is Map) {
      final count = value.first['count'];
      return count is num ? count.toInt() : 0;
    }
    return 0;
  }

  static String _filterText(String value) {
    final clean = value.trim().replaceAll(RegExp(r'[,.()%"]'), '');
    return clean.length <= 80 ? clean : clean.substring(0, 80);
  }
}

class AppRepositoryException implements Exception {
  const AppRepositoryException(this.message);
  final String message;
  @override
  String toString() => message;
}
