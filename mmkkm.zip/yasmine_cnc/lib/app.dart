import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'core/config/env.dart';
import 'core/theme/app_theme.dart';
import 'features/auth/auth_screen.dart';
import 'features/home/home_shell.dart';
import 'features/setup/setup_screen.dart';
import 'state/app_controller.dart';

class YasmineApp extends StatelessWidget {
  const YasmineApp({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Yasmine CNC',
      locale: app.locale,
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: AppTheme.build(app.theme),
      builder: (context, child) {
        final media = MediaQuery.of(context);
        return MediaQuery(
          data: media.copyWith(
            textScaler: TextScaler.linear(app.theme.fontScale),
          ),
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: !app.ready
          ? const Scaffold(body: Center(child: CircularProgressIndicator()))
          : !Env.isConfigured
          ? const SetupScreen()
          : app.signedIn
          ? const HomeShell()
          : const AuthScreen(),
    );
  }
}
