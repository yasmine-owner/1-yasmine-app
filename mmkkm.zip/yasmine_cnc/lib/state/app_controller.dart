import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/config/env.dart';
import '../core/services/app_repository.dart';
import '../core/services/supabase_service.dart';
import '../core/theme/theme_settings.dart';
import '../models/app_models.dart';

class AppController extends ChangeNotifier {
  AppController(this.repository);
  final AppRepository repository;

  Locale _locale = const Locale('ar');
  AppThemeSettings _theme = AppThemeSettings.defaults;
  Profile? _profile;
  bool _ready = false;
  bool _busy = false;
  StreamSubscription<AuthState>? _authSubscription;

  Locale get locale => _locale;
  AppThemeSettings get theme => _theme;
  Profile? get profile => _profile;
  bool get ready => _ready;
  bool get busy => _busy;
  bool get signedIn => Env.isConfigured && SupabaseService.session != null;

  Future<void> initialize() async {
    final preferences = await SharedPreferences.getInstance();
    final language = preferences.getString('locale');
    if (language == 'ar' || language == 'en') _locale = Locale(language!);
    _theme = AppThemeSettings.decode(preferences.getString('theme'));
    if (Env.isConfigured) {
      try {
        _theme = await repository.fetchPublicTheme();
        await _persistTheme();
        if (SupabaseService.user != null) {
          _profile = await repository.fetchProfile();
        }
      } catch (_) {
        // Local preferences keep the interface usable while the network recovers.
      }
      _authSubscription = SupabaseService.client.auth.onAuthStateChange.listen((
        state,
      ) async {
        if (state.event == AuthChangeEvent.signedIn ||
            state.event == AuthChangeEvent.tokenRefreshed ||
            state.event == AuthChangeEvent.userUpdated) {
          try {
            _profile = await repository.fetchProfile();
          } catch (_) {
            _profile = null;
          }
        } else if (state.event == AuthChangeEvent.signedOut) {
          _profile = null;
        }
        notifyListeners();
      });
    }
    _ready = true;
    notifyListeners();
  }

  Future<void> setLocale(Locale locale) async {
    if (locale.languageCode != 'ar' && locale.languageCode != 'en') return;
    _locale = locale;
    notifyListeners();
    final preferences = await SharedPreferences.getInstance();
    await preferences.setString('locale', locale.languageCode);
  }

  Future<void> updateTheme(AppThemeSettings settings) async {
    _theme = settings;
    notifyListeners();
    await _persistTheme();
  }

  Future<void> _persistTheme() async {
    final preferences = await SharedPreferences.getInstance();
    await preferences.setString('theme', _theme.encode());
  }

  Future<void> sendEmailOtp(String email) => _run(
    () => SupabaseService.client.auth.signInWithOtp(
      email: email.trim(),
      shouldCreateUser: true,
    ),
  );

  Future<void> sendPhoneOtp(String phone) => _run(
    () => SupabaseService.client.auth.signInWithOtp(
      phone: phone.trim(),
      shouldCreateUser: true,
    ),
  );

  Future<void> verifyEmailOtp(String email, String token) => _run(
    () => SupabaseService.client.auth.verifyOTP(
      email: email.trim(),
      token: token.trim(),
      type: OtpType.email,
    ),
  );

  Future<void> verifyPhoneOtp(String phone, String token) => _run(
    () => SupabaseService.client.auth.verifyOTP(
      phone: phone.trim(),
      token: token.trim(),
      type: OtpType.sms,
    ),
  );

  Future<void> refreshProfile() async {
    if (SupabaseService.user == null) return;
    _profile = await repository.fetchProfile();
    notifyListeners();
  }

  Future<void> signOut() => _run(() => SupabaseService.client.auth.signOut());

  Future<T> _run<T>(Future<T> Function() action) async {
    if (_busy) throw StateError('Another request is in progress.');
    _busy = true;
    notifyListeners();
    try {
      return await action();
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _authSubscription?.cancel();
    super.dispose();
  }
}
