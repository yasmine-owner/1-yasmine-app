import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/services/app_repository.dart';
import '../../core/utils/validators.dart';
import '../../core/widgets/app_widgets.dart';
import '../../models/app_models.dart';

class CommunityScreen extends StatefulWidget {
  const CommunityScreen({super.key});
  @override
  State<CommunityScreen> createState() => _CommunityScreenState();
}

class _CommunityScreenState extends State<CommunityScreen> {
  late Future<List<Post>> _future;
  final _post = TextEditingController();
  bool _publishing = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() => _future = context.read<AppRepository>().fetchPosts();
  void _retry() => setState(_load);

  @override
  void dispose() {
    _post.dispose();
    super.dispose();
  }

  Future<void> _publish() async {
    if (_post.text.trim().length < 5) {
      showAppError(context, context.t('required'));
      return;
    }
    setState(() => _publishing = true);
    try {
      await context.read<AppRepository>().createPost(_post.text);
      _post.clear();
      _retry();
    } catch (error) {
      if (mounted) showAppError(context, readableError(error));
    } finally {
      if (mounted) setState(() => _publishing = false);
    }
  }

  Future<void> _like(Post post) async {
    try {
      await context.read<AppRepository>().togglePostLike(post.id);
      _retry();
    } catch (error) {
      if (mounted) showAppError(context, readableError(error));
    }
  }

  @override
  Widget build(BuildContext context) => PageBody(
    maxWidth: 850,
    children: [
      SectionHeader(context.t('community'), subtitle: context.t('dataOnline')),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              TextField(
                controller: _post,
                minLines: 3,
                maxLines: 6,
                maxLength: 5000,
                decoration: InputDecoration(
                  hintText: context.t('postHint'),
                  border: InputBorder.none,
                ),
              ),
              Align(
                alignment: AlignmentDirectional.centerEnd,
                child: FilledButton.icon(
                  onPressed: _publishing ? null : _publish,
                  icon: const Icon(Icons.send_outlined),
                  label: Text(context.t('publish')),
                ),
              ),
            ],
          ),
        ),
      ),
      const SizedBox(height: 16),
      AsyncView<List<Post>>(
        future: _future,
        onRetry: _retry,
        builder: (context, posts) => posts.isEmpty
            ? EmptyView(
                message: context.t('noData'),
                icon: Icons.forum_outlined,
              )
            : Column(children: posts.map(_card).toList()),
      ),
    ],
  );

  Widget _card(Post post) => Card(
    margin: const EdgeInsets.only(bottom: 12),
    child: Padding(
      padding: const EdgeInsets.all(17),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                child: Text(
                  post.authorName.isEmpty
                      ? 'Y'
                      : post.authorName.characters.first,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      post.authorName,
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                    Text(
                      dateLabel(post.createdAt),
                      style: TextStyle(
                        fontSize: 12,
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Text(post.body, style: const TextStyle(height: 1.8)),
          const Divider(height: 26),
          Row(
            children: [
              TextButton.icon(
                onPressed: () => _like(post),
                icon: const Icon(Icons.thumb_up_outlined, size: 19),
                label: Text('${post.likesCount} ${context.t('like')}'),
              ),
              TextButton.icon(
                onPressed: () => showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  useSafeArea: true,
                  builder: (_) => CommentsSheet(post: post),
                ),
                icon: const Icon(Icons.comment_outlined, size: 19),
                label: Text('${post.commentsCount} ${context.t('comments')}'),
              ),
            ],
          ),
        ],
      ),
    ),
  );
}

class CommentsSheet extends StatefulWidget {
  const CommentsSheet({super.key, required this.post});
  final Post post;
  @override
  State<CommentsSheet> createState() => _CommentsSheetState();
}

class _CommentsSheetState extends State<CommentsSheet> {
  late Future<List<Map<String, dynamic>>> _future;
  final _comment = TextEditingController();
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() =>
      _future = context.read<AppRepository>().fetchPostComments(widget.post.id);
  void _retry() => setState(_load);
  @override
  void dispose() {
    _comment.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (_comment.text.trim().isEmpty) return;
    setState(() => _sending = true);
    try {
      await context.read<AppRepository>().addPostComment(
        widget.post.id,
        _comment.text,
      );
      _comment.clear();
      _retry();
    } catch (error) {
      if (mounted) showAppError(context, readableError(error));
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) => SizedBox(
    height: MediaQuery.sizeOf(context).height * .75,
    child: Padding(
      padding: EdgeInsets.fromLTRB(
        16,
        16,
        16,
        16 + MediaQuery.viewInsetsOf(context).bottom,
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  context.t('comments'),
                  style: const TextStyle(
                    fontSize: 21,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.close),
              ),
            ],
          ),
          Expanded(
            child: AsyncView<List<Map<String, dynamic>>>(
              future: _future,
              onRetry: _retry,
              builder: (context, comments) => comments.isEmpty
                  ? EmptyView(
                      message: context.t('noData'),
                      icon: Icons.comment_outlined,
                    )
                  : ListView(
                      children: comments.map((comment) {
                        final profile = comment['profiles'];
                        return ListTile(
                          contentPadding: EdgeInsets.zero,
                          leading: const CircleAvatar(
                            child: Icon(Icons.person_outline),
                          ),
                          title: Text(
                            profile is Map
                                ? profile['full_name']?.toString() ?? ''
                                : '',
                          ),
                          subtitle: Text(
                            comment['body']?.toString() ?? '',
                            style: const TextStyle(height: 1.5),
                          ),
                        );
                      }).toList(),
                    ),
            ),
          ),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _comment,
                  decoration: InputDecoration(hintText: context.t('comments')),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(
                onPressed: _sending ? null : _send,
                icon: const Icon(Icons.send),
              ),
            ],
          ),
        ],
      ),
    ),
  );
}
