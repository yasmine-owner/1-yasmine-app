import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/widgets/app_widgets.dart';
import '../../state/app_controller.dart';
import '../admin/admin_screen.dart';
import '../community/community_screen.dart';
import '../courses/courses_screen.dart';
import '../jobs/jobs_screen.dart';
import '../manufacturing/manufacturing_screen.dart';
import '../marketplace/marketplace_screen.dart';
import '../messages/messages_screen.dart';
import '../notifications/notifications_screen.dart';
import '../orders/orders_screen.dart';
import '../profile/profile_screen.dart';
import '../workshops/workshops_screen.dart';
import 'home_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  void _open(String title, Widget page) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => Scaffold(
          appBar: AppBar(title: Text(title)),
          body: page,
        ),
      ),
    );
  }

  Future<void> _signOut() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(context.t('logout')),
        content: Text(context.t('logout')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: Text(context.t('cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: Text(context.t('logout')),
          ),
        ],
      ),
    );
    if (confirmed == true && mounted) {
      await context.read<AppController>().signOut();
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final pages = [
      HomeScreen(
        onNavigate: (index) => setState(() => _index = index),
        onWorkshops: () =>
            _open(context.t('workshops'), const WorkshopsScreen()),
      ),
      const ManufacturingScreen(),
      const MarketplaceScreen(),
      const CommunityScreen(),
      MoreScreen(onOpen: _open, onSignOut: _signOut),
    ];
    return LayoutBuilder(
      builder: (context, constraints) {
        final desktop = constraints.maxWidth >= 1000;
        final destinations = [
          (Icons.home_outlined, context.t('home')),
          (Icons.assignment_outlined, context.t('manufacturing')),
          (Icons.storefront_outlined, context.t('market')),
          (Icons.forum_outlined, context.t('community')),
          (Icons.menu, context.t('more')),
        ];
        return Scaffold(
          appBar: AppBar(
            title: InkWell(
              onTap: () => setState(() => _index = 0),
              child: const YasmineLogo(),
            ),
            actions: [
              IconButton(
                tooltip: context.t('notifications'),
                onPressed: () => _open(
                  context.t('notifications'),
                  const NotificationsScreen(),
                ),
                icon: const Icon(Icons.notifications_outlined),
              ),
              IconButton(
                tooltip: context.t('language'),
                onPressed: () =>
                    app.setLocale(Locale(context.isArabic ? 'en' : 'ar')),
                icon: const Icon(Icons.translate),
              ),
              const SizedBox(width: 6),
            ],
          ),
          body: Column(
            children: [
              if (app.profile?.fullName.isEmpty ?? true)
                MaterialBanner(
                  backgroundColor: Theme.of(
                    context,
                  ).colorScheme.secondary.withValues(alpha: .12),
                  content: Text(context.t('profile')),
                  leading: const Icon(Icons.person_add_alt_1_outlined),
                  actions: [
                    TextButton(
                      onPressed: () =>
                          _open(context.t('profile'), const ProfileScreen()),
                      child: Text(context.t('save')),
                    ),
                  ],
                ),
              Expanded(
                child: Row(
                  children: [
                    if (desktop)
                      NavigationRail(
                        selectedIndex: _index,
                        extended: constraints.maxWidth >= 1280,
                        onDestinationSelected: (value) =>
                            setState(() => _index = value),
                        labelType: constraints.maxWidth >= 1280
                            ? NavigationRailLabelType.none
                            : NavigationRailLabelType.all,
                        destinations: destinations
                            .map(
                              (item) => NavigationRailDestination(
                                icon: Icon(item.$1),
                                label: Text(item.$2),
                              ),
                            )
                            .toList(),
                      ),
                    Expanded(
                      child: IndexedStack(index: _index, children: pages),
                    ),
                  ],
                ),
              ),
            ],
          ),
          bottomNavigationBar: desktop
              ? null
              : NavigationBar(
                  selectedIndex: _index,
                  onDestinationSelected: (value) =>
                      setState(() => _index = value),
                  destinations: destinations
                      .map(
                        (item) => NavigationDestination(
                          icon: Icon(item.$1),
                          label: item.$2,
                        ),
                      )
                      .toList(),
                ),
        );
      },
    );
  }
}

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key, required this.onOpen, required this.onSignOut});
  final void Function(String title, Widget page) onOpen;
  final VoidCallback onSignOut;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final profile = app.profile;
    final items = <(IconData, String, Widget)>[
      (Icons.factory_outlined, context.t('workshops'), const WorkshopsScreen()),
      (Icons.work_outline, context.t('jobs'), const JobsScreen()),
      (Icons.track_changes_outlined, context.t('orders'), const OrdersScreen()),
      (Icons.school_outlined, context.t('training'), const CoursesScreen()),
      (
        Icons.chat_bubble_outline,
        context.t('messages'),
        const MessagesScreen(),
      ),
      (
        Icons.notifications_outlined,
        context.t('notifications'),
        const NotificationsScreen(),
      ),
      (Icons.person_outline, context.t('profile'), const ProfileScreen()),
      if (profile?.isAdmin == true)
        (
          Icons.admin_panel_settings_outlined,
          context.t('admin'),
          const AdminScreen(),
        ),
    ];
    return PageBody(
      maxWidth: 760,
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 28,
                  backgroundColor: Theme.of(
                    context,
                  ).colorScheme.secondary.withValues(alpha: .12),
                  child: Icon(
                    Icons.person_outline,
                    color: Theme.of(context).colorScheme.secondary,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        profile?.fullName.isNotEmpty == true
                            ? profile!.fullName
                            : context.t('welcome'),
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      Text(
                        context.t(profile?.accountType ?? 'client'),
                        style: TextStyle(
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                if (profile?.isVerified == true)
                  Icon(
                    Icons.verified,
                    color: Theme.of(context).colorScheme.tertiary,
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        ...items.map(
          (item) => Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: Icon(item.$1),
              title: Text(item.$2),
              trailing: const Icon(Icons.chevron_left),
              onTap: () => onOpen(item.$2, item.$3),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Card(
          child: Column(
            children: [
              SwitchListTile(
                secondary: const Icon(Icons.dark_mode_outlined),
                title: Text(context.t('darkMode')),
                value: app.theme.darkMode,
                onChanged: (value) =>
                    app.updateTheme(app.theme.copyWith(darkMode: value)),
              ),
              ListTile(
                leading: const Icon(Icons.translate),
                title: Text(context.t('language')),
                subtitle: Text(
                  context.t(context.isArabic ? 'arabic' : 'english'),
                ),
                trailing: const Icon(Icons.swap_horiz),
                onTap: () =>
                    app.setLocale(Locale(context.isArabic ? 'en' : 'ar')),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          style: OutlinedButton.styleFrom(
            foregroundColor: Theme.of(context).colorScheme.error,
          ),
          onPressed: onSignOut,
          icon: const Icon(Icons.logout),
          label: Text(context.t('logout')),
        ),
      ],
    );
  }
}
