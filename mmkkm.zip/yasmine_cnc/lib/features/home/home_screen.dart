import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/services/app_repository.dart';
import '../../core/widgets/app_widgets.dart';
import '../../models/app_models.dart';

class HomeData {
  const HomeData(this.stats, this.requests, this.products, this.workshops);
  final DashboardStats stats;
  final List<ManufacturingRequest> requests;
  final List<Product> products;
  final List<Workshop> workshops;
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    required this.onNavigate,
    required this.onWorkshops,
  });
  final ValueChanged<int> onNavigate;
  final VoidCallback onWorkshops;
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<HomeData> _future;
  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() {
    final repository = context.read<AppRepository>();
    _future =
        Future.wait([
          repository.fetchPublicStats(),
          repository.fetchManufacturingRequests(),
          repository.fetchProducts(),
          repository.fetchWorkshops(),
        ]).then(
          (values) => HomeData(
            values[0] as DashboardStats,
            (values[1] as List<ManufacturingRequest>).take(3).toList(),
            (values[2] as List<Product>).take(4).toList(),
            values[3] as List<Workshop>,
          ),
        );
  }

  void _retry() => setState(_load);

  @override
  Widget build(BuildContext context) => AsyncView<HomeData>(
    future: _future,
    onRetry: _retry,
    builder: (context, data) => RefreshIndicator(
      onRefresh: () async => _retry(),
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 36),
        children: [
          _hero(data.stats),
          const SizedBox(height: 26),
          SectionHeader(context.t('quickServices')),
          LayoutBuilder(
            builder: (context, constraints) {
              final count = constraints.maxWidth >= 950 ? 4 : 2;
              return GridView.count(
                crossAxisCount: count,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: constraints.maxWidth < 380 ? 1.1 : 1.45,
                children: [
                  _service(
                    Icons.assignment_add,
                    context.t('manufacturing'),
                    () => widget.onNavigate(1),
                  ),
                  _service(
                    Icons.storefront_outlined,
                    context.t('market'),
                    () => widget.onNavigate(2),
                  ),
                  _service(
                    Icons.factory_outlined,
                    context.t('workshops'),
                    widget.onWorkshops,
                  ),
                  _service(
                    Icons.forum_outlined,
                    context.t('community'),
                    () => widget.onNavigate(3),
                  ),
                ],
              );
            },
          ),
          const SizedBox(height: 26),
          SectionHeader(
            context.t('latestRequests'),
            action: TextButton(
              onPressed: () => widget.onNavigate(1),
              child: Text(context.t('viewAll')),
            ),
          ),
          if (data.requests.isEmpty)
            EmptyView(
              message: context.t('noData'),
              icon: Icons.assignment_outlined,
            )
          else
            ...data.requests.map(_requestTile),
          const SizedBox(height: 22),
          SectionHeader(
            context.t('latestProducts'),
            action: TextButton(
              onPressed: () => widget.onNavigate(2),
              child: Text(context.t('viewAll')),
            ),
          ),
          if (data.products.isEmpty)
            EmptyView(
              message: context.t('noData'),
              icon: Icons.storefront_outlined,
            )
          else
            LayoutBuilder(
              builder: (context, constraints) => GridView.count(
                crossAxisCount: constraints.maxWidth >= 850 ? 4 : 2,
                childAspectRatio: 1.35,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                children: data.products.map(_productCard).toList(),
              ),
            ),
          const SizedBox(height: 24),
          SectionHeader(
            context.t('verifiedWorkshops'),
            action: TextButton(
              onPressed: widget.onWorkshops,
              child: Text(context.t('viewAll')),
            ),
          ),
          if (data.workshops.isEmpty)
            EmptyView(
              message: context.t('noData'),
              icon: Icons.factory_outlined,
            )
          else
            ...data.workshops
                .where((item) => item.verified)
                .take(3)
                .map(_workshopTile),
        ],
      ),
    ),
  );

  Widget _hero(DashboardStats stats) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [theme.colorScheme.primary, const Color(0xFF061C2E)],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            context.t('homeHeroTitle'),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.w800,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            context.t('homeHeroBody'),
            style: const TextStyle(
              color: Color(0xFFD8E8F1),
              fontSize: 15,
              height: 1.7,
            ),
          ),
          const SizedBox(height: 20),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: theme.colorScheme.secondary,
                ),
                onPressed: () => widget.onNavigate(1),
                icon: const Icon(Icons.add),
                label: Text(context.t('requestNow')),
              ),
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white,
                  side: const BorderSide(color: Color(0xFF91B8CC)),
                ),
                onPressed: widget.onWorkshops,
                icon: const Icon(Icons.search),
                label: Text(context.t('findWorkshop')),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Wrap(
            spacing: 24,
            runSpacing: 14,
            children: [
              _heroStat('${stats.requests}', context.t('openRequests')),
              _heroStat('${stats.products}', context.t('products')),
              _heroStat('${stats.users}', context.t('industrialNetwork')),
            ],
          ),
        ],
      ),
    );
  }

  Widget _heroStat(String value, String label) => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      Text(
        value,
        style: const TextStyle(
          color: Color(0xFF56D9F5),
          fontSize: 23,
          fontWeight: FontWeight.w800,
        ),
      ),
      const SizedBox(width: 7),
      Text(label, style: const TextStyle(color: Colors.white, fontSize: 12)),
    ],
  );

  Widget _service(IconData icon, String label, VoidCallback onTap) => Card(
    clipBehavior: Clip.antiAlias,
    child: InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 30,
              color: Theme.of(context).colorScheme.secondary,
            ),
            const SizedBox(height: 12),
            Text(
              label,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ],
        ),
      ),
    ),
  );

  Widget _requestTile(ManufacturingRequest request) => Card(
    margin: const EdgeInsets.only(bottom: 10),
    child: ListTile(
      contentPadding: const EdgeInsets.all(14),
      leading: CircleAvatar(
        backgroundColor: Theme.of(
          context,
        ).colorScheme.secondary.withValues(alpha: .1),
        child: Icon(
          Icons.precision_manufacturing,
          color: Theme.of(context).colorScheme.secondary,
        ),
      ),
      title: Text(
        request.title,
        style: const TextStyle(fontWeight: FontWeight.w700),
      ),
      subtitle: Text(
        '${request.material} · ${request.quantity} · ${dateLabel(request.deadline)}',
      ),
      trailing: StatusChip(label: statusLabel(context, request.status)),
    ),
  );

  Widget _productCard(Product product) => Card(
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.inventory_2_outlined,
            color: Theme.of(context).colorScheme.secondary,
          ),
          const Spacer(),
          Text(
            product.title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 4),
          Text(
            money(context, product.price),
            style: TextStyle(
              color: Theme.of(context).colorScheme.primary,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    ),
  );

  Widget _workshopTile(Workshop workshop) => Card(
    margin: const EdgeInsets.only(bottom: 10),
    child: ListTile(
      leading: const Icon(Icons.factory_outlined),
      title: Text(context.isArabic ? workshop.nameAr : workshop.nameEn),
      subtitle: Text(
        '${workshop.city} · ${workshop.capabilities.take(2).join(' · ')}',
      ),
      trailing: StatusChip(
        label: context.t('verified'),
        color: Theme.of(context).colorScheme.tertiary,
      ),
    ),
  );
}
