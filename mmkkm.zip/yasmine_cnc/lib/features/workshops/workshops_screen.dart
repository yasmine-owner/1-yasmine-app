import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/services/app_repository.dart';
import '../../core/utils/validators.dart';
import '../../core/widgets/app_widgets.dart';
import '../../models/app_models.dart';

class WorkshopsScreen extends StatefulWidget {
  const WorkshopsScreen({super.key});
  @override
  State<WorkshopsScreen> createState() => _WorkshopsScreenState();
}

class _WorkshopsScreenState extends State<WorkshopsScreen> {
  late Future<List<Workshop>> _future;
  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() => _future = context.read<AppRepository>().fetchWorkshops();
  void _retry() => setState(_load);

  Future<void> _createFacility() async {
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => const FacilityFormDialog(),
    );
    if (result == true && mounted) _retry();
  }

  @override
  Widget build(BuildContext context) => PageBody(
    children: [
      SectionHeader(
        context.t('workshops'),
        subtitle: context.t('industrialNetwork'),
        action: IconButton.filled(
          onPressed: _createFacility,
          icon: const Icon(Icons.add_business),
        ),
      ),
      AsyncView<List<Workshop>>(
        future: _future,
        onRetry: _retry,
        builder: (context, workshops) => workshops.isEmpty
            ? EmptyView(
                message: context.t('noData'),
                icon: Icons.factory_outlined,
                action: FilledButton.icon(
                  onPressed: _createFacility,
                  icon: const Icon(Icons.add),
                  label: Text(context.t('create')),
                ),
              )
            : Column(children: workshops.map(_card).toList()),
      ),
    ],
  );

  Widget _card(Workshop workshop) => Card(
    margin: const EdgeInsets.only(bottom: 12),
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 25,
                backgroundColor: Theme.of(
                  context,
                ).colorScheme.secondary.withValues(alpha: .1),
                child: Icon(
                  Icons.factory_outlined,
                  color: Theme.of(context).colorScheme.secondary,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      context.isArabic ? workshop.nameAr : workshop.nameEn,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Text(
                      workshop.city,
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              if (workshop.verified)
                StatusChip(
                  label: context.t('verified'),
                  color: Theme.of(context).colorScheme.tertiary,
                ),
            ],
          ),
          if (workshop.description.isNotEmpty) ...[
            const SizedBox(height: 12),
            Text(workshop.description, style: const TextStyle(height: 1.6)),
          ],
          if (workshop.capabilities.isNotEmpty) ...[
            const SizedBox(height: 12),
            Wrap(
              spacing: 7,
              runSpacing: 7,
              children: workshop.capabilities
                  .map((item) => Chip(label: Text(item)))
                  .toList(),
            ),
          ],
        ],
      ),
    ),
  );
}

class FacilityFormDialog extends StatefulWidget {
  const FacilityFormDialog({super.key});
  @override
  State<FacilityFormDialog> createState() => _FacilityFormDialogState();
}

class _FacilityFormDialogState extends State<FacilityFormDialog> {
  final _key = GlobalKey<FormState>();
  final _nameAr = TextEditingController();
  final _nameEn = TextEditingController();
  final _description = TextEditingController();
  final _city = TextEditingController();
  final _capabilities = TextEditingController();
  bool _saving = false;

  @override
  void dispose() {
    for (final c in [_nameAr, _nameEn, _description, _city, _capabilities]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (!_key.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      await context.read<AppRepository>().createFacility(
        nameAr: _nameAr.text,
        nameEn: _nameEn.text,
        description: _description.text,
        city: _city.text,
        capabilities: _capabilities.text
            .split(',')
            .map((e) => e.trim())
            .where((e) => e.isNotEmpty)
            .toList(),
      );
      if (mounted) Navigator.pop(context, true);
    } catch (error) {
      if (mounted) showAppError(context, readableError(error));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(context.t('workshops')),
    content: SizedBox(
      width: 560,
      child: Form(
        key: _key,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: _nameAr,
                decoration: const InputDecoration(
                  labelText: 'اسم المنشأة بالعربية',
                ),
                validator: (v) => (v?.trim().isNotEmpty ?? false)
                    ? null
                    : context.t('required'),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _nameEn,
                decoration: const InputDecoration(
                  labelText: 'Facility name in English',
                ),
                validator: (v) => (v?.trim().isNotEmpty ?? false)
                    ? null
                    : context.t('required'),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _city,
                decoration: InputDecoration(labelText: context.t('city')),
                validator: (v) => (v?.trim().isNotEmpty ?? false)
                    ? null
                    : context.t('required'),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _capabilities,
                decoration: InputDecoration(
                  labelText: context.isArabic
                      ? 'الإمكانيات — افصل بينها بفاصلة'
                      : 'Capabilities — comma separated',
                ),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _description,
                minLines: 3,
                maxLines: 5,
                decoration: InputDecoration(
                  labelText: context.t('description'),
                ),
                validator: (v) => (v?.trim().length ?? 0) >= 10
                    ? null
                    : context.t('required'),
              ),
            ],
          ),
        ),
      ),
    ),
    actions: [
      TextButton(
        onPressed: _saving ? null : () => Navigator.pop(context),
        child: Text(context.t('cancel')),
      ),
      FilledButton(
        onPressed: _saving ? null : _save,
        child: Text(context.t('create')),
      ),
    ],
  );
}
