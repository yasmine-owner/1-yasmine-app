import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/services/app_repository.dart';
import '../../core/utils/validators.dart';
import '../../core/widgets/app_widgets.dart';
import '../../models/app_models.dart';

class MarketplaceScreen extends StatefulWidget {
  const MarketplaceScreen({super.key});
  @override
  State<MarketplaceScreen> createState() => _MarketplaceScreenState();
}

class _MarketplaceScreenState extends State<MarketplaceScreen> {
  late Future<List<Product>> _future;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() =>
      _future = context.read<AppRepository>().fetchProducts(query: _query);
  void _retry() => setState(_load);

  Future<void> _addProduct() async {
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => const ProductFormDialog(),
    );
    if (result == true && mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(context.t('productCreated'))));
    }
  }

  @override
  Widget build(BuildContext context) => PageBody(
    children: [
      SectionHeader(context.t('market'), subtitle: context.t('dataOnline')),
      Row(
        children: [
          Expanded(
            child: TextField(
              decoration: InputDecoration(
                hintText: context.t('search'),
                prefixIcon: const Icon(Icons.search),
              ),
              onSubmitted: (value) {
                _query = value.trim();
                _retry();
              },
            ),
          ),
          const SizedBox(width: 10),
          IconButton.filled(
            onPressed: _addProduct,
            icon: const Icon(Icons.add),
            tooltip: context.t('newProduct'),
          ),
        ],
      ),
      const SizedBox(height: 16),
      AsyncView<List<Product>>(
        future: _future,
        onRetry: _retry,
        builder: (context, products) => products.isEmpty
            ? EmptyView(
                message: context.t('noData'),
                icon: Icons.storefront_outlined,
                action: FilledButton.icon(
                  onPressed: _addProduct,
                  icon: const Icon(Icons.add),
                  label: Text(context.t('newProduct')),
                ),
              )
            : LayoutBuilder(
                builder: (context, constraints) => GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: products.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: constraints.maxWidth >= 1000
                        ? 4
                        : constraints.maxWidth >= 650
                        ? 3
                        : 2,
                    mainAxisExtent: 230,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                  ),
                  itemBuilder: (context, index) => _product(products[index]),
                ),
              ),
      ),
    ],
  );

  Widget _product(Product product) => Card(
    clipBehavior: Clip.antiAlias,
    child: InkWell(
      onTap: () => showModalBottomSheet(
        context: context,
        showDragHandle: true,
        builder: (_) => Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                product.title,
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                money(context, product.price),
                style: TextStyle(
                  fontSize: 20,
                  color: Theme.of(context).colorScheme.primary,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 14),
              Text(product.description, style: const TextStyle(height: 1.7)),
              const SizedBox(height: 12),
              Text(
                '${product.city} · ${context.t(product.condition)} · ${context.t('stock')}: ${product.stock}',
              ),
            ],
          ),
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 70,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Theme.of(
                  context,
                ).colorScheme.secondary.withValues(alpha: .08),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                Icons.precision_manufacturing,
                size: 38,
                color: Theme.of(context).colorScheme.secondary,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              product.title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
            const Spacer(),
            Text(
              money(context, product.price),
              style: TextStyle(
                color: Theme.of(context).colorScheme.primary,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              product.city,
              maxLines: 1,
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

class ProductFormDialog extends StatefulWidget {
  const ProductFormDialog({super.key});
  @override
  State<ProductFormDialog> createState() => _ProductFormDialogState();
}

class _ProductFormDialogState extends State<ProductFormDialog> {
  final _key = GlobalKey<FormState>();
  final _title = TextEditingController();
  final _description = TextEditingController();
  final _price = TextEditingController();
  final _city = TextEditingController();
  final _stock = TextEditingController(text: '1');
  String _condition = 'new';
  String? _category;
  List<Map<String, dynamic>> _categories = [];
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    context.read<AppRepository>().fetchCategories().then((value) {
      if (mounted) setState(() => _categories = value);
    });
  }

  @override
  void dispose() {
    for (final c in [_title, _description, _price, _city, _stock]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (!_key.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      await context.read<AppRepository>().createProduct(
        title: _title.text,
        description: _description.text,
        price: double.parse(_price.text),
        city: _city.text,
        condition: _condition,
        stock: int.parse(_stock.text),
        categoryId: _category,
      );
      if (mounted) Navigator.pop(context, true);
    } catch (error) {
      if (mounted) showAppError(context, readableError(error));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(context.t('newProduct')),
    content: SizedBox(
      width: 560,
      child: Form(
        key: _key,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: _title,
                decoration: InputDecoration(
                  labelText: context.t('productTitle'),
                ),
                validator: (v) =>
                    (v?.trim().length ?? 0) >= 3 ? null : context.t('required'),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _description,
                minLines: 3,
                maxLines: 5,
                decoration: InputDecoration(
                  labelText: context.t('description'),
                ),
                validator: (v) => (v?.trim().length ?? 0) >= 10
                    ? null
                    : context.t('required'),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                initialValue: _category,
                items: _categories
                    .map(
                      (category) => DropdownMenuItem(
                        value: category['id'].toString(),
                        child: Text(
                          category[context.isArabic ? 'name_ar' : 'name_en']
                              .toString(),
                        ),
                      ),
                    )
                    .toList(),
                onChanged: (value) => setState(() => _category = value),
                decoration: InputDecoration(
                  labelText: context.t('manufacturing'),
                ),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _price,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: InputDecoration(labelText: context.t('price')),
                validator: (v) => Validators.positiveDouble(v ?? '') == null
                    ? context.t('invalidNumber')
                    : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _city,
                decoration: InputDecoration(labelText: context.t('city')),
                validator: (v) => (v?.trim().isNotEmpty ?? false)
                    ? null
                    : context.t('required'),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                initialValue: _condition,
                items: ['new', 'used']
                    .map(
                      (value) => DropdownMenuItem(
                        value: value,
                        child: Text(context.t(value)),
                      ),
                    )
                    .toList(),
                onChanged: (value) =>
                    setState(() => _condition = value ?? 'new'),
                decoration: InputDecoration(labelText: context.t('condition')),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _stock,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: context.t('stock')),
                validator: (v) => Validators.positiveInt(v ?? '') == null
                    ? context.t('invalidNumber')
                    : null,
              ),
            ],
          ),
        ),
      ),
    ),
    actions: [
      TextButton(
        onPressed: _saving ? null : () => Navigator.pop(context),
        child: Text(context.t('cancel')),
      ),
      FilledButton(
        onPressed: _saving ? null : _save,
        child: Text(context.t('publish')),
      ),
    ],
  );
}
