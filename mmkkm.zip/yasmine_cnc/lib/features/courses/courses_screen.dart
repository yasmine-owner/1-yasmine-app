import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/services/app_repository.dart';
import '../../core/utils/validators.dart';
import '../../core/widgets/app_widgets.dart';
import '../../models/app_models.dart';

class CoursesScreen extends StatefulWidget {
  const CoursesScreen({super.key});
  @override
  State<CoursesScreen> createState() => _CoursesScreenState();
}

class _CoursesScreenState extends State<CoursesScreen> {
  late Future<List<CourseItem>> _future;
  final Set<String> _enrolled = {};
  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() => _future = context.read<AppRepository>().fetchCourses();
  void _retry() => setState(_load);

  Future<void> _enroll(CourseItem course) async {
    try {
      await context.read<AppRepository>().enrollInCourse(course.id);
      if (!mounted) return;
      setState(() => _enrolled.add(course.id));
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(context.t('enrolled'))));
    } catch (error) {
      if (mounted) showAppError(context, readableError(error));
    }
  }

  @override
  Widget build(BuildContext context) => PageBody(
    children: [
      SectionHeader(context.t('training'), subtitle: context.t('dataOnline')),
      AsyncView<List<CourseItem>>(
        future: _future,
        onRetry: _retry,
        builder: (context, courses) => courses.isEmpty
            ? EmptyView(
                message: context.t('noData'),
                icon: Icons.school_outlined,
              )
            : LayoutBuilder(
                builder: (context, constraints) => GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: constraints.maxWidth >= 900
                        ? 3
                        : constraints.maxWidth >= 600
                        ? 2
                        : 1,
                    mainAxisExtent: 280,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                  ),
                  itemCount: courses.length,
                  itemBuilder: (context, index) => _card(courses[index]),
                ),
              ),
      ),
    ],
  );

  Widget _card(CourseItem course) => Card(
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.school_outlined,
            size: 34,
            color: Theme.of(context).colorScheme.secondary,
          ),
          const SizedBox(height: 12),
          Text(
            context.isArabic ? course.titleAr : course.titleEn,
            style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 6),
          Text(
            '${course.providerName} · ${course.city}',
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: Text(
              course.description,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(height: 1.5),
            ),
          ),
          Text(
            '${dateLabel(course.startsAt)} · ${money(context, course.price)}',
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: _enrolled.contains(course.id)
                  ? null
                  : () => _enroll(course),
              icon: Icon(
                _enrolled.contains(course.id)
                    ? Icons.check
                    : Icons.app_registration,
              ),
              label: Text(
                context.t(_enrolled.contains(course.id) ? 'applied' : 'enroll'),
              ),
            ),
          ),
        ],
      ),
    ),
  );
}
