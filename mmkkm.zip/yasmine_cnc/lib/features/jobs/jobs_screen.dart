import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/services/app_repository.dart';
import '../../core/utils/validators.dart';
import '../../core/widgets/app_widgets.dart';
import '../../models/app_models.dart';

class JobsScreen extends StatefulWidget {
  const JobsScreen({super.key});
  @override
  State<JobsScreen> createState() => _JobsScreenState();
}

class _JobsScreenState extends State<JobsScreen> {
  late Future<List<Job>> _future;
  final Set<String> _applied = {};
  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() => _future = context.read<AppRepository>().fetchJobs();
  void _retry() => setState(_load);

  Future<void> _apply(Job job) async {
    final repository = context.read<AppRepository>();
    final controller = TextEditingController();
    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text('${context.t('apply')} · ${job.title}'),
        content: TextField(
          controller: controller,
          minLines: 4,
          maxLines: 7,
          maxLength: 2000,
          decoration: InputDecoration(
            labelText: context.t('coverLetter'),
            alignLabelWithHint: true,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: Text(context.t('cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: Text(context.t('send')),
          ),
        ],
      ),
    );
    final letter = controller.text;
    controller.dispose();
    if (result != true) return;
    try {
      await repository.applyForJob(job.id, letter);
      if (!mounted) return;
      setState(() => _applied.add(job.id));
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(context.t('applicationSent'))));
    } catch (error) {
      if (mounted) showAppError(context, readableError(error));
    }
  }

  Future<void> _addJob() async {
    final organizations = await context
        .read<AppRepository>()
        .fetchMyOrganizations();
    if (!mounted) return;
    if (organizations.isEmpty) {
      showAppError(
        context,
        context.isArabic
            ? 'أنشئ ملف منشأة أولًا.'
            : 'Create a facility profile first.',
      );
      return;
    }
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => JobFormDialog(organizations: organizations),
    );
    if (result == true && mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(context.t('jobCreated'))));
      _retry();
    }
  }

  @override
  Widget build(BuildContext context) => PageBody(
    children: [
      SectionHeader(
        context.t('jobs'),
        subtitle: context.t('dataOnline'),
        action: IconButton.filled(
          onPressed: _addJob,
          icon: const Icon(Icons.add),
          tooltip: context.t('newJob'),
        ),
      ),
      AsyncView<List<Job>>(
        future: _future,
        onRetry: _retry,
        builder: (context, jobs) => jobs.isEmpty
            ? EmptyView(message: context.t('noData'), icon: Icons.work_outline)
            : Column(children: jobs.map(_card).toList()),
      ),
    ],
  );

  Widget _card(Job job) => Card(
    margin: const EdgeInsets.only(bottom: 12),
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  job.title,
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              Icon(
                Icons.work_outline,
                color: Theme.of(context).colorScheme.secondary,
              ),
            ],
          ),
          const SizedBox(height: 5),
          Text(
            '${job.companyName} · ${job.city}',
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            job.description,
            maxLines: 4,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(height: 1.6),
          ),
          if (job.skills.isNotEmpty) ...[
            const SizedBox(height: 12),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: job.skills
                  .map((skill) => Chip(label: Text(skill)))
                  .toList(),
            ),
          ],
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _applied.contains(job.id) ? null : () => _apply(job),
            icon: Icon(
              _applied.contains(job.id) ? Icons.check : Icons.send_outlined,
            ),
            label: Text(
              context.t(_applied.contains(job.id) ? 'applied' : 'apply'),
            ),
          ),
        ],
      ),
    ),
  );
}

class JobFormDialog extends StatefulWidget {
  const JobFormDialog({super.key, required this.organizations});
  final List<Map<String, dynamic>> organizations;
  @override
  State<JobFormDialog> createState() => _JobFormDialogState();
}

class _JobFormDialogState extends State<JobFormDialog> {
  final _key = GlobalKey<FormState>();
  final _title = TextEditingController();
  final _description = TextEditingController();
  final _city = TextEditingController();
  final _skills = TextEditingController();
  String? _organization;
  String _type = 'full_time';
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _organization = widget.organizations.first['organization_id'].toString();
  }

  @override
  void dispose() {
    for (final c in [_title, _description, _city, _skills]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (!_key.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      await context.read<AppRepository>().createJob(
        organizationId: _organization!,
        title: _title.text,
        description: _description.text,
        city: _city.text,
        employmentType: _type,
        skills: _skills.text
            .split(',')
            .map((e) => e.trim())
            .where((e) => e.isNotEmpty)
            .toList(),
      );
      if (mounted) Navigator.pop(context, true);
    } catch (error) {
      if (mounted) showAppError(context, readableError(error));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(context.t('newJob')),
    content: SizedBox(
      width: 560,
      child: Form(
        key: _key,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<String>(
                initialValue: _organization,
                items: widget.organizations.map((item) {
                  final org = item['organizations'] as Map?;
                  return DropdownMenuItem(
                    value: item['organization_id'].toString(),
                    child: Text(
                      context.isArabic
                          ? (org?['name_ar'] ?? '').toString()
                          : (org?['name_en'] ?? '').toString(),
                    ),
                  );
                }).toList(),
                onChanged: (value) => setState(() => _organization = value),
                decoration: InputDecoration(labelText: context.t('workshop')),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _title,
                decoration: InputDecoration(labelText: context.t('jobs')),
                validator: (v) =>
                    (v?.trim().length ?? 0) >= 3 ? null : context.t('required'),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _description,
                minLines: 3,
                maxLines: 5,
                decoration: InputDecoration(
                  labelText: context.t('description'),
                ),
                validator: (v) => (v?.trim().length ?? 0) >= 20
                    ? null
                    : context.t('required'),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _city,
                decoration: InputDecoration(labelText: context.t('city')),
                validator: (v) => (v?.trim().isNotEmpty ?? false)
                    ? null
                    : context.t('required'),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                initialValue: _type,
                items:
                    [
                          'full_time',
                          'part_time',
                          'contract',
                          'internship',
                          'remote',
                        ]
                        .map(
                          (type) => DropdownMenuItem(
                            value: type,
                            child: Text(context.t(type)),
                          ),
                        )
                        .toList(),
                onChanged: (value) =>
                    setState(() => _type = value ?? 'full_time'),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _skills,
                decoration: InputDecoration(
                  labelText: context.isArabic
                      ? 'المهارات — افصل بينها بفاصلة'
                      : 'Skills — comma separated',
                ),
              ),
            ],
          ),
        ),
      ),
    ),
    actions: [
      TextButton(
        onPressed: _saving ? null : () => Navigator.pop(context),
        child: Text(context.t('cancel')),
      ),
      FilledButton(
        onPressed: _saving ? null : _save,
        child: Text(context.t('publish')),
      ),
    ],
  );
}
