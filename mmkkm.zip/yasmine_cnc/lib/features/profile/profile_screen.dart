import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/services/app_repository.dart';
import '../../core/utils/validators.dart';
import '../../core/widgets/app_widgets.dart';
import '../../state/app_controller.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _key = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _specialty;
  late final TextEditingController _city;
  late final TextEditingController _bio;
  String _accountType = 'client';
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final profile = context.read<AppController>().profile;
    _name = TextEditingController(text: profile?.fullName ?? '');
    _specialty = TextEditingController(text: profile?.specialty ?? '');
    _city = TextEditingController(text: profile?.city ?? '');
    _bio = TextEditingController(text: profile?.bio ?? '');
    _accountType = profile?.accountType ?? 'client';
  }

  @override
  void dispose() {
    for (final c in [_name, _specialty, _city, _bio]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (!_key.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      await context.read<AppRepository>().updateProfile(
        fullName: _name.text,
        accountType: _accountType,
        specialty: _specialty.text,
        city: _city.text,
        bio: _bio.text,
      );
      if (!mounted) return;
      await context.read<AppController>().refreshProfile();
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(context.t('profileSaved'))));
      }
    } catch (error) {
      if (mounted) showAppError(context, readableError(error));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => Form(
    key: _key,
    child: PageBody(
      maxWidth: 720,
      children: [
        SectionHeader(context.t('profile')),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              children: [
                CircleAvatar(
                  radius: 38,
                  backgroundColor: Theme.of(
                    context,
                  ).colorScheme.secondary.withValues(alpha: .12),
                  child: Icon(
                    Icons.person_outline,
                    size: 40,
                    color: Theme.of(context).colorScheme.secondary,
                  ),
                ),
                const SizedBox(height: 18),
                TextFormField(
                  controller: _name,
                  decoration: InputDecoration(labelText: context.t('fullName')),
                  validator: (v) => (v?.trim().length ?? 0) >= 3
                      ? null
                      : context.t('required'),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  initialValue: _accountType,
                  items:
                      [
                            'client',
                            'engineer',
                            'technician',
                            'workshop',
                            'factory',
                            'supplier',
                          ]
                          .map(
                            (type) => DropdownMenuItem(
                              value: type,
                              child: Text(context.t(type)),
                            ),
                          )
                          .toList(),
                  onChanged: (value) =>
                      setState(() => _accountType = value ?? 'client'),
                  decoration: InputDecoration(
                    labelText: context.t('accountType'),
                  ),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _specialty,
                  decoration: InputDecoration(
                    labelText: context.t('specialty'),
                  ),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _city,
                  decoration: InputDecoration(labelText: context.t('city')),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _bio,
                  minLines: 3,
                  maxLines: 6,
                  maxLength: 1500,
                  decoration: InputDecoration(
                    labelText: context.t('bio'),
                    alignLabelWithHint: true,
                  ),
                ),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: _saving ? null : _save,
                    icon: const Icon(Icons.save_outlined),
                    label: Text(context.t('save')),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    ),
  );
}
