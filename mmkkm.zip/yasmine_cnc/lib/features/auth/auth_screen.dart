import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/utils/validators.dart';
import '../../core/widgets/app_widgets.dart';
import '../../state/app_controller.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _formKey = GlobalKey<FormState>();
  final _contact = TextEditingController();
  final _otp = TextEditingController();
  bool _emailMode = true;
  bool _otpStep = false;
  int _resendSeconds = 0;
  Timer? _timer;

  @override
  void dispose() {
    _timer?.cancel();
    _contact.dispose();
    _otp.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (!_formKey.currentState!.validate()) return;
    final app = context.read<AppController>();
    try {
      if (_emailMode) {
        await app.sendEmailOtp(_contact.text);
      } else {
        await app.sendPhoneOtp(_contact.text);
      }
      if (!mounted) return;
      setState(() {
        _otpStep = true;
        _otp.clear();
        _resendSeconds = 60;
      });
      _startTimer();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            context.t(_emailMode ? 'otpSentEmail' : 'otpSentPhone'),
          ),
        ),
      );
    } catch (error) {
      if (mounted) showAppError(context, readableError(error));
    }
  }

  Future<void> _verify() async {
    if (!_formKey.currentState!.validate()) return;
    final app = context.read<AppController>();
    try {
      if (_emailMode) {
        await app.verifyEmailOtp(_contact.text, _otp.text);
      } else {
        await app.verifyPhoneOtp(_contact.text, _otp.text);
      }
    } catch (error) {
      if (mounted) showAppError(context, readableError(error));
    }
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return timer.cancel();
      if (_resendSeconds <= 1) {
        timer.cancel();
        setState(() => _resendSeconds = 0);
      } else {
        setState(() => _resendSeconds -= 1);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    return Scaffold(
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final wide = constraints.maxWidth >= 850;
            final form = Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 450),
                  child: _form(app),
                ),
              ),
            );
            if (!wide) {
              return Column(
                children: [
                  SizedBox(
                    height: 210,
                    width: double.infinity,
                    child: _brandPanel(compact: true),
                  ),
                  Expanded(child: form),
                ],
              );
            }
            return Row(
              textDirection: TextDirection.ltr,
              children: [
                Expanded(flex: 5, child: _brandPanel()),
                Expanded(flex: 4, child: form),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _brandPanel({bool compact = false}) {
    final theme = Theme.of(context);
    return Container(
      padding: EdgeInsets.all(compact ? 24 : 54),
      decoration: BoxDecoration(
        color: theme.colorScheme.primary,
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [theme.colorScheme.primary, const Color(0xFF061B2D)],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const YasmineLogo(light: true),
          SizedBox(height: compact ? 22 : 48),
          Text(
            context.t('homeHeroTitle'),
            style: TextStyle(
              color: Colors.white,
              fontSize: compact ? 24 : 40,
              height: 1.35,
              fontWeight: FontWeight.w800,
            ),
          ),
          if (!compact) ...[
            const SizedBox(height: 18),
            Text(
              context.t('homeHeroBody'),
              style: const TextStyle(
                color: Color(0xFFD4E6F0),
                fontSize: 17,
                height: 1.8,
              ),
            ),
            const SizedBox(height: 28),
            const Row(
              children: [
                Icon(Icons.verified_user_outlined, color: Color(0xFF56D9F5)),
                SizedBox(width: 10),
                Flexible(
                  child: Text(
                    'OTP · PostgreSQL · RLS',
                    style: TextStyle(color: Colors.white, letterSpacing: 1),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _form(AppController app) => AutofillGroup(
    child: Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            context.t('loginTitle'),
            style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Text(
            _otpStep
                ? context.t(_emailMode ? 'otpSentEmail' : 'otpSentPhone')
                : context.t('loginSubtitle'),
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
              height: 1.6,
            ),
          ),
          const SizedBox(height: 24),
          if (!_otpStep) ...[
            SegmentedButton<bool>(
              segments: [
                ButtonSegment(
                  value: true,
                  icon: const Icon(Icons.email_outlined),
                  label: Text(context.t('email')),
                ),
                ButtonSegment(
                  value: false,
                  icon: const Icon(Icons.sms_outlined),
                  label: Text(context.t('phone')),
                ),
              ],
              selected: {_emailMode},
              onSelectionChanged: app.busy
                  ? null
                  : (value) => setState(() {
                      _emailMode = value.first;
                      _contact.clear();
                    }),
            ),
            const SizedBox(height: 18),
            TextFormField(
              controller: _contact,
              enabled: !app.busy,
              keyboardType: _emailMode
                  ? TextInputType.emailAddress
                  : TextInputType.phone,
              autofillHints: [
                _emailMode
                    ? AutofillHints.email
                    : AutofillHints.telephoneNumber,
              ],
              textDirection: TextDirection.ltr,
              decoration: InputDecoration(
                labelText: context.t(_emailMode ? 'email' : 'phone'),
                hintText: context.t(_emailMode ? 'emailHint' : 'phoneHint'),
                prefixIcon: Icon(
                  _emailMode ? Icons.email_outlined : Icons.phone_outlined,
                ),
              ),
              validator: (value) {
                if (_emailMode) {
                  return Validators.email(value ?? '')
                      ? null
                      : context.t('invalidEmail');
                }
                return Validators.phone(value ?? '')
                    ? null
                    : context.t('invalidPhone');
              },
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: app.busy ? null : _send,
              icon: app.busy
                  ? const SizedBox(
                      width: 19,
                      height: 19,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.mark_email_read_outlined),
              label: Text(context.t('sendOtp')),
            ),
          ] else ...[
            TextFormField(
              controller: _otp,
              enabled: !app.busy,
              autofocus: true,
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              maxLength: 6,
              autofillHints: const [AutofillHints.oneTimeCode],
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              style: const TextStyle(
                fontSize: 26,
                letterSpacing: 8,
                fontWeight: FontWeight.w700,
              ),
              decoration: InputDecoration(
                labelText: context.t('otp'),
                hintText: '000000',
                counterText: '',
              ),
              validator: (value) =>
                  Validators.otp(value ?? '') ? null : context.t('invalidOtp'),
              onFieldSubmitted: (_) => app.busy ? null : _verify(),
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: app.busy ? null : _verify,
              icon: app.busy
                  ? const SizedBox(
                      width: 19,
                      height: 19,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.verified_user_outlined),
              label: Text(context.t('verifyOtp')),
            ),
            const SizedBox(height: 10),
            TextButton(
              onPressed: app.busy || _resendSeconds > 0 ? null : _send,
              child: Text(
                _resendSeconds > 0
                    ? '${context.t('resend')} ($_resendSeconds)'
                    : context.t('resend'),
              ),
            ),
            TextButton(
              onPressed: app.busy
                  ? null
                  : () => setState(() {
                      _otpStep = false;
                      _otp.clear();
                      _timer?.cancel();
                      _resendSeconds = 0;
                    }),
              child: Text(context.t('changeContact')),
            ),
          ],
          const SizedBox(height: 22),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(
                Icons.lock_outline,
                size: 19,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  context.t('secureByDesign'),
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    fontSize: 12,
                    height: 1.5,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    ),
  );
}
