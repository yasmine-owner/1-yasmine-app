import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/services/app_repository.dart';
import '../../core/utils/validators.dart';
import '../../core/widgets/app_widgets.dart';
import '../../models/app_models.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});
  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  late Future<List<NotificationItem>> _future;
  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() => _future = context.read<AppRepository>().fetchNotifications();
  void _retry() => setState(_load);

  Future<void> _read(NotificationItem item) async {
    if (item.readAt != null) return;
    try {
      await context.read<AppRepository>().markNotificationRead(item.id);
      _retry();
    } catch (error) {
      if (mounted) showAppError(context, readableError(error));
    }
  }

  @override
  Widget build(BuildContext context) => PageBody(
    maxWidth: 800,
    children: [
      SectionHeader(context.t('notifications')),
      AsyncView<List<NotificationItem>>(
        future: _future,
        onRetry: _retry,
        builder: (context, items) => items.isEmpty
            ? EmptyView(
                message: context.t('noNotifications'),
                icon: Icons.notifications_none,
              )
            : Column(
                children: items
                    .map(
                      (item) => Card(
                        margin: const EdgeInsets.only(bottom: 9),
                        child: ListTile(
                          onTap: () => _read(item),
                          leading: CircleAvatar(
                            backgroundColor: Theme.of(context)
                                .colorScheme
                                .secondary
                                .withValues(
                                  alpha: item.readAt == null ? .15 : .06,
                                ),
                            child: Icon(
                              item.readAt == null
                                  ? Icons.notifications_active_outlined
                                  : Icons.notifications_none,
                            ),
                          ),
                          title: Text(
                            item.title,
                            style: TextStyle(
                              fontWeight: item.readAt == null
                                  ? FontWeight.w800
                                  : FontWeight.w500,
                            ),
                          ),
                          subtitle: Text(
                            '${item.body}\n${dateLabel(item.createdAt)}',
                          ),
                          isThreeLine: true,
                          trailing: item.readAt == null
                              ? const Icon(Icons.circle, size: 9)
                              : null,
                        ),
                      ),
                    )
                    .toList(),
              ),
      ),
    ],
  );
}
