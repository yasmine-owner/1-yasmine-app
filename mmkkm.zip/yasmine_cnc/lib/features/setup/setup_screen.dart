import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/widgets/app_widgets.dart';
import '../../state/app_controller.dart';

class SetupScreen extends StatelessWidget {
  const SetupScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const YasmineLogo(),
      actions: [
        TextButton(
          onPressed: () {
            final app = context.read<AppController>();
            app.setLocale(Locale(context.isArabic ? 'en' : 'ar'));
          },
          child: Text(context.t(context.isArabic ? 'english' : 'arabic')),
        ),
      ],
    ),
    body: PageBody(
      maxWidth: 760,
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  Icons.cloud_outlined,
                  size: 52,
                  color: Theme.of(context).colorScheme.secondary,
                ),
                const SizedBox(height: 18),
                Text(
                  context.t('setupTitle'),
                  style: const TextStyle(
                    fontSize: 27,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  context.t('setupBody'),
                  style: const TextStyle(height: 1.8),
                ),
                const SizedBox(height: 24),
                ...['setupStep1', 'setupStep2', 'setupStep3'].map(
                  (key) => Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(
                          Icons.check_circle_outline,
                          color: Theme.of(context).colorScheme.tertiary,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            context.t(key),
                            style: const TextStyle(height: 1.7),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Directionality(
                    textDirection: TextDirection.ltr,
                    child: SelectableText(
                      'flutter pub get\nflutter run --dart-define-from-file=env.json',
                      style: TextStyle(
                        color: Colors.white,
                        fontFamily: 'monospace',
                        height: 1.8,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  context.t('secureByDesign'),
                  style: const TextStyle(height: 1.7),
                ),
              ],
            ),
          ),
        ),
      ],
    ),
  );
}
