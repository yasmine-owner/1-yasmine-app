import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/services/app_repository.dart';
import '../../core/services/supabase_service.dart';
import '../../core/utils/validators.dart';
import '../../core/widgets/app_widgets.dart';
import '../../models/app_models.dart';

class ManufacturingScreen extends StatefulWidget {
  const ManufacturingScreen({super.key, this.openFormInitially = false});
  final bool openFormInitially;
  @override
  State<ManufacturingScreen> createState() => _ManufacturingScreenState();
}

class _ManufacturingScreenState extends State<ManufacturingScreen> {
  late Future<List<ManufacturingRequest>> _future;
  bool _opened = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() =>
      _future = context.read<AppRepository>().fetchManufacturingRequests();
  void _retry() => setState(_load);

  Future<void> _openForm() async {
    final created = await Navigator.of(
      context,
    ).push<bool>(MaterialPageRoute(builder: (_) => const RequestFormScreen()));
    if (created == true && mounted) _retry();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.openFormInitially && !_opened) {
      _opened = true;
      WidgetsBinding.instance.addPostFrameCallback((_) => _openForm());
    }
    return Scaffold(
      body: PageBody(
        children: [
          SectionHeader(
            context.t('manufacturing'),
            subtitle: context.t('dataOnline'),
            action: IconButton.filled(
              onPressed: _openForm,
              icon: const Icon(Icons.add),
            ),
          ),
          AsyncView<List<ManufacturingRequest>>(
            future: _future,
            onRetry: _retry,
            builder: (context, requests) => requests.isEmpty
                ? EmptyView(
                    message: context.t('noData'),
                    icon: Icons.assignment_outlined,
                    action: FilledButton.icon(
                      onPressed: _openForm,
                      icon: const Icon(Icons.add),
                      label: Text(context.t('newRequest')),
                    ),
                  )
                : Column(children: requests.map(_card).toList()),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openForm,
        icon: const Icon(Icons.add),
        label: Text(context.t('newRequest')),
      ),
    );
  }

  Widget _card(ManufacturingRequest request) => Card(
    margin: const EdgeInsets.only(bottom: 12),
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  request.title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              StatusChip(label: statusLabel(context, request.status)),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            request.details,
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(height: 1.6),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 14,
            runSpacing: 8,
            children: [
              _meta(
                Icons.inventory_2_outlined,
                '${request.material} · ${request.quantity}',
              ),
              _meta(Icons.event_outlined, dateLabel(request.deadline)),
              if (request.budget != null)
                _meta(Icons.payments_outlined, money(context, request.budget!)),
              _meta(
                Icons.request_quote_outlined,
                '${request.quotesCount} ${context.t('quotes')}',
              ),
            ],
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () => showModalBottomSheet(
              context: context,
              isScrollControlled: true,
              useSafeArea: true,
              builder: (_) => QuotesSheet(request: request, onChanged: _retry),
            ),
            icon: const Icon(Icons.request_quote_outlined),
            label: Text(context.t('quotes')),
          ),
        ],
      ),
    ),
  );

  Widget _meta(IconData icon, String text) => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      Icon(
        icon,
        size: 17,
        color: Theme.of(context).colorScheme.onSurfaceVariant,
      ),
      const SizedBox(width: 5),
      Text(
        text,
        style: TextStyle(
          color: Theme.of(context).colorScheme.onSurfaceVariant,
          fontSize: 12,
        ),
      ),
    ],
  );
}

class RequestFormScreen extends StatefulWidget {
  const RequestFormScreen({super.key});
  @override
  State<RequestFormScreen> createState() => _RequestFormScreenState();
}

class _RequestFormScreenState extends State<RequestFormScreen> {
  final _key = GlobalKey<FormState>();
  final _title = TextEditingController();
  final _details = TextEditingController();
  final _material = TextEditingController();
  final _quantity = TextEditingController(text: '1');
  final _budget = TextEditingController();
  DateTime? _deadline;
  PlatformFile? _file;
  bool _saving = false;

  @override
  void dispose() {
    for (final controller in [
      _title,
      _details,
      _material,
      _quantity,
      _budget,
    ]) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      withData: true,
      type: FileType.custom,
      allowedExtensions: [
        'pdf',
        'png',
        'jpg',
        'jpeg',
        'step',
        'stp',
        'dxf',
        'dwg',
        'zip',
      ],
    );
    if (result == null) return;
    final file = result.files.single;
    if (file.bytes == null || file.size > 15 * 1024 * 1024) {
      if (mounted) showAppError(context, 'Maximum file size is 15 MB.');
      return;
    }
    setState(() => _file = file);
  }

  Future<void> _save() async {
    if (!_key.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      final repository = context.read<AppRepository>();
      final id = await repository.createManufacturingRequest(
        title: _title.text,
        details: _details.text,
        material: _material.text,
        quantity: int.parse(_quantity.text),
        deadline: _deadline,
        budget: _budget.text.trim().isEmpty ? null : double.parse(_budget.text),
      );
      if (_file != null) {
        await repository.uploadRequestAttachment(
          requestId: id,
          fileName: _file!.name,
          bytes: _file!.bytes!,
          mimeType: _file!.extension == 'pdf' ? 'application/pdf' : null,
        );
      }
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(context.t('requestCreated'))));
      Navigator.pop(context, true);
    } catch (error) {
      if (mounted) showAppError(context, readableError(error));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(context.t('newRequest'))),
    body: Form(
      key: _key,
      child: PageBody(
        maxWidth: 720,
        children: [
          TextFormField(
            controller: _title,
            maxLength: 140,
            decoration: InputDecoration(labelText: context.t('requestTitle')),
            validator: (v) =>
                (v?.trim().length ?? 0) >= 5 ? null : context.t('required'),
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _details,
            minLines: 4,
            maxLines: 7,
            maxLength: 5000,
            decoration: InputDecoration(
              labelText: context.t('requestDetails'),
              alignLabelWithHint: true,
            ),
            validator: (v) =>
                (v?.trim().length ?? 0) >= 20 ? null : context.t('required'),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextFormField(
                  controller: _material,
                  decoration: InputDecoration(labelText: context.t('material')),
                  validator: (v) => (v?.trim().isNotEmpty ?? false)
                      ? null
                      : context.t('required'),
                ),
              ),
              const SizedBox(width: 12),
              SizedBox(
                width: 120,
                child: TextFormField(
                  controller: _quantity,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(labelText: context.t('quantity')),
                  validator: (v) => Validators.positiveInt(v ?? '') == null
                      ? context.t('invalidNumber')
                      : null,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _budget,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(labelText: context.t('budget')),
            validator: (v) =>
                (v?.trim().isEmpty ?? true) ||
                    Validators.positiveDouble(v!) != null
                ? null
                : context.t('invalidNumber'),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.event_outlined),
              title: Text(context.t('deadline')),
              subtitle: Text(dateLabel(_deadline)),
              trailing: const Icon(Icons.edit_calendar_outlined),
              onTap: () async {
                final now = DateTime.now();
                final value = await showDatePicker(
                  context: context,
                  firstDate: now,
                  lastDate: now.add(const Duration(days: 730)),
                  initialDate: now.add(const Duration(days: 14)),
                );
                if (value != null) setState(() => _deadline = value);
              },
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.attach_file),
              title: Text(_file?.name ?? context.t('attachment')),
              subtitle: Text(context.t('attachmentHelp')),
              trailing: IconButton(
                onPressed: _pickFile,
                icon: const Icon(Icons.upload_file),
              ),
              onTap: _pickFile,
            ),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: _saving ? null : _save,
            icon: _saving
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.publish_outlined),
            label: Text(context.t('publish')),
          ),
        ],
      ),
    ),
  );
}

class QuotesSheet extends StatefulWidget {
  const QuotesSheet({
    super.key,
    required this.request,
    required this.onChanged,
  });
  final ManufacturingRequest request;
  final VoidCallback onChanged;
  @override
  State<QuotesSheet> createState() => _QuotesSheetState();
}

class _QuotesSheetState extends State<QuotesSheet> {
  late Future<List<Quote>> _future;
  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() =>
      _future = context.read<AppRepository>().fetchQuotes(widget.request.id);
  void _retry() => setState(_load);

  Future<void> _addQuote() async {
    final organizations = await context
        .read<AppRepository>()
        .fetchMyOrganizations();
    if (!mounted) return;
    if (organizations.isEmpty) {
      showAppError(
        context,
        context.isArabic
            ? 'أنشئ ملف ورشة أو مصنع أولًا.'
            : 'Create a workshop or factory profile first.',
      );
      return;
    }
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => QuoteFormDialog(
        requestId: widget.request.id,
        organizations: organizations,
      ),
    );
    if (result == true) _retry();
  }

  @override
  Widget build(BuildContext context) {
    final mine = widget.request.ownerId == SupabaseService.userId;
    return SizedBox(
      height: MediaQuery.sizeOf(context).height * .85,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    context.t('quotes'),
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                if (!mine && widget.request.status == 'open')
                  IconButton.filled(
                    onPressed: _addQuote,
                    icon: const Icon(Icons.add),
                  ),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
            Expanded(
              child: AsyncView<List<Quote>>(
                future: _future,
                onRetry: _retry,
                builder: (context, quotes) => quotes.isEmpty
                    ? EmptyView(
                        message: context.t('noData'),
                        icon: Icons.request_quote_outlined,
                      )
                    : ListView(
                        children: quotes
                            .map(
                              (quote) => Card(
                                margin: const EdgeInsets.only(bottom: 10),
                                child: Padding(
                                  padding: const EdgeInsets.all(16),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Expanded(
                                            child: Text(
                                              money(context, quote.amount),
                                              style: const TextStyle(
                                                fontSize: 21,
                                                fontWeight: FontWeight.w800,
                                              ),
                                            ),
                                          ),
                                          StatusChip(
                                            label: statusLabel(
                                              context,
                                              quote.status,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        '${quote.providerName} · ${quote.deliveryDays} ${context.isArabic ? 'يوم' : 'days'}',
                                      ),
                                      if (quote.notes.isNotEmpty) ...[
                                        const SizedBox(height: 8),
                                        Text(quote.notes),
                                      ],
                                      if (mine &&
                                          quote.status == 'pending') ...[
                                        const SizedBox(height: 12),
                                        FilledButton.icon(
                                          onPressed: () async {
                                            try {
                                              await context
                                                  .read<AppRepository>()
                                                  .acceptQuote(quote.id);
                                              if (!context.mounted) return;
                                              ScaffoldMessenger.of(
                                                context,
                                              ).showSnackBar(
                                                SnackBar(
                                                  content: Text(
                                                    context.t('done'),
                                                  ),
                                                ),
                                              );
                                              _retry();
                                              widget.onChanged();
                                            } catch (error) {
                                              if (context.mounted) {
                                                showAppError(
                                                  context,
                                                  readableError(error),
                                                );
                                              }
                                            }
                                          },
                                          icon: const Icon(
                                            Icons.check_circle_outline,
                                          ),
                                          label: Text(context.t('acceptQuote')),
                                        ),
                                      ],
                                    ],
                                  ),
                                ),
                              ),
                            )
                            .toList(),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class QuoteFormDialog extends StatefulWidget {
  const QuoteFormDialog({
    super.key,
    required this.requestId,
    required this.organizations,
  });
  final String requestId;
  final List<Map<String, dynamic>> organizations;
  @override
  State<QuoteFormDialog> createState() => _QuoteFormDialogState();
}

class _QuoteFormDialogState extends State<QuoteFormDialog> {
  final _key = GlobalKey<FormState>();
  final _amount = TextEditingController();
  final _days = TextEditingController();
  final _notes = TextEditingController();
  String? _organization;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _organization = widget.organizations.first['organization_id'].toString();
  }

  @override
  void dispose() {
    _amount.dispose();
    _days.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_key.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      await context.read<AppRepository>().addQuote(
        requestId: widget.requestId,
        providerId: _organization!,
        amount: double.parse(_amount.text),
        deliveryDays: int.parse(_days.text),
        notes: _notes.text,
      );
      if (mounted) Navigator.pop(context, true);
    } catch (error) {
      if (mounted) showAppError(context, readableError(error));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(context.t('addQuote')),
    content: Form(
      key: _key,
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            DropdownButtonFormField<String>(
              initialValue: _organization,
              items: widget.organizations.map((item) {
                final org = item['organizations'] as Map?;
                return DropdownMenuItem(
                  value: item['organization_id'].toString(),
                  child: Text(
                    context.isArabic
                        ? (org?['name_ar'] ?? '').toString()
                        : (org?['name_en'] ?? '').toString(),
                  ),
                );
              }).toList(),
              onChanged: (value) => setState(() => _organization = value),
              decoration: InputDecoration(labelText: context.t('workshop')),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _amount,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              decoration: InputDecoration(labelText: context.t('quoteAmount')),
              validator: (v) => Validators.positiveDouble(v ?? '') == null
                  ? context.t('invalidNumber')
                  : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _days,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: context.t('deliveryDays')),
              validator: (v) => Validators.positiveInt(v ?? '') == null
                  ? context.t('invalidNumber')
                  : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _notes,
              maxLines: 3,
              decoration: InputDecoration(labelText: context.t('notes')),
            ),
          ],
        ),
      ),
    ),
    actions: [
      TextButton(
        onPressed: _saving ? null : () => Navigator.pop(context),
        child: Text(context.t('cancel')),
      ),
      FilledButton(
        onPressed: _saving ? null : _save,
        child: Text(context.t('send')),
      ),
    ],
  );
}
