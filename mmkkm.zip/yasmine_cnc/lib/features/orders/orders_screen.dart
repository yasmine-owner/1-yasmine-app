import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/services/app_repository.dart';
import '../../core/services/supabase_service.dart';
import '../../core/utils/validators.dart';
import '../../core/widgets/app_widgets.dart';
import '../../models/app_models.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});
  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  late Future<List<OrderItem>> _future;
  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() => _future = context.read<AppRepository>().fetchOrders();
  void _retry() => setState(_load);

  Future<void> _advance(OrderItem order, String status) async {
    try {
      await context.read<AppRepository>().changeOrderStatus(order.id, status);
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(context.t('statusChanged'))));
      _retry();
    } catch (error) {
      if (mounted) showAppError(context, readableError(error));
    }
  }

  @override
  Widget build(BuildContext context) => PageBody(
    maxWidth: 900,
    children: [
      SectionHeader(context.t('orders'), subtitle: context.t('dataOnline')),
      AsyncView<List<OrderItem>>(
        future: _future,
        onRetry: _retry,
        builder: (context, orders) => orders.isEmpty
            ? EmptyView(
                message: context.t('noData'),
                icon: Icons.track_changes_outlined,
              )
            : Column(children: orders.map(_card).toList()),
      ),
    ],
  );

  Widget _card(OrderItem order) {
    final isCustomer = order.customerId == SupabaseService.userId;
    String? next;
    if (isCustomer && order.status == 'shipped') next = 'completed';
    if (!isCustomer && order.status == 'in_progress') next = 'quality_check';
    if (!isCustomer && order.status == 'quality_check') next = 'shipped';
    final current = [
      'in_progress',
      'quality_check',
      'shipped',
      'completed',
    ].indexOf(order.status);
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    order.title,
                    style: const TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                StatusChip(label: statusLabel(context, order.status)),
              ],
            ),
            const SizedBox(height: 6),
            Text('${order.orderNumber} · ${order.providerName}'),
            const SizedBox(height: 6),
            Text(
              money(context, order.total),
              style: TextStyle(
                color: Theme.of(context).colorScheme.primary,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 18),
            Row(
              children: List.generate(4, (index) {
                const icons = [
                  Icons.precision_manufacturing,
                  Icons.fact_check_outlined,
                  Icons.local_shipping_outlined,
                  Icons.check_circle_outline,
                ];
                final active = current >= index;
                return Expanded(
                  child: Row(
                    children: [
                      Icon(
                        icons[index],
                        color: active
                            ? Theme.of(context).colorScheme.tertiary
                            : Theme.of(context).colorScheme.outline,
                      ),
                      if (index < 3)
                        Expanded(
                          child: Container(
                            height: 2,
                            color: current > index
                                ? Theme.of(context).colorScheme.tertiary
                                : Theme.of(context).colorScheme.outlineVariant,
                          ),
                        ),
                    ],
                  ),
                );
              }),
            ),
            if (next != null) ...[
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: () => _advance(order, next!),
                icon: const Icon(Icons.arrow_forward),
                label: Text(
                  '${context.t('nextStatus')} · ${statusLabel(context, next)}',
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
