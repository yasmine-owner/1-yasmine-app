import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/services/app_repository.dart';
import '../../core/services/supabase_service.dart';
import '../../core/utils/validators.dart';
import '../../core/widgets/app_widgets.dart';
import '../../models/app_models.dart';

class MessagesScreen extends StatefulWidget {
  const MessagesScreen({super.key});
  @override
  State<MessagesScreen> createState() => _MessagesScreenState();
}

class _MessagesScreenState extends State<MessagesScreen> {
  late Future<List<Conversation>> _future;
  String? _selected;
  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() => _future = context.read<AppRepository>().fetchConversations();
  void _retry() => setState(_load);

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      final wide = constraints.maxWidth >= 850;
      final list = AsyncView<List<Conversation>>(
        future: _future,
        onRetry: _retry,
        builder: (context, conversations) {
          if (conversations.isEmpty) {
            return EmptyView(
              message: context.t('noConversations'),
              icon: Icons.chat_bubble_outline,
            );
          }
          return ListView.builder(
            shrinkWrap: !wide,
            physics: wide ? null : const NeverScrollableScrollPhysics(),
            itemCount: conversations.length,
            itemBuilder: (context, index) {
              final conversation = conversations[index];
              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: ListTile(
                  selected: _selected == conversation.id,
                  leading: const CircleAvatar(
                    child: Icon(Icons.forum_outlined),
                  ),
                  title: Text(conversation.title),
                  subtitle: Text(
                    conversation.lastMessage,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () {
                    if (wide) {
                      setState(() => _selected = conversation.id);
                    } else {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) =>
                              ConversationScreen(conversation: conversation),
                        ),
                      );
                    }
                  },
                ),
              );
            },
          );
        },
      );
      if (!wide) {
        return PageBody(children: [SectionHeader(context.t('messages')), list]);
      }
      return Row(
        children: [
          SizedBox(
            width: 330,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    context.t('messages'),
                    style: const TextStyle(
                      fontSize: 23,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Expanded(child: list),
                ],
              ),
            ),
          ),
          const VerticalDivider(width: 1),
          Expanded(
            child: _selected == null
                ? EmptyView(
                    message: context.t('messages'),
                    icon: Icons.chat_bubble_outline,
                  )
                : ConversationView(conversationId: _selected!),
          ),
        ],
      );
    },
  );
}

class ConversationScreen extends StatelessWidget {
  const ConversationScreen({super.key, required this.conversation});
  final Conversation conversation;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(conversation.title)),
    body: ConversationView(conversationId: conversation.id),
  );
}

class ConversationView extends StatefulWidget {
  const ConversationView({super.key, required this.conversationId});
  final String conversationId;
  @override
  State<ConversationView> createState() => _ConversationViewState();
}

class _ConversationViewState extends State<ConversationView> {
  late Future<List<Message>> _future;
  final _message = TextEditingController();
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() => _future = context.read<AppRepository>().fetchMessages(
    widget.conversationId,
  );
  void _retry() => setState(_load);
  @override
  void didUpdateWidget(covariant ConversationView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.conversationId != widget.conversationId) _retry();
  }

  @override
  void dispose() {
    _message.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (_message.text.trim().isEmpty) return;
    setState(() => _sending = true);
    try {
      await context.read<AppRepository>().sendMessage(
        widget.conversationId,
        _message.text,
      );
      _message.clear();
      _retry();
    } catch (error) {
      if (mounted) showAppError(context, readableError(error));
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) => Column(
    children: [
      Expanded(
        child: AsyncView<List<Message>>(
          future: _future,
          onRetry: _retry,
          builder: (context, messages) => messages.isEmpty
              ? EmptyView(
                  message: context.t('noData'),
                  icon: Icons.chat_bubble_outline,
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: messages.length,
                  itemBuilder: (context, index) {
                    final message = messages[index];
                    final mine = message.senderId == SupabaseService.userId;
                    return Align(
                      alignment: mine
                          ? AlignmentDirectional.centerEnd
                          : AlignmentDirectional.centerStart,
                      child: Container(
                        constraints: const BoxConstraints(maxWidth: 520),
                        margin: const EdgeInsets.only(bottom: 9),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 11,
                        ),
                        decoration: BoxDecoration(
                          color: mine
                              ? Theme.of(context).colorScheme.primary
                              : Theme.of(context).colorScheme.surface,
                          borderRadius: BorderRadius.circular(15),
                          border: mine
                              ? null
                              : Border.all(
                                  color: Theme.of(
                                    context,
                                  ).colorScheme.outlineVariant,
                                ),
                        ),
                        child: Text(
                          message.body,
                          style: TextStyle(
                            color: mine
                                ? Theme.of(context).colorScheme.onPrimary
                                : null,
                            height: 1.55,
                          ),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ),
      SafeArea(
        top: false,
        child: Padding(
          padding: EdgeInsets.fromLTRB(
            12,
            8,
            12,
            8 + MediaQuery.viewInsetsOf(context).bottom,
          ),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _message,
                  minLines: 1,
                  maxLines: 4,
                  decoration: InputDecoration(
                    hintText: context.t('typeMessage'),
                  ),
                  onSubmitted: (_) => _send(),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(
                onPressed: _sending ? null : _send,
                icon: const Icon(Icons.send),
              ),
            ],
          ),
        ),
      ),
    ],
  );
}
