import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/services/app_repository.dart';
import '../../core/services/supabase_service.dart';
import '../../core/theme/theme_settings.dart';
import '../../core/utils/validators.dart';
import '../../core/widgets/app_widgets.dart';
import '../../models/app_models.dart';
import '../../state/app_controller.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});
  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  int _refresh = 0;
  void _refreshData() => setState(() => _refresh++);

  @override
  Widget build(BuildContext context) {
    final profile = context.watch<AppController>().profile;
    if (profile?.isAdmin != true) {
      return EmptyView(
        message: context.t('permissionError'),
        icon: Icons.admin_panel_settings_outlined,
      );
    }
    return DefaultTabController(
      length: 6,
      child: Column(
        children: [
          Material(
            color: Theme.of(context).colorScheme.surface,
            child: TabBar(
              isScrollable: true,
              tabAlignment: TabAlignment.start,
              tabs: [
                Tab(
                  text: context.t('overview'),
                  icon: const Icon(Icons.dashboard_outlined),
                ),
                Tab(
                  text: context.t('appearance'),
                  icon: const Icon(Icons.palette_outlined),
                ),
                Tab(
                  text: context.t('verifications'),
                  icon: const Icon(Icons.verified_outlined),
                ),
                Tab(
                  text: context.t('products'),
                  icon: const Icon(Icons.fact_check_outlined),
                ),
                Tab(
                  text: context.t('users'),
                  icon: const Icon(Icons.people_outline),
                ),
                Tab(
                  text: context.t('settings'),
                  icon: const Icon(Icons.settings_outlined),
                ),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              children: [
                AdminOverview(key: ValueKey(_refresh)),
                AppearanceEditor(onSaved: _refreshData),
                VerificationAdmin(
                  key: ValueKey(_refresh),
                  onChanged: _refreshData,
                ),
                ProductModeration(
                  key: ValueKey(_refresh),
                  onChanged: _refreshData,
                ),
                UsersAdmin(key: ValueKey(_refresh), onChanged: _refreshData),
                GeneralSettingsEditor(key: ValueKey(_refresh)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class AdminOverview extends StatefulWidget {
  const AdminOverview({super.key});
  @override
  State<AdminOverview> createState() => _AdminOverviewState();
}

class _AdminOverviewState extends State<AdminOverview> {
  late Future<DashboardStats> _future;
  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() => _future = context.read<AppRepository>().fetchDashboardStats();
  void _retry() => setState(_load);
  @override
  Widget build(BuildContext context) => PageBody(
    children: [
      SectionHeader(context.t('overview'), subtitle: context.t('dataOnline')),
      AsyncView<DashboardStats>(
        future: _future,
        onRetry: _retry,
        builder: (context, stats) => LayoutBuilder(
          builder: (context, constraints) => GridView.count(
            crossAxisCount: constraints.maxWidth >= 900 ? 4 : 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisExtent: 100,
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            children: [
              StatCard(
                label: context.t('totalUsers'),
                value: '${stats.users}',
                icon: Icons.people_outline,
              ),
              StatCard(
                label: context.t('totalRequests'),
                value: '${stats.requests}',
                icon: Icons.assignment_outlined,
              ),
              StatCard(
                label: context.t('totalProducts'),
                value: '${stats.products}',
                icon: Icons.storefront_outlined,
              ),
              StatCard(
                label: context.t('pendingVerifications'),
                value: '${stats.pendingVerifications}',
                icon: Icons.verified_outlined,
              ),
            ],
          ),
        ),
      ),
    ],
  );
}

class AppearanceEditor extends StatefulWidget {
  const AppearanceEditor({super.key, required this.onSaved});
  final VoidCallback onSaved;
  @override
  State<AppearanceEditor> createState() => _AppearanceEditorState();
}

class _AppearanceEditorState extends State<AppearanceEditor> {
  late AppThemeSettings _draft;
  bool _saving = false;
  @override
  void initState() {
    super.initState();
    _draft = context.read<AppController>().theme;
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    try {
      await context.read<AppRepository>().publishTheme(_draft);
      if (!mounted) return;
      await context.read<AppController>().updateTheme(_draft);
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(context.t('appearanceSaved'))));
      widget.onSaved();
    } catch (error) {
      if (mounted) showAppError(context, readableError(error));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _editColor(
    String label,
    Color current,
    ValueChanged<Color> onChanged,
  ) async {
    final controller = TextEditingController(
      text: AppThemeSettings.hex(current),
    );
    final form = GlobalKey<FormState>();
    final result = await showDialog<Color>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(label),
        content: Form(
          key: form,
          child: TextFormField(
            controller: controller,
            autofocus: true,
            textDirection: TextDirection.ltr,
            decoration: const InputDecoration(hintText: '#00B4D8'),
            validator: (value) => AppThemeSettings.parseHex(value ?? '') == null
                ? '#RRGGBB'
                : null,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: Text(context.t('cancel')),
          ),
          FilledButton(
            onPressed: () {
              if (!form.currentState!.validate()) return;
              Navigator.pop(
                dialogContext,
                AppThemeSettings.parseHex(controller.text),
              );
            },
            child: Text(context.t('save')),
          ),
        ],
      ),
    );
    controller.dispose();
    if (result != null) setState(() => onChanged(result));
  }

  @override
  Widget build(BuildContext context) {
    final previewTheme = AppThemeSettings.defaults;
    return PageBody(
      maxWidth: 900,
      children: [
        SectionHeader(
          context.t('appearance'),
          subtitle: context.t('appearanceHelp'),
        ),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  context.t('presets'),
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    ChoiceChip(
                      label: Text(context.t('navyTheme')),
                      selected: false,
                      onSelected: (_) => setState(
                        () => _draft = AppThemeSettings.navy.copyWith(
                          darkMode: _draft.darkMode,
                        ),
                      ),
                    ),
                    ChoiceChip(
                      label: Text(context.t('oceanTheme')),
                      selected: false,
                      onSelected: (_) => setState(
                        () => _draft = AppThemeSettings.ocean.copyWith(
                          darkMode: _draft.darkMode,
                        ),
                      ),
                    ),
                    ChoiceChip(
                      label: Text(context.t('emeraldTheme')),
                      selected: false,
                      onSelected: (_) => setState(
                        () => _draft = AppThemeSettings.emerald.copyWith(
                          darkMode: _draft.darkMode,
                        ),
                      ),
                    ),
                  ],
                ),
                const Divider(height: 30),
                _colorRow(
                  'primaryColor',
                  _draft.primary,
                  (color) => _draft = _draft.copyWith(primary: color),
                ),
                _colorRow(
                  'secondaryColor',
                  _draft.secondary,
                  (color) => _draft = _draft.copyWith(secondary: color),
                ),
                _colorRow(
                  'successColor',
                  _draft.success,
                  (color) => _draft = _draft.copyWith(success: color),
                ),
                _colorRow(
                  'backgroundColor',
                  _draft.background,
                  (color) => _draft = _draft.copyWith(background: color),
                ),
                _colorRow(
                  'textColor',
                  _draft.text,
                  (color) => _draft = _draft.copyWith(text: color),
                ),
                const Divider(height: 30),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(context.t('darkMode')),
                  value: _draft.darkMode,
                  onChanged: (value) =>
                      setState(() => _draft = _draft.copyWith(darkMode: value)),
                ),
                DropdownButtonFormField<String>(
                  initialValue: _draft.fontFamily,
                  items: const [
                    DropdownMenuItem(
                      value: 'NotoSansArabic',
                      child: Text('Noto Sans Arabic'),
                    ),
                    DropdownMenuItem(
                      value: 'NotoKufiArabic',
                      child: Text('Noto Kufi Arabic'),
                    ),
                    DropdownMenuItem(
                      value: 'NotoNaskhArabic',
                      child: Text('Noto Naskh Arabic'),
                    ),
                  ],
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(fontFamily: value),
                  ),
                  decoration: InputDecoration(labelText: context.t('font')),
                ),
                const SizedBox(height: 18),
                Text(
                  '${context.t('fontScale')}: ${(_draft.fontScale * 100).round()}%',
                ),
                Slider(
                  value: _draft.fontScale,
                  min: .85,
                  max: 1.3,
                  divisions: 9,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(fontScale: value),
                  ),
                ),
                Text(
                  '${context.t('cornerRadius')}: ${_draft.borderRadius.round()}',
                ),
                Slider(
                  value: _draft.borderRadius,
                  min: 4,
                  max: 28,
                  divisions: 24,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(borderRadius: value),
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: _draft.primary,
                    borderRadius: BorderRadius.circular(_draft.borderRadius),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        context.t('preview'),
                        style: TextStyle(
                          color: _draft.secondary,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 7),
                      Text(
                        context.t('previewText'),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: _saving ? null : _save,
                        icon: const Icon(Icons.publish_outlined),
                        label: Text(context.t('saveAppearance')),
                      ),
                    ),
                    const SizedBox(width: 10),
                    IconButton.outlined(
                      onPressed: () => setState(() => _draft = previewTheme),
                      icon: const Icon(Icons.restart_alt),
                      tooltip: context.t('resetAppearance'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _colorRow(String key, Color color, ValueChanged<Color> onChanged) =>
      ListTile(
        contentPadding: EdgeInsets.zero,
        leading: ColorDot(color),
        title: Text(context.t(key)),
        subtitle: Text(AppThemeSettings.hex(color)),
        trailing: const Icon(Icons.edit_outlined),
        onTap: () => _editColor(context.t(key), color, onChanged),
      );
}

class VerificationAdmin extends StatefulWidget {
  const VerificationAdmin({super.key, required this.onChanged});
  final VoidCallback onChanged;
  @override
  State<VerificationAdmin> createState() => _VerificationAdminState();
}

class _VerificationAdminState extends State<VerificationAdmin> {
  late Future<List<Map<String, dynamic>>> _future;
  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() =>
      _future = context.read<AppRepository>().fetchVerificationRequests();
  void _retry() => setState(_load);

  Future<void> _review(String id, bool approved) async {
    try {
      await context.read<AppRepository>().reviewVerification(id, approved, '');
      _retry();
      widget.onChanged();
    } catch (error) {
      if (mounted) showAppError(context, readableError(error));
    }
  }

  @override
  Widget build(BuildContext context) => PageBody(
    children: [
      SectionHeader(context.t('verifications')),
      AsyncView<List<Map<String, dynamic>>>(
        future: _future,
        onRetry: _retry,
        builder: (context, items) => items.isEmpty
            ? EmptyView(
                message: context.t('noData'),
                icon: Icons.verified_outlined,
              )
            : Column(
                children: items.map((item) {
                  final org = item['organizations'];
                  final pending = item['status'] == 'pending';
                  return Card(
                    margin: const EdgeInsets.only(bottom: 10),
                    child: ListTile(
                      leading: const Icon(Icons.business_outlined),
                      title: Text(
                        org is Map
                            ? org[context.isArabic ? 'name_ar' : 'name_en']
                                      ?.toString() ??
                                  ''
                            : context.t('profile'),
                      ),
                      subtitle: Text(
                        '${item['document_type'] ?? ''} · ${item['status']}',
                      ),
                      trailing: pending
                          ? Wrap(
                              children: [
                                IconButton(
                                  onPressed: () =>
                                      _review(item['id'].toString(), false),
                                  icon: const Icon(Icons.close),
                                  tooltip: context.t('reject'),
                                ),
                                IconButton.filled(
                                  onPressed: () =>
                                      _review(item['id'].toString(), true),
                                  icon: const Icon(Icons.check),
                                  tooltip: context.t('approve'),
                                ),
                              ],
                            )
                          : StatusChip(
                              label: statusLabel(
                                context,
                                item['status'].toString(),
                              ),
                            ),
                    ),
                  );
                }).toList(),
              ),
      ),
    ],
  );
}

class ProductModeration extends StatefulWidget {
  const ProductModeration({super.key, required this.onChanged});
  final VoidCallback onChanged;
  @override
  State<ProductModeration> createState() => _ProductModerationState();
}

class _ProductModerationState extends State<ProductModeration> {
  late Future<List<Map<String, dynamic>>> _future;
  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() =>
      _future = context.read<AppRepository>().fetchPendingProducts();
  void _retry() => setState(_load);
  Future<void> _review(String id, bool approved) async {
    try {
      await context.read<AppRepository>().moderateProduct(id, approved);
      _retry();
      widget.onChanged();
    } catch (error) {
      if (mounted) showAppError(context, readableError(error));
    }
  }

  @override
  Widget build(BuildContext context) => PageBody(
    children: [
      SectionHeader('${context.t('products')} · ${context.t('pending')}'),
      AsyncView<List<Map<String, dynamic>>>(
        future: _future,
        onRetry: _retry,
        builder: (context, items) => items.isEmpty
            ? EmptyView(
                message: context.t('noData'),
                icon: Icons.fact_check_outlined,
              )
            : Column(
                children: items
                    .map(
                      (item) => Card(
                        margin: const EdgeInsets.only(bottom: 10),
                        child: ListTile(
                          title: Text(item['title'].toString()),
                          subtitle: Text(
                            '${money(context, item['price'] as num)} · ${item['city']}',
                          ),
                          trailing: Wrap(
                            children: [
                              IconButton(
                                onPressed: () =>
                                    _review(item['id'].toString(), false),
                                icon: const Icon(Icons.close),
                              ),
                              IconButton.filled(
                                onPressed: () =>
                                    _review(item['id'].toString(), true),
                                icon: const Icon(Icons.check),
                              ),
                            ],
                          ),
                        ),
                      ),
                    )
                    .toList(),
              ),
      ),
    ],
  );
}

class UsersAdmin extends StatefulWidget {
  const UsersAdmin({super.key, required this.onChanged});
  final VoidCallback onChanged;
  @override
  State<UsersAdmin> createState() => _UsersAdminState();
}

class _UsersAdminState extends State<UsersAdmin> {
  late Future<List<Map<String, dynamic>>> _future;
  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() => _future = context.read<AppRepository>().fetchUsers();
  void _retry() => setState(_load);
  Future<void> _toggle(Map<String, dynamic> user, bool active) async {
    try {
      await context.read<AppRepository>().setUserActive(
        user['id'].toString(),
        active,
      );
      _retry();
      widget.onChanged();
    } catch (error) {
      if (mounted) showAppError(context, readableError(error));
    }
  }

  @override
  Widget build(BuildContext context) => PageBody(
    children: [
      SectionHeader(context.t('users')),
      AsyncView<List<Map<String, dynamic>>>(
        future: _future,
        onRetry: _retry,
        builder: (context, users) => Column(
          children: users.map((user) {
            final active = user['is_active'] == true;
            final self = user['id'] == SupabaseService.userId;
            return Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: SwitchListTile(
                secondary: CircleAvatar(
                  child: Text(
                    user['full_name']?.toString().isNotEmpty == true
                        ? user['full_name'].toString()[0]
                        : 'Y',
                  ),
                ),
                title: Text(user['full_name']?.toString() ?? ''),
                subtitle: Text(
                  '${user['account_type']} · ${user['city'] ?? ''} · ${active ? context.t('active') : context.t('inactive')}',
                ),
                value: active,
                onChanged: self ? null : (value) => _toggle(user, value),
              ),
            );
          }).toList(),
        ),
      ),
    ],
  );
}

class GeneralSettingsEditor extends StatefulWidget {
  const GeneralSettingsEditor({super.key});
  @override
  State<GeneralSettingsEditor> createState() => _GeneralSettingsEditorState();
}

class _GeneralSettingsEditorState extends State<GeneralSettingsEditor> {
  final _nameAr = TextEditingController();
  final _nameEn = TextEditingController();
  final _commission = TextEditingController();
  late Future<void> _future;
  bool _saving = false;
  @override
  void initState() {
    super.initState();
    _future = context.read<AppRepository>().fetchGeneralSettings().then((
      settings,
    ) {
      _nameAr.text = settings['platform_name_ar']?.toString() ?? 'ياسمين CNC';
      _nameEn.text = settings['platform_name_en']?.toString() ?? 'Yasmine CNC';
      _commission.text = (settings['commission_rate'] ?? 5).toString();
    });
  }

  @override
  void dispose() {
    _nameAr.dispose();
    _nameEn.dispose();
    _commission.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final commission = double.tryParse(_commission.text);
    if (_nameAr.text.trim().isEmpty ||
        _nameEn.text.trim().isEmpty ||
        commission == null ||
        commission < 0 ||
        commission > 30) {
      showAppError(context, context.t('invalidNumber'));
      return;
    }
    setState(() => _saving = true);
    try {
      await context.read<AppRepository>().saveGeneralSettings(
        platformNameAr: _nameAr.text,
        platformNameEn: _nameEn.text,
        commission: commission,
      );
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(context.t('settingsSaved'))));
      }
    } catch (error) {
      if (mounted) showAppError(context, readableError(error));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _retry() => setState(() {});
  @override
  Widget build(BuildContext context) => PageBody(
    maxWidth: 700,
    children: [
      SectionHeader(context.t('generalSettings')),
      AsyncView<void>(
        future: _future,
        onRetry: _retry,
        builder: (context, _) => Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              children: [
                TextField(
                  controller: _nameAr,
                  decoration: const InputDecoration(
                    labelText: 'اسم المنصة بالعربية',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _nameEn,
                  decoration: const InputDecoration(
                    labelText: 'Platform name in English',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _commission,
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                  ),
                  decoration: InputDecoration(
                    labelText: context.t('commission'),
                  ),
                ),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: _saving ? null : _save,
                    icon: const Icon(Icons.save_outlined),
                    label: Text(context.t('saveSettings')),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ],
  );
}
