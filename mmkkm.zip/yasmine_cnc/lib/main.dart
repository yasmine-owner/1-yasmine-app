import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'app.dart';
import 'core/services/app_repository.dart';
import 'core/services/supabase_service.dart';
import 'state/app_controller.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SupabaseService.initialize();
  runApp(
    MultiProvider(
      providers: [
        Provider(create: (_) => AppRepository()),
        ChangeNotifierProvider(
          create: (context) =>
              AppController(context.read<AppRepository>())..initialize(),
        ),
      ],
      child: const YasmineApp(),
    ),
  );
}
