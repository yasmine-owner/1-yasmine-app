String _s(Object? value, [String fallback = '']) =>
    value?.toString() ?? fallback;
int _i(Object? value) =>
    value is num ? value.toInt() : int.tryParse(_s(value)) ?? 0;
double _d(Object? value) =>
    value is num ? value.toDouble() : double.tryParse(_s(value)) ?? 0;
DateTime? _date(Object? value) => DateTime.tryParse(_s(value));

class Profile {
  const Profile({
    required this.id,
    required this.fullName,
    required this.accountType,
    required this.role,
    this.specialty = '',
    this.city = '',
    this.bio = '',
    this.avatarPath,
    this.isActive = true,
    this.isVerified = false,
  });
  final String id;
  final String fullName;
  final String accountType;
  final String role;
  final String specialty;
  final String city;
  final String bio;
  final String? avatarPath;
  final bool isActive;
  final bool isVerified;
  bool get isAdmin => role == 'admin';

  factory Profile.fromMap(Map<String, dynamic> map) => Profile(
    id: _s(map['id']),
    fullName: _s(map['full_name']),
    accountType: _s(map['account_type'], 'client'),
    role: _s(map['role'], 'user'),
    specialty: _s(map['specialty']),
    city: _s(map['city']),
    bio: _s(map['bio']),
    avatarPath: map['avatar_path']?.toString(),
    isActive: map['is_active'] != false,
    isVerified: map['is_verified'] == true,
  );
}

class Product {
  const Product({
    required this.id,
    required this.title,
    required this.description,
    required this.price,
    required this.city,
    required this.condition,
    required this.stock,
    required this.status,
    this.categoryName = '',
  });
  final String id;
  final String title;
  final String description;
  final double price;
  final String city;
  final String condition;
  final int stock;
  final String status;
  final String categoryName;
  factory Product.fromMap(Map<String, dynamic> map) {
    final category = map['categories'];
    return Product(
      id: _s(map['id']),
      title: _s(map['title']),
      description: _s(map['description']),
      price: _d(map['price']),
      city: _s(map['city']),
      condition: _s(map['condition'], 'new'),
      stock: _i(map['stock']),
      status: _s(map['status'], 'pending'),
      categoryName: category is Map
          ? _s(category['name_ar'] ?? category['name_en'])
          : '',
    );
  }
}

class ManufacturingRequest {
  const ManufacturingRequest({
    required this.id,
    required this.ownerId,
    required this.title,
    required this.details,
    required this.material,
    required this.quantity,
    required this.unit,
    required this.status,
    this.deadline,
    this.budget,
    this.quotesCount = 0,
  });
  final String id;
  final String ownerId;
  final String title;
  final String details;
  final String material;
  final int quantity;
  final String unit;
  final String status;
  final DateTime? deadline;
  final double? budget;
  final int quotesCount;
  factory ManufacturingRequest.fromMap(Map<String, dynamic> map) {
    final quotes = map['quotes'];
    var count = 0;
    if (quotes is List && quotes.isNotEmpty && quotes.first is Map) {
      count = _i((quotes.first as Map)['count']);
    }
    return ManufacturingRequest(
      id: _s(map['id']),
      ownerId: _s(map['owner_id']),
      title: _s(map['title']),
      details: _s(map['details']),
      material: _s(map['material']),
      quantity: _i(map['quantity']),
      unit: _s(map['unit'], 'piece'),
      status: _s(map['status'], 'open'),
      deadline: _date(map['deadline']),
      budget: map['budget'] == null ? null : _d(map['budget']),
      quotesCount: count,
    );
  }
}

class Quote {
  const Quote({
    required this.id,
    required this.requestId,
    required this.providerId,
    required this.amount,
    required this.deliveryDays,
    required this.status,
    this.notes = '',
    this.providerName = '',
  });
  final String id;
  final String requestId;
  final String providerId;
  final double amount;
  final int deliveryDays;
  final String status;
  final String notes;
  final String providerName;
  factory Quote.fromMap(Map<String, dynamic> map) {
    final org = map['organizations'];
    return Quote(
      id: _s(map['id']),
      requestId: _s(map['request_id']),
      providerId: _s(map['provider_id']),
      amount: _d(map['amount']),
      deliveryDays: _i(map['delivery_days']),
      status: _s(map['status'], 'pending'),
      notes: _s(map['notes']),
      providerName: org is Map ? _s(org['name_ar'] ?? org['name_en']) : '',
    );
  }
}

class Workshop {
  const Workshop({
    required this.id,
    required this.nameAr,
    required this.nameEn,
    required this.description,
    required this.city,
    required this.verificationStatus,
    this.capabilities = const [],
    this.rating = 0,
  });
  final String id;
  final String nameAr;
  final String nameEn;
  final String description;
  final String city;
  final String verificationStatus;
  final List<String> capabilities;
  final double rating;
  bool get verified => verificationStatus == 'approved';
  factory Workshop.fromMap(Map<String, dynamic> map) => Workshop(
    id: _s(map['id']),
    nameAr: _s(map['name_ar']),
    nameEn: _s(map['name_en']),
    description: _s(map['description']),
    city: _s(map['city']),
    verificationStatus: _s(map['verification_status'], 'pending'),
    capabilities: map['capabilities'] is List
        ? (map['capabilities'] as List).map((e) => e.toString()).toList()
        : const [],
    rating: _d(map['rating_average']),
  );
}

class Job {
  const Job({
    required this.id,
    required this.title,
    required this.description,
    required this.city,
    required this.employmentType,
    this.salaryMin,
    this.salaryMax,
    this.companyName = '',
    this.skills = const [],
  });
  final String id;
  final String title;
  final String description;
  final String city;
  final String employmentType;
  final double? salaryMin;
  final double? salaryMax;
  final String companyName;
  final List<String> skills;
  factory Job.fromMap(Map<String, dynamic> map) {
    final org = map['organizations'];
    return Job(
      id: _s(map['id']),
      title: _s(map['title']),
      description: _s(map['description']),
      city: _s(map['city']),
      employmentType: _s(map['employment_type'], 'full_time'),
      salaryMin: map['salary_min'] == null ? null : _d(map['salary_min']),
      salaryMax: map['salary_max'] == null ? null : _d(map['salary_max']),
      companyName: org is Map ? _s(org['name_ar'] ?? org['name_en']) : '',
      skills: map['skills'] is List
          ? (map['skills'] as List).map((e) => e.toString()).toList()
          : const [],
    );
  }
}

class Post {
  const Post({
    required this.id,
    required this.authorId,
    required this.body,
    required this.createdAt,
    this.authorName = '',
    this.likesCount = 0,
    this.commentsCount = 0,
    this.likedByMe = false,
  });
  final String id;
  final String authorId;
  final String body;
  final DateTime? createdAt;
  final String authorName;
  final int likesCount;
  final int commentsCount;
  final bool likedByMe;
  factory Post.fromMap(Map<String, dynamic> map) => Post(
    id: _s(map['id']),
    authorId: _s(map['author_id']),
    body: _s(map['body']),
    createdAt: _date(map['created_at']),
    authorName: _s(map['author_name']),
    likesCount: _i(map['likes_count']),
    commentsCount: _i(map['comments_count']),
    likedByMe: map['liked_by_me'] == true,
  );
}

class Conversation {
  const Conversation({
    required this.id,
    this.title = '',
    this.lastMessage = '',
  });
  final String id;
  final String title;
  final String lastMessage;
  factory Conversation.fromMap(Map<String, dynamic> map) => Conversation(
    id: _s(map['id']),
    title: _s(map['title'], 'Conversation'),
    lastMessage: _s(map['last_message']),
  );
}

class Message {
  const Message({
    required this.id,
    required this.senderId,
    required this.body,
    required this.createdAt,
  });
  final String id;
  final String senderId;
  final String body;
  final DateTime? createdAt;
  factory Message.fromMap(Map<String, dynamic> map) => Message(
    id: _s(map['id']),
    senderId: _s(map['sender_id']),
    body: _s(map['body']),
    createdAt: _date(map['created_at']),
  );
}

class NotificationItem {
  const NotificationItem({
    required this.id,
    required this.title,
    required this.body,
    this.readAt,
    this.createdAt,
  });
  final String id;
  final String title;
  final String body;
  final DateTime? readAt;
  final DateTime? createdAt;
  factory NotificationItem.fromMap(Map<String, dynamic> map) =>
      NotificationItem(
        id: _s(map['id']),
        title: _s(map['title']),
        body: _s(map['body']),
        readAt: _date(map['read_at']),
        createdAt: _date(map['created_at']),
      );
}

class DashboardStats {
  const DashboardStats({
    this.users = 0,
    this.requests = 0,
    this.products = 0,
    this.pendingVerifications = 0,
  });
  final int users;
  final int requests;
  final int products;
  final int pendingVerifications;
}

class OrderItem {
  const OrderItem({
    required this.id,
    required this.orderNumber,
    required this.title,
    required this.providerName,
    required this.total,
    required this.status,
    required this.customerId,
    required this.providerId,
  });
  final String id;
  final String orderNumber;
  final String title;
  final String providerName;
  final double total;
  final String status;
  final String customerId;
  final String providerId;
  factory OrderItem.fromMap(Map<String, dynamic> map) {
    final request = map['manufacturing_requests'];
    final provider = map['organizations'];
    return OrderItem(
      id: _s(map['id']),
      orderNumber: _s(map['order_number']),
      title: request is Map ? _s(request['title']) : '',
      providerName: provider is Map
          ? _s(provider['name_ar'] ?? provider['name_en'])
          : '',
      total: _d(map['total']),
      status: _s(map['status'], 'in_progress'),
      customerId: _s(map['customer_id']),
      providerId: _s(map['provider_id']),
    );
  }
}

class CourseItem {
  const CourseItem({
    required this.id,
    required this.titleAr,
    required this.titleEn,
    required this.description,
    required this.city,
    required this.deliveryMode,
    required this.price,
    this.startsAt,
    this.providerName = '',
  });
  final String id;
  final String titleAr;
  final String titleEn;
  final String description;
  final String city;
  final String deliveryMode;
  final double price;
  final DateTime? startsAt;
  final String providerName;
  factory CourseItem.fromMap(Map<String, dynamic> map) {
    final provider = map['organizations'];
    return CourseItem(
      id: _s(map['id']),
      titleAr: _s(map['title_ar']),
      titleEn: _s(map['title_en']),
      description: _s(map['description']),
      city: _s(map['city']),
      deliveryMode: _s(map['delivery_mode']),
      price: _d(map['price']),
      startsAt: _date(map['starts_at']),
      providerName: provider is Map
          ? _s(provider['name_ar'] ?? provider['name_en'])
          : '',
    );
  }
}
