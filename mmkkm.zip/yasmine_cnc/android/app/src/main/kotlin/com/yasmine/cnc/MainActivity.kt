package com.yasmine.cnc

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
